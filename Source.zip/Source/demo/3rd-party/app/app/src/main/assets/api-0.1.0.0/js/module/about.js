(function (window, $){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,                
        Module = topWindow.Module,
        web = topWindow.web,
        Constants = topWindow.Constants,
        Config = topWindow.Config,
        StringUtil = topWindow.StringUtil,

	    /********************* Internal variable ****************************/
        VS_CSS_DEBUG = '.app-debug',
        
        VS_CSS_VERSION = '.app-version',
        VS_CSS_TYPE = '.app-type',
        VS_CSS_HOST = '.app-host',
        VS_CSS_OS = '.app-os',
        VS_CSS_RESOLUTION = '.app-resolution',
        VS_CSS_SIZE = '.app-size',
        VS_CSS_ACCESS = '.app-access',
        VS_CSS_TOKEN = '.app-token',
        VS_CSS_SCOPE = '.app-scope',
        VS_CSS_USER = '.app-user',
        VS_CSS_CALLBACK = '.app-callback';

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************
    function _showAbout(ao_view) {
        var lo_$view = $(ao_view),
            ls_phoneSize,
            ls_screenSize;
        
        lo_$view.find(VS_CSS_VERSION).html('V ' + web.getVersion());
        
        if (web.isDebug()) {  
            lo_$view.find(VS_CSS_TYPE).html(web.getGateway());
            lo_$view.find(VS_CSS_HOST).html(web.getHost());

            if (web.isExpiredToken()) {
                lo_$view.find(VS_CSS_TOKEN).html(web.getToken() + ' (Expired)');
            } else {
                lo_$view.find(VS_CSS_TOKEN).html(web.getToken());
            }

            lo_$view.find(VS_CSS_USER).html(web.getAuthUser());
            //lo_$view.find(VS_CSS_SCOPE).html(StringUtil.decodeUri(web.getScope()));
            
            lo_$view.find(VS_CSS_ACCESS).html(web.getAuthUrl());
            lo_$view.find(VS_CSS_CALLBACK).html(Config.PS_URL_AUTH_CALLBACK);

            if (web.isPhone()) {
                ls_phoneSize = ' H :' + androidJS.getHeight();
                ls_phoneSize += ' W :' + androidJS.getWidth();
                ls_phoneSize += ' DPI :' + androidJS.getDpi();

                lo_$view.find(VS_CSS_RESOLUTION).html(ls_phoneSize);
                lo_$view.find(VS_CSS_OS).html(web.getOS());
            }

             ls_screenSize = ' H : ' + $(window).height();
             ls_screenSize += ' W : ' + $(window).width();

             lo_$view.find(VS_CSS_SIZE).html(ls_screenSize);
        } else {
            lo_$view.find(VS_CSS_DEBUG).hide();
        }
    }
    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function About() {
        Module.call(this);
    }

    CommonUtil.$extends(About, Module, {
        bindEvent : function() {
            var lo_$view = $(this.getPage());
            
            if (web.isDebug()) {
                lo_$view.find(VS_CSS_DEBUG).removeClass('mui-hidden');
            } else {
                lo_$view.find(VS_CSS_DEBUG).addClass('mui-hidden');
            }
        },
        
        refresh : function() {
            _showAbout(this.getPage());
        }
    });
   
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.About = About;

}(window, jQuery));
