(function (window, $){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,                
        Config = topWindow.Config,
        Constants = topWindow.Constants,
        StringUtil = topWindow.StringUtil,
        CommonUtil = topWindow.CommonUtil,
        Mapping = window.Mapping,
        Message = topWindow.Message,
        
        web = window.web,
        
        /********************* Internal variable ****************************/
        VS_CLASS_VIEW_CELL = '.app-item-template .app-view-cell',
        VS_CLASS_VIEW_TABLE = '.app-view-table',
        VS_CLASS_PRD_ID = '.app-prd-id';
    
    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************    
    function _getTarget(as_code) {
        return Mapping['Product'][as_code] || null;
    }
    
    function _getRefer(as_refer) {
        return Mapping['Handler'][as_refer] || null;
    }
    
    function _clear(ao_scope) {
        $(ao_scope.getPage()).find(VS_CLASS_VIEW_TABLE).empty();
    }
    
    function _show(aa_result, af_callback, ao_scope) {
        var lo_$viewPage = $(ao_scope.getPage()),
            lo_$viewTable = lo_$viewPage.find(VS_CLASS_VIEW_TABLE),
            lo_$viewCell = lo_$viewPage.find(VS_CLASS_VIEW_CELL);
            
        lo_$viewTable.empty();        
        
        if (CommonUtil.isValidArray(aa_result)) {
            $.each(aa_result, function(ai_index, ao_item) {
                _showItems(lo_$viewCell, lo_$viewTable, ao_item, af_callback, ao_scope);
            });
        } else {
            Message.showMuiInfoMsg(Constants.PS_MSG_NO_FOUND_RECORD, 'Message');
            //mui.toast(Constants.PS_MSG_NO_FOUND_RECORD);
            //_showItems(lo_$viewCell, lo_$viewTable, aa_result, af_callback, ao_scope);
        }
    }
    
    function _showItems(ao_viewCell, ao_viewTalbe, ao_result, af_callback, ao_scope) {
        var lo_$viewCellClone = ao_viewCell.clone(),
            lo_result;
            
        if (ao_result) {
            lo_result = ao_result;
            
            if (!CommonUtil.isValidObj(lo_result) && CommonUtil.isValidStr(lo_result)) {
                lo_result = JSON.parse(lo_result);
            }
        }
        
        if (lo_result) {
            lo_$viewCellClone.appendTo(ao_viewTalbe);
            
            if (af_callback) {
                af_callback.call(ao_scope, lo_$viewCellClone, lo_result);
            }
        }
    }
    
    function _showDetail(ao_result, af_callback, ao_scope) {
        var lo_$viewPage = $(ao_scope.getPage());
        
        if (ao_result) {
            if (af_callback) {
                af_callback.call(ao_scope, lo_$viewPage, ao_result)
            }
        }
    }

    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function Product() {
        this._url = '';
        this._ref = '';
        this._prdCode = '';
        
        this._vo = null;
        this._page = null;
        this._params = null;
        
        this._isLoaded = false;
        this._isCache = false;
        
        this._successCallback = undefined;
    }

    /**
     * Status prototype
     */
    Product.prototype = {
        constructor: Product,

        setPage : function(ao_page) {
            this._page = ao_page;
        },
        
        getPage : function() {
            return this._page;
        },
                
        setProductCode : function(as_code) {
            this._prdCode = as_code;
        },
        
        setLoaded : function(ab_isLoaded) {
            this._isLoaded = ab_isLoaded;
        },
        
        setRef : function(as_refer) {
            this._ref = as_refer;
        },
        
        getRef : function() {
            return this._ref;
        },
        
        setProductItemsCache : function(aa_cache) {
            this._prdItemsCache = aa_cache;
        },

        setVO : function(ao_vo) {
            this._vo = ao_vo;
        },
        
        getVO : function() {
            return this._vo;
        },
        
        addParam : function(as_key, ao_value) {
            if (!this._params) {
                this._params = new HashMap();
            }
            
            this._params.put(as_key, ao_value);
        },

        getParam : function(as_key) {
            if (this._params) {
                return this._params.get(as_key);
            } else {
                return null;
            }
        },
        
        getParams : function() {            
            return this._params;
        },
        
        setParams : function(ahm_params) {
            this._params = ahm_params;
        },
        
        isCache : function() {
            return this._isCache;
        },
        
        _loadJSON : function() {
            var lo_me = this,
                lo_result,
                ls_prdId;
            
            $.getJSON(lo_me._url)
                .done(function(ao_result) {
                    lo_result = ao_result;                                    
                    ls_prdId = lo_me.getParam(Constants.PS_KEY_PRD_ID);                

                    if (ls_prdId) {
                        lo_result = lo_result[ls_prdId];
                    }
                    
                    if (lo_me._successCallback) {
                        lo_me._successCallback(lo_result);                  
                    }
                    
                    lo_me._isLoaded = true;
                })
                .fail(function(ao_xmlHttpRequest, ao_textStatus, ao_errorThrown) {
                    Message.showMuiErrorMsg('Load file[' + lo_me._url + '] failure');				
                }
            ); 
        },
        
        _loadAjax : function(as_url) {
            var lo_me = this,
                lo_param = lo_me._params;
            
            if (lo_param) {
                lo_param = lo_param.getMap();
            }
            
            web.sendRestRequest(lo_me._url, lo_param, function(ao_result) {
                if (lo_me._successCallback) {
                    lo_me._successCallback(ao_result);
                }
                    
                lo_me._isLoaded = true;
            });
        },
        
        load: function() {                        
            if (this._isCache) {
                if (this._successCallback) {
                    this._successCallback(this._vo);                  
                }
            } else {
                _clear(this);
                
                if (this._url.indexOf('.json') >= 0) {
                    this._loadJSON();
                } else {
                    this._loadAjax();
                }                
            }           
        },
        
        preLoad : function() {
            var lo_target = _getTarget(this._prdCode),
                lo_refer = _getRefer(this._ref),
                ls_referUrl,
                ls_url;
            
            ls_referUrl = lo_refer['url'];            
            
            if (ls_referUrl === Constants.PS_CACHE) {
                this._isCache = true;
            } else {
                this._isCache = false;
                ls_url = eval(lo_target[ls_referUrl]);
                this._url = ls_url;
            }   

            this._successCallback = eval('this.' + lo_refer['method'] + '.bind(this)');
        },
        
        refresh : function() {
            if (!this._isLoaded) {
                this.preLoad();
            }
            
            this.load();
        },

        refreshPrdIds : function(ao_result) {
            _show(ao_result, this.showPrdIds, this);
        },
                
        refreshPrdIdItems : function(ao_result) {
            _show(ao_result, this.showPrdItems, this);
        },
        
        refreshPrdIdItem : function(ao_result) {
            _showDetail(ao_result, this.showPrdItem, this);
        },
        
        showPrdIds : function(ao_row, ao_item) {
            var ls_prdId = ao_item[Constants.PS_KEY_PRD_ID] || '';
            
            ao_row.find(VS_CLASS_PRD_ID).html(ls_prdId);
            ao_row.find('a').data('title', ls_prdId);
        },
        
        showPrdItems : function(ao_row, ao_item) {
            ao_row.find('a').data('title', 'Detail');
        },
        
        showPrdItem : function(ao_page, ao_item) {}
    };
    
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Product = Product;

}(window, jQuery));
