package com.excelhk.openapi.app;


import java.util.logging.Logger;

/**
 * Create by yyh on 2019/1/22
 */
public class AppLogger {

    private static Logger logger = Logger.getLogger(AppLogger.class.getSimpleName());

    public static void info(String message) {
        logger.info(message);
    }
}
