(function(window){
    'use strict';

    //******************************************************************************
    //*                             Config definitions                             *
    //******************************************************************************
    var SubConfig = {		
        PS_URL_GATEWAY : 'http://10.4.2.76:8082',
        //PS_URL_GATEWAY : 'http://118.143.64.116:9878',
        //PS_URL_AUTH : 'http://openapi.baidu.com/oauth/2.0/authorize',
        PS_URL_AUTH : 'http://10.4.2.76:8092/test/oauth/authorize',
        
        //PS_TOKEN_VAL_CLIENT_ID : 'q6pd7gLX1paTzBHxc3Iabvrx'
        PS_TOKEN_VAL_CLIENT_ID : 'CLIENT_TEST_ID_OAUTH2',
        PS_TOKEN_VAL_CLIENT_SECRET : 'excel'
    };
    
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.SubConfig = SubConfig;
}(window));