(function(window){
    'use strict';

    //******************************************************************************
    //*                             Mapping definitions                             *
    //******************************************************************************
    var Mapping = {		
        Product : {
            'DEPOSIT' : {
                'PRD_ID_PATH' : 'Config.PS_URL_DEPOSITS_PID',
                'PRD_DTL_PATH' : 'Config.PS_URL_DEPOSITS_DTL',
                'PRD_ID_JSON' : 'Config.PS_JSON_DEPOSITS_PID',
                'PRD_DTL_JSON' : 'Config.PS_JSON_DEPOSITS_DTL'
            },            
            'LOAN' : {
                'PRD_ID_PATH' : 'Config.PS_URL_LOANS_PID',
                'PRD_DTL_PATH' : 'Config.PS_URL_LOANS_DTL',
                'PRD_ID_JSON' : 'Config.PS_JSON_LOANS_PID',
                'PRD_DTL_JSON' : 'Config.PS_JSON_LOANS_DTL'
            }
        },
        Handler : {
            'REF_PRD_1' : {
                url : 'PRD_ID_PATH',
                method : 'refreshPrdIds'
            },
            'REF_PRD_2' : {
                url : 'PRD_DTL_PATH',
                method : 'refreshPrdIdItems'
            },
            'REF_PRD_3' : {
                url : 'CACHE',
                method : 'refreshPrdIdItem'
            },
        },
        Gateways : {
            'Gravitee' : {
                config : Config.PS_CFG_GIO
            },
            'Tyk' : {
                config : Config.PS_CFG_TYK
            } 
        },
        Pages : {
            'HOME' : '#app-page-home',
            'ME' : '#app-page-me',
            'ABOUT' : '#app-page-about',
            'SETTING' : '#app-page-setting',
            'DEPOSITS' : '#app-page-deposits',
            'LOANS' : '#app-page-loans'
        },
        Page : {
            'PAGE_HOME' : {
                pages : 'HOME',
                url : 'views/home.html'
            },
            'PAGE_ME' : {
                pages : 'ME',
                url : 'views/me.html'
            },
            'PAGE_ABOUT' : {
                pages : 'ABOUT',
                url : 'views/about.html'
            },
            'PAGE_SETTING' : {
                pages : 'SETTING',
                url : 'views/setting.html'
            },
            'PAGE_DEPOSITS' : {
                pages : 'DEPOSITS',
                url : 'views/deposits.html'
            },
            'PAGE_LOANS' : {
                pages : 'LOANS',
                url : 'views/loans.html'
            },
            'PAGE_APP' : {
                url : 'app.html'
            },
            'PAGE_LOGIN' : {
                url : 'login.html'
            }
        }
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Mapping = Mapping;
}(window));