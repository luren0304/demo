$(function (){
	'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

	var
        /********************* External reference ***************************/
        Constants = window.Constants,
        Store = window.Store,
        Mapping = window.Mapping,
        Config = window.Config,

        /********************* Internal static variable *********************/
        VS_ID_LOGIN_FORM = '#login-form',
        VS_ID_LOGIN_USER = '#app-login-username',
        VS_ID_LOGIN_PWD = '#app-login-password',
        VS_ID_LOGIN_SUBMIT = '#app-login-submit',
        VS_ID_LOGIN_ERR = '#app_login_error',
        VS_ID_LOGIN_MSG = '#app_error_msg',

        VS_MSG_EMPTY_NAME = 'Username cannot be empty',
        VS_MSG_EMPTY_PWD = 'Password cannot be empty',
        VS_MSG_NOT_FOUND_USER = 'Username or password incorrect',
        VS_MSG_BAD_CREDENTIAL = 'Username or password incorrect',

        VO_USER_STORE = Config.PO_USER_STORE,

        /********************* Internal variable ****************************/
        vs_urlProjectPath,
        vo_$error = null,
        vo_$errorMsg = null,
        vo_errorMsgData = {};

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************

    function _setProjectPath() {
        var l_location = document.location,
            ls_pathName = l_location ? l_location.pathname : '',
            ls_projectPath = ls_pathName.substring(1);

        vs_urlProjectPath = '/' + ls_projectPath.substring(0, ls_projectPath.indexOf('/'));
    }

    function _redirectPage(as_pageUrl, ab_external) {
        if (ab_external) {
            window.location.href = as_pageUrl;
        } else {
            window.location.href = vs_urlProjectPath + as_pageUrl;
        }
    }

    function _initErrorMsg() {
        vo_$error = $(VS_ID_LOGIN_ERR);
        vo_$errorMsg = $(VS_ID_LOGIN_MSG);

        vo_errorMsgData = {
            msg: '',
            field: null
        };
    }

    function _setErrorMsg(as_message, ao_$field) {
        vo_errorMsgData = {
            msg: as_message,
            field: ao_$field
        };
    }

    function _hideErrorMsg() {
        vo_$error.addClass('mui-hidden');
        vo_$error.fadeOut('fast');
    }

    function _showErrorMsg() {
        if ($.trim(vo_errorMsgData.msg).length > 0) {
            if (vo_errorMsgData.field) {
                vo_errorMsgData.field.focus();
            }

            vo_$errorMsg.html(vo_errorMsgData.msg);

            vo_$error.removeClass('mui-hidden');
        }

        _initErrorMsg();
    }

    function _validate() {
        var lo_$userName = $(VS_ID_LOGIN_USER),
            lo_$password = $(VS_ID_LOGIN_PWD),
            ls_userName = lo_$userName.val(),
            ls_password = lo_$password.val(),
            ls_userPassword,
            vo_store;

        if (ls_userName.trim().length < 1) {
            _setErrorMsg(VS_MSG_EMPTY_NAME, lo_$userName);

            return false;
        }

        if (ls_password.trim().length < 1) {
            _setErrorMsg(VS_MSG_EMPTY_PWD, lo_$password);

            return false;
        }

        ls_userPassword = VO_USER_STORE[ls_userName];

        if (ls_userPassword) {
            if (ls_userPassword !== ls_password) {
                _setErrorMsg(VS_MSG_BAD_CREDENTIAL);

                return false;
            } else {
                vo_store = new Store();

                if (vo_store.isValidStore()) {
                    vo_store.put(Constants.PS_KEY_USERNAME, ls_userName);
                }
            }
        } else {
            _setErrorMsg(VS_MSG_NOT_FOUND_USER);

            return false;
        }

        return true;
    }

    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Application constructor function
     *
     * @constructor
     */
    function Login(){
        _setProjectPath();

        _initErrorMsg();
    }

    /**
     * Application prototype
     */
    Login.prototype = {
        constructor: Login,

        submit: function(ao_event) {
            var ls_redirectPage,
                ls_dataPage;

            if (_validate()) {
                _hideErrorMsg();

                ls_dataPage = $(this).data('page');
                ls_redirectPage = Mapping.Page[ls_dataPage].url;

                window.location.href = ls_redirectPage;

                return false;
            } else {
                _showErrorMsg();

                return false;
            }
        }
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    (function main(){
        var lo_login = new Login(),
            lo_$loginForm = $(VS_ID_LOGIN_FORM),
            lo_$loginSubmit = $(VS_ID_LOGIN_SUBMIT);

        mui.init();

        lo_$loginForm.submit(lo_login.submit);

        lo_$loginSubmit.on('tap', function () {
            lo_$loginForm.submit();
        });

        lo_$loginForm.keyup(function(ao_event) {
            // Enter
            if (ao_event.keyCode === 13) {
                lo_$loginSubmit.trigger('tap');
            }
        });

        $(VS_ID_LOGIN_USER + ',' + VS_ID_LOGIN_PWD).keyup(function(ao_event){
            if ($.trim(ao_event.target.value).length > 0) {
                _hideErrorMsg();
            }
        });

        // When the IME(Input Method Editor) pops up, the page will moves up, close the IME, the page will moves down
        $('body').height($('body')[0].clientHeight);

        window.web = {};
        window.web.forcedBack = function() {
            mui.back();
        };
    }());
});
