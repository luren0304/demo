(function (window, document) {
	'use strict';

	//******************************************************************************
	//*                           Public function definitions                      *
	//******************************************************************************
	/**
	 * Store constructor function
	 *
	 * @constructor
	 */
	function Store() {
		this._store = window.localStorage;
	}

	/**
	 * Store prototype
	 */
    Store.prototype = {
		constructor: Store,
        
        put : function(as_key, as_value) {
            if (this.isValidStore()) {
                if (typeof as_value === 'object') {
                    this._store.setItem(as_key, JSON.stringify(as_value));
                } else {
                    this._store.setItem(as_key, as_value);
                }  
            }
        },
        
        get : function(as_key, ab_unserial) {
            var lo_value;
            
            if (this.isValidStore()) { 
                lo_value = this._store.getItem(as_key);
                
                if (lo_value && ab_unserial) {
                    lo_value = JSON.parse(lo_value);
                } 
            }
            
            return lo_value; 
        },

        remove : function(as_key) {
            if (this.isValidStore()) {
                if (as_key) {
                    this._store.removeItem(as_key);
                } else {
                    this._store.clear();
                }
            }
        },
        
        isValidStore : function() {
            return !!this._store;
        }
	};

	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
	window.Store = Store;

}(window, document));
