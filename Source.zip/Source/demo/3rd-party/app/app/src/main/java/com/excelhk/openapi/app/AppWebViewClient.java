package com.excelhk.openapi.app;

import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.logging.Logger;

/**
 * Create by yyh on 2018/12/25
 */
public class AppWebViewClient extends WebViewClient {

    private AppWebActivity v_activity;

    public AppWebViewClient(AppWebActivity a_activity) {
        v_activity = a_activity;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView a_view, String as_url) {
        a_view.loadUrl(as_url);

        // Support area link redirect page
        return true;
    }

    @Override
    public void onReceivedSslError(WebView a_view, SslErrorHandler a_sslErrorHandler, SslError a_error) {
        // Skipping the ssl verify
        a_sslErrorHandler.proceed();
    }

    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        super.onReceivedError(view, errorCode, description, failingUrl);

        gotoErrorPage(description, view);
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        final AppWebView l_view = (AppWebView) view;

        int li_viewContentHeight = l_view.getContentHeight();

        if (li_viewContentHeight == 0) {
            l_view.evaluateJavascript("javascript:document.getElementsByTagName('pre')[0].innerText", new ValueCallback<String>(){
                @Override
                public void onReceiveValue(String responseJson) {
                    if (responseJson != null && responseJson.contains("error")) {
                        gotoErrorPage(responseJson, l_view);
                    }
                }
            });
        }

        super.onPageFinished(view, url);
    }

    private void gotoErrorPage(String as_error, WebView view) {
        v_activity.setHasError(true);
        v_activity.setError(as_error);

        view.loadUrl("file:///android_asset/api-0.1.0.0/error.html");
    }
}
