(function (window, $, mui){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,                
        Module = topWindow.Module,
        Message = topWindow.Message,
        
        web = topWindow.web,
        Constants = topWindow.Constants,
        Config = topWindow.Config,
        StringUtil = topWindow.StringUtil,

	    /********************* Internal variable ****************************/                
        VS_ACCESS_TOKEN = 'access_token',
        VS_RESPONSE_TYPE = 'response_type',
        VS_CLIENT_ID = 'client_id',
        VS_CLIENT_SECRET = 'client_secret',
        VS_REDIRECT_URI = 'redirect_uri',
        VS_STATE = 'state',
        VS_USER = 'user',
        VS_AUTH_STATE = Config.PS_TOKEN_VAL_STATE,
        VS_AUTH_URL_CALLBACK = Config.PS_URL_AUTH_CALLBACK,

        vi_interval = 200,

        vo_token,
        vo_subWindow,
        vo_timer = null;

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************
    function _corsDomainMessage() {
        window.addEventListener('message', function(ao_event) {
            console.info('login-3rd.js receive message', ao_event.data);
            
            if (StringUtil.startWith(VS_AUTH_URL_CALLBACK, ao_event.origin)) {
                vo_token = _retrieveURIData(ao_event.data);
                
                if (Config.PS_TOKEN_VAL_STATE === vo_token[VS_STATE]) {
                    if (vo_token.error) {

                    } else {
                        if (_verifyToken()) {
                            vo_subWindow.postMessage('received', VS_AUTH_URL_CALLBACK);

                            _updateToken();
                        }
                    }
                } else {
                    console.info('login-3rd.js', vo_token[VS_STATE] + 'not same ' + Config.PS_TOKEN_VAL_STATE);
                }                
            }
        });
    }

    function _verifyToken() {
        return vo_token;
    }
    
    function _updateToken() {
        web.updateToken(vo_token);
        
        //web.reload();
    }
    
    function _showLogin(as_waringMessage) {
        var lo_subWindowPage,
            lo_$loginForm = _createLoginForm(),
            lo_loginForm = lo_$loginForm.get(0),
            lo_subWindowTimer,
            ls_subWindowName = 'bank';

        lo_loginForm.method = 'POST';
        lo_loginForm.action = web.getAuthUrl();
        lo_loginForm.target = ls_subWindowName;

        Message.showMuiWaringMsg(as_waringMessage, false, function () {
            web.showLoading('Waiting...');

            //vo_subWindow = window.open('blank.html', ls_subWindowName);
            vo_subWindow = window.open('', ls_subWindowName);

            lo_$loginForm.appendTo('body');

            lo_loginForm.submit();
            lo_$loginForm.remove();
        });

        _listenSubWindowIsClose();

        /*
        lo_subWindowTimer = setInterval(function() {
            if(vo_subWindow && vo_subWindow.closed) {
                clearInterval(lo_subWindowTimer);

                web.hideLoading();
                web.reload();
            }
        }, 500);
        */
    }

    function _listenSubWindowIsClose() {
        if(vo_subWindow && vo_subWindow.closed) {
            clearTimeout(vo_timer);

            vo_subWindow = null;
            vo_token = null;

            web.hideLoading();
            web.reload();
        } else {
            vo_timer = setTimeout(_listenSubWindowIsClose, vi_interval);
        }
    }
    
    function _createLoginForm() {
        var ls_url = web.getAuthUrl(),
            lo_$loginForm = $('<form></form>');
        
        //lo_urlParams[VS_CLIENT_SECRET] = Config.PS_TOKEN_VAL_CLIENT_SECRET;

        lo_$loginForm.append(_createHiddenChild(VS_CLIENT_ID, Config.PS_TOKEN_VAL_CLIENT_ID));
        lo_$loginForm.append(_createHiddenChild(VS_RESPONSE_TYPE, Config.PS_TOKEN_VAL_RESPONSE_TYPE));
        lo_$loginForm.append(_createHiddenChild(VS_REDIRECT_URI, VS_AUTH_URL_CALLBACK));
        lo_$loginForm.append(_createHiddenChild(VS_STATE, VS_AUTH_STATE));

        if (web.isAuthorized()) {
            lo_$loginForm.append(_createHiddenChild(VS_USER, web.getAuthUser()));
        }
        
        return lo_$loginForm;
    }

    function _createHiddenChild(as_name, as_value) {
        return $('<input type="hidden" name="'+ as_name + '" value="' + as_value + '">');
    }
    
    function _retrieveURIData(as_data) {
        var ls_data = as_data || '',
            la_data,
            la_param,
            lo_data;
        
        if (ls_data && ls_data.length > 0) {
            //ls_data = encodeURIComponent(ls_data);
            ls_data = ls_data.substr(1);
            
            la_data = ls_data.split('&') || [];
            la_data.length > 0 ? lo_data = {} : null;
            
            la_data.forEach(function(as_item, ai_index) {
                la_param = as_item.split('=');
                lo_data[la_param[0]] = encodeURIComponent(la_param[1]);
            });
        }
        
        return lo_data;
    }
    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function Login3rd() {
        _corsDomainMessage();
    }

    Login3rd.prototype = {
        constructor: Login3rd,

        login : function(ab_isExpired) {
            var ls_waringMessage = '';

            if (ab_isExpired) {
                ls_waringMessage = Constants.PS_MSG_REQ_EXPIRED_AUTH;
            } else {
                ls_waringMessage = Constants.PS_MSG_REQ_NO_AUTH;
            }

            _showLogin(ls_waringMessage);
        },

        getTimer : function() {
            return vo_timer;
        }
    };
   
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    (function main(){
        window.login3rd = new Login3rd;
    })();

}(window, jQuery, mui));
