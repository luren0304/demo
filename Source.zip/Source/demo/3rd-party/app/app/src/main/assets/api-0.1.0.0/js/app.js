(function (window, document, $, mui) {
	'use strict';

	//******************************************************************************
	//*   Variable definitions(include external reference and internal variable)   *
	//******************************************************************************
	var
	/********************* External reference ***************************/
	Config = window.Config,
	StringUtil = window.StringUtil,
    CommonUtil = window.CommonUtil,
    Constants = window.Constants,    
    Message = window.Message,
    Mapping = window.Mapping,
    Product = window.Product,
    Deposits = window.Deposits,
    Loans = window.Loans,
    Module = window.Module,
    About = window.About,
    Setting = window.Setting,
    AccessVO = window.AccessVO,
    
    androidJS = window.androidJS,
	/********************* Internal variable ****************************/
    VS_ID_MAIN = '#app-home',
    VS_ID_CONT_MAIN = '#app-cont-main',
    VS_ID_CONT_ME = '#app-cont-me',
    VS_ID_FOOTER_NAV = '#app-footer-nav',
    VS_ID_HEADER = '#app-header',
    VS_ID_NAV_LOGIN = '#app-nav-login',
    VS_ID_NAV_ME = '#app-nav-me',
    
    VS_ID_PAGES = '#app-pages',
    
    VS_CSS_PAGES = '.app-mui-pages',
    VS_CSS_PRD_PAGE_LINK = '.app-mui-page-content ul li a[data-ref*="PRD"]',
    VS_CSS_SINGLE_PAGE_LINK = '.app-mui-page-content ul li a[data-ref="SINGLE"]',
    VS_CSS_TITLE_CENTER = '.app-nav-title-center',
    VS_CSS_TITLE_LEFT = '.app-nav-title-left',
    VS_CSS_REFRESH = '.app-mui-navbar .app-btn-refresh',
    VS_CSS_CURRENT_WRAPPER = '.mui-page-center .app-scroll-wrapper',
    VS_CSS_ACTIVE_PAGE = '#app-footer-nav .mui-tab-item.mui-active',
    VS_CSS_FOOTER_NAV_ITEM = '#app-footer-nav .mui-tab-item',    
    VS_CSS_AVATAR_TABLE = '.app-view-avatar-table',    
    VS_CSS_AVATAR_LOGIN = '.app-avatar-login button',
    VS_CSS_AVATAR_USER = '.app-avatar-user',
    VS_CSS_AUTH_USER = '.app-auth-user',
    VS_CSS_USER = '.app-auth-user .app-user',
    VS_CSS_USER_LOGIN = '.app-userbar .app-user-login',

    VS_CSS_USER_AUTH_LOGIN = '.app-userbar .app-auth-login',
    VS_CSS_LOGOUT = '.app-logout',
    VS_CSS_LOGOUT_LINK = '.app-logout a',
    VS_CSS_LEFT_BAR_ICON = '.mui-icon-left-nav',
    VS_CSS_ICON = '.mui-icon.openapi',
    
    VS_STYLE_CSS_HIDE = 'mui-hidden',
    VS_STYLE_CSS_AUTH = 'app-auth',
    VS_STYLE_CSS_FULL = 'app-view-full',
    	
    vo_viewApi = null,
    vo_product = null,
    vo_module = null,
    vo_pagesMapping = Mapping.Pages,
    vo_pageMapping = Mapping.Page,
    
    vs_homeViewId = '',
    vs_currentTitle = '',
    vs_parentTitle = '',

    vb_duplicateClick = false,

    va_loadPages = [],
    va_accessHistory = [];

	//******************************************************************************
	//*                           Private function definitions                     *
	//******************************************************************************
    function _init() {
        _initPageContainer();
        
        _initActivePage(_initContext);                
    }
    
    function _initPageContainer() {
        var lo_pages = vo_pagesMapping,
            la_pageKeys = Object.keys(lo_pages) || [],
            ls_pageSelector = '',
            lo_$pages = $(VS_ID_PAGES);
        
        if (CommonUtil.isValidArray(la_pageKeys)) {
            la_pageKeys.forEach(function(as_key, ai_index) {
                ls_pageSelector = lo_pages[as_key];
                
                if (StringUtil.startWith(ls_pageSelector, '#')) {
                    ls_pageSelector = ls_pageSelector.substr(1);
                }
                
                lo_$pages.append('<div id="' + ls_pageSelector + '"></div>');
            });
        }
    }
    
    function _initActivePage(af_callback) {
        _loadDataPage($(VS_CSS_ACTIVE_PAGE), function() {
            _toggleFooterNavIcon();
            
            af_callback && af_callback();
        });
    }
    
    function _initContext() {   
        _initMui();
        
        _initMuiEvent();
        
        _initCustomEvent();                
    }
    
    function _initMui() {
        mui.init();

        vo_viewApi = mui(VS_ID_CONT_MAIN).view({
            defaultPage: VS_ID_MAIN
        });  
        
        vo_viewApi.isHome = true;       
    }
    
    function _initMuiEvent() {
        var lf_oldBack,
            lo_view,
            lo_$viewContainer = $(lo_view).parent();
                
        lo_view = vo_viewApi.view;
        lf_oldBack = mui.back;
        
        // Back event
        mui.back = function() {
            if (vo_viewApi.canBack()) {
                vo_viewApi.back();                                
            } else {
                //lf_oldBack();
                
                // Call android exit method
                if (androidJS) {
                    androidJS.exit();
                }

                vo_product = null;
                vo_module = null;
            }
        };

        // Before page show event
        $(lo_view).on('pageBeforeShow', _pageBeforeShow);
        
        // Page show evnet
        $(lo_view).on('pageShow', _pageShow);
        
        // Before page back event
        $(lo_view).on('pageBeforeBack', _pageBeforeBack);
        
        // Page back event
        $(lo_view).on('pageBack', _pageBack);

        vs_homeViewId = $(lo_view).data('view'); 

        _toogleLogin();
    }
            
    function _initCustomEvent() {                
        $(VS_CSS_PAGES).on('tap', VS_CSS_PRD_PAGE_LINK, function(ao_event) {
            var lo_$me = $(this);

            _loginControl(function() {
                lo_$me.attr('href', lo_$me.data('href'));

                _toggleFooterNav();

                _eventTarget(ao_event, _initProduct);
            });
        });
        
        $(VS_CSS_PAGES).on('tap', VS_CSS_SINGLE_PAGE_LINK, function(ao_event) {           
           _toggleFooterNav();
            
           _eventTarget(ao_event, _initModule);
        }); 
                                        
        $(VS_CSS_FOOTER_NAV_ITEM).on('tap', function(ao_event) {
            var lo_$target = $(ao_event.currentTarget),
                ls_container = lo_$target.attr('href'),
                ls_page = lo_$target.data('href'),
                ls_go = lo_$target.data('go'),
                ls_viewId = $(ls_container).data('view');
                
            if (ls_viewId) {
                vo_viewApi = mui.data[ls_viewId];                
            } else {
                _loadDataPage(lo_$target, function() {
                    vo_viewApi = mui(ls_container).view({
                        defaultPage: ls_page
                    });
                    
                    _initMuiEvent();
                });
            }
            
            _toggleFooterNavIcon(lo_$target);
        }); 

        $(VS_ID_CONT_MAIN).on('tap', VS_CSS_USER_LOGIN, function() {
            if (web.isLogin()) {
                _gotoMeView($(this));
            } else {
                _redirectLoginPage();
            }
        });
        
        $(VS_ID_CONT_ME).on('tap', VS_CSS_AVATAR_LOGIN, function(event) {
            _redirectLoginPage();
        });
        
        $(VS_ID_CONT_ME).on('tap', VS_CSS_LOGOUT_LINK, function() {
            Message.showMuiConfirmMsg(Constants.PS_MSG_CFG_LOGOUT, 'Confirm', function(ao_event) {
                web.updateToken();

                web.updateUser();

                //web.reload();

                _redirectLoginPage();
            });
        });
    }
            
    function _pageBeforeShow() {
        var ls_parentTitle,
            lo_$activeNavbar = $(vo_viewApi.activeNavbar),
            lo_$previousNavbar = $(vo_viewApi.previousNavbar),
            lo_access,
            lo_currentPage;

        if (vo_viewApi.isBack) {
            lo_currentPage = vo_viewApi.previousPage;                        
        } else {
            ls_parentTitle = lo_$previousNavbar.find(VS_CSS_TITLE_CENTER).text();
            
            lo_$activeNavbar.find(VS_CSS_TITLE_LEFT).text(vs_currentTitle);
            
            lo_currentPage = vo_viewApi.activePage;            
        }
        
        if (vo_product) {
            vo_product.setPage(lo_currentPage);
            vo_product.refresh(); 
        }
        
        if (vo_module) {            
            vo_module.setPage(lo_currentPage);
            vo_module.init();
            vo_module.refresh();
        }
    }
    
    function _pageShow() {
        var lo_access;

        if (!vo_viewApi.isBack) {
            if (vo_product) {
                lo_access = null;
                lo_access = new AccessVO();  
                lo_access.setRef(vo_product.getRef());
                lo_access.setParamObj(_clone(vo_product.getParams()));
                
                va_accessHistory.push(lo_access);
            }
        }

        _initPullRefresh();
    }
    
    function _pageBeforeBack() {
        var lo_access;
        
        // Home page
        if (!CommonUtil.isValidArray(vo_viewApi.history)) {
            vo_product = null;
            vo_module = null;
            
            _toggleFooterNav(true);

            web.setHash('');
        } else {
            if (CommonUtil.isValidArray(va_accessHistory)) {
                 va_accessHistory.pop();
            
                if (vo_product) {
                    lo_access = va_accessHistory[va_accessHistory.length - 1];
                    
                    vo_product.setLoaded(false);
                    vo_product.setRef(lo_access.getRef());
                    vo_product.setParams(_clone(lo_access.getParamObj()));
                }
            }

            web.setHash(vo_viewApi.previousPage.id);
        }

        _toogleLogin();
    }
    
    function _pageBack() {
        var la_history = vo_viewApi.history;
    }

    function _loginControl(af_callback) {
        if (web.isLogin()) {            
            if (web.isAuthorized() && !web.isExpiredToken()) {
                af_callback && af_callback();
            } else {
                _gotoAuthLogin();
            }            
        } else {
            _redirectLoginPage();
        }
    }
    
    function _gotoAuthLogin() {
        var lb_tokenIsExpired = web.isExpiredToken();
        //web.updateToken();

        login3rd.login(web.isExpiredToken());
    }
    
    function _gotoMeView(ao_target) {
        var lo_$target = $(ao_target);
        
        lo_$target.data('page', 'PAGE_ME');
        
        _gotoView(lo_$target, VS_ID_NAV_ME);
        
        _toggleFooterNav(true);
    }
    
    function _gotoView(ao_target, as_targetFooterNav) {
        var lo_targetTab = $(as_targetFooterNav).get(0);
        
        _loadDataPage(ao_target, function() {            
            mui.trigger(lo_targetTab, mui.EVENT_START);
            mui.trigger(lo_targetTab, 'tap');
        });
    }


    function _redirectLoginPage() {
        _redirectPage('PAGE_LOGIN');
    }

    function _redirectPage(as_dataPage) {
        var lo_page = vo_pageMapping[as_dataPage];

        if (lo_page) {
            window.location.href = lo_page['url'];
        }
    }

    //******************************************************************************
	//*                           Private Common definitions                       *
	//******************************************************************************
    function _loadDataPage(ao_target, af_callback) {
        var lo_$target,
            ls_page;
        
        if (ao_target) {
            lo_$target = $(ao_target);
            
            ls_page = lo_$target.data('page');
            
            if (ls_page) {
                if (va_loadPages.indexOf(ls_page) < 0) {
                    _loadPage(ls_page, af_callback);
                } else {
                    af_callback && af_callback();
                }
            } else {
                af_callback && af_callback();
            }
        }
    }
    
    function _loadPage(as_dataPage, af_callback) {
        var lo_page = vo_pageMapping[as_dataPage],
            ls_pageRef,
            ls_selector,
            ls_pageUrl;
        
        if (lo_page) {
            ls_pageRef = lo_page['pages'];
            ls_pageUrl = lo_page['url'];
            
            if (ls_pageRef) {
                ls_selector = vo_pagesMapping[ls_pageRef];
            }
        }
        
        if (ls_selector && ls_pageUrl) {
            $(ls_selector).load(ls_pageUrl, function() {
                va_loadPages.push(as_dataPage);
                
                af_callback && af_callback();
            });
        }
    }
    
    function _initPullRefresh() {
        mui(VS_CSS_CURRENT_WRAPPER).pullRefresh({
            down: {
                style: 'circle',
                contentinit: Constants.PS_MSG_PULLDOWN_REFERSH,
                contentdown: Constants.PS_MSG_PULLDOWN_REFERSH,
                contentover: Constants.PS_MSG_RELEASE_REFERSH,
                contentrefresh: Constants.PS_MSG_LOADING,
                callback: _pulldownRefresh
            }
        }); 
    }
    
    function _pullupRefresh() {
        var lo_me = this;
        lo_me.endPullupToRefresh(false);
        
        setTimeout(function() {            
            if (vo_product) {
                vo_product.setLoaded(true);
                vo_product.refresh();
            }
                      
            mui.toast(Constants.PS_MSG_RECORD_UPDATED);
        }, 1000);        
    }
    
    function _pulldownRefresh() {
        var lo_me = this;
        
        setTimeout(function() {            
            if (vo_product) {
                vo_product.setLoaded(true);
                vo_product.refresh();
            }
            
            lo_me.endPulldownToRefresh();                        
            //mui.toast(Constants.PS_MSG_RECORD_UPDATED);
        }, 1000);        
    }
    
    function _toggleFooterNavIcon(ao_target) {
        var ls_IconClass = '',
            ls_fillIconClass = '',
            lo_$footerActiveNav = ao_target ? $(ao_target) : $(VS_CSS_ACTIVE_PAGE),
            lo_$footerNavIcon = $(VS_CSS_FOOTER_NAV_ITEM).find(VS_CSS_ICON),
            lo_$footerActiveNavIcon = lo_$footerActiveNav.find(VS_CSS_ICON);
        
            lo_$footerNavIcon.each(function() {
                ls_IconClass = $(this).data('style');
                ls_fillIconClass = ls_IconClass + '-filled';
                
                $(this).removeClass(ls_fillIconClass);
                $(this).addClass(ls_IconClass);
            });
            
            ls_IconClass = lo_$footerActiveNavIcon.data('style');
            ls_fillIconClass = ls_IconClass + '-filled';
            
            lo_$footerActiveNavIcon.removeClass(ls_IconClass);
            lo_$footerActiveNavIcon.addClass(ls_fillIconClass);
    }
    
    function _toggleFooterNav(ab_remove) {
        _toogleClass(VS_ID_FOOTER_NAV, VS_STYLE_CSS_HIDE, ab_remove);
    }
    
    function _toogleHeader(ab_remove) {
        _toogleClass(VS_ID_HEADER, VS_STYLE_CSS_HIDE, ab_remove);
        _toogleClass(vo_viewApi.view, VS_STYLE_CSS_FULL, ab_remove);
    }

    function _toogleLogin() {
        var lb_isLogin = web.isLogin(),
            lb_isAuthorized = web.isAuthorized(),
            lo_view = vo_viewApi.view,
            lo_$avatarTarget = $(lo_view).find(VS_CSS_AVATAR_TABLE),
            lo_$logoutTarget = $(lo_view).find(VS_CSS_LOGOUT),
            lo_$avatarUser = lo_$avatarTarget.find(VS_CSS_AVATAR_USER);
        
        _toogleClass(lo_$avatarTarget, VS_STYLE_CSS_AUTH, !lb_isLogin);
        
        _toogleClass(lo_$logoutTarget, VS_STYLE_CSS_HIDE, lb_isLogin);

        if (lb_isLogin) {
            lo_$avatarUser.html(web.getUsername());
        }

        if (lb_isAuthorized) {
            $(lo_view).find(VS_CSS_USER).attr('data-content', web.getAuthUser());
            _toogleClass($(lo_view).find(VS_CSS_AUTH_USER), VS_STYLE_CSS_HIDE, lb_isAuthorized);
            _toogleClass($(lo_view).find(VS_CSS_PRD_PAGE_LINK), VS_STYLE_CSS_AUTH, !lb_isAuthorized);
        }
    }
    
    function _toogleClass(as_selector, as_class, ab_remove) {
        var lo_$target = $(as_selector),
            lb_hasCls;
        
        if (lo_$target.length > 0) {
            lb_hasCls = lo_$target.hasClass(as_class);
            
            if (ab_remove) {
                if (lb_hasCls) {
                    lo_$target.removeClass(as_class);
                }
            } else {
                if (!lb_hasCls) {
                    lo_$target.addClass(as_class);
                }
            }
        }
    }    
        
    function _eventTarget(ao_event, af_callback) {
        var lo_target = ao_event.target,
            lo_currentTarget = ao_event.currentTarget,
            lo_$currentTarget;
            
        if (lo_target && lo_target.tagName === 'A') {
            lo_currentTarget = lo_target;
        }
        
        if (lo_currentTarget && lo_currentTarget.tagName === 'A') {                     
            _loadDataPage(lo_currentTarget, function() {
                af_callback && af_callback(lo_currentTarget);
                                
                vo_viewApi.go($(lo_currentTarget).attr('href'));

                web.setHash($(lo_currentTarget).attr('href'));
            });                       
        } else {
            vs_currentTitle = '';
        } 
        
        // Prevent events bubbles
        return false;
    }
    
    function _initProduct(ao_target) {
        var ls_prdCode,
            ls_key,
            ls_refer,
            lo_$currentTarget = $(ao_target);
        
        ls_prdCode = lo_$currentTarget.data('prd');
        ls_refer = lo_$currentTarget.data('ref');
        ls_key = lo_$currentTarget.data('title');
        
        vs_currentTitle = ls_key;

        if (!vo_product) {
            vo_product = _createProduct(ls_prdCode);
        } else {
            vo_product.addParam(Constants.PS_KEY_PRD_ID, ls_key);
        }
        
        if (vo_product && vo_product instanceof Product) {
            vo_product.setLoaded(false);
            vo_product.setRef(ls_refer);
        }
    }
    
    function _createProduct(as_prdCode) {
        var lo_product;
        
        switch(as_prdCode) {
            case Constants.PS_PRD_DEPOSITS:
                lo_product = new Deposits();
                break;
            case Constants.PS_PRD_LOANS:
                lo_product = new Loans();                
                break;                        
        }
        
        if (lo_product) {
            lo_product.setProductCode(as_prdCode);
        }
        
        return lo_product;
    }
    
    function _initModule(ao_target) {
        var ls_mdlCode,
            ls_key,
            ls_refer,
            lo_$currentTarget = $(ao_target);
        
        ls_mdlCode = lo_$currentTarget.data('mdl');
        ls_refer = lo_$currentTarget.data('ref');
        ls_key = lo_$currentTarget.data('title');
        
        vs_currentTitle = ls_key;

        if (!vo_module) {
            vo_module = _createModule(ls_mdlCode);
        } 
    }
    
    function _createModule(as_mdlCode) {
        var lo_module;
        
        switch(as_mdlCode) {
            case Constants.PS_MDL_ABOUT:
                lo_module = new About();
                break;
            case Constants.PS_MDL_SETTING:
                lo_module = new Setting();                
                break;
        }
        
        if (lo_module) {
            lo_module.setModuleCode(as_mdlCode);
        }
        
        return lo_module;
    }
  
    function _clone(ao_target) {
        if (ao_target) {
            return $.extend(true, {}, ao_target);
        } else {
            return null;
        }        
    }
	//******************************************************************************
	//*                           Public function definitions                      *
	//******************************************************************************
    function App() {
        _init();    
	}
    
    App.prototype = {
        constructor : App,
        
        gotoAuthLogin : function() {
           _gotoAuthLogin();
        },

        productReload : function () {
            if (vo_product) {
                vo_product.setLoaded(true);
                vo_product.refresh();
            }
        }
    };
    
	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
    (function main() {        
        window.app = new App();
    }());
}(window, document, jQuery, mui));
