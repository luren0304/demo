(function(window){
    'use strict';

    //******************************************************************************
    //*                             Config definitions                             *
    //******************************************************************************
    var SubConfig = {		
        //PS_URL_GATEWAY : 'https://www.excelopenapi.com:9879',
        //PS_URL_GATEWAY : 'https://118.143.64.116:9879',
	PS_URL_GATEWAY : 'https://218.17.142.44:3001',

        PS_URL_AUTH : '/testoauthdemo/oauth/authorize',
        
        PS_TOKEN_VAL_CLIENT_ID : '758f0cf25fc348668f772867865ac0cb',
        PS_TOKEN_VAL_CLIENT_SECRET : 'NTcyYWJhOGEtMDM4MS00Y2MzLTgxNWUtYjAxMjAyMjEwZGQ1'
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.SubConfig = SubConfig;
}(window));