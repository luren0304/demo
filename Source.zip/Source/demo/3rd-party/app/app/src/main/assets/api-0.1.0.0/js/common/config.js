(function(window){
    'use strict';

    //******************************************************************************
    //*                             Config definitions                             *
    //******************************************************************************
    var Constants = window.Constants,    
        Config = {		
            PS_URL_GATEWAY : '',
            PS_URL_AUTH : '',
            PS_URL_LOGOUT : '/logout',
            //PS_URL_AUTH_CALLBACK : 'http://10.4.2.141:9090/openapi/callback',
            PS_URL_AUTH_CALLBACK : 'https://218.17.142.44:3001/callback-service/callback',
            PS_URL_DEPOSITS_PID : '/deposits/prod',
            PS_URL_DEPOSITS_DTL : '/deposits/one/{prodId}',
            PS_URL_LOANS_PID : '/loans/prod',
            PS_URL_LOANS_DTL : '/loans/one/{prodId}',
            
            PS_JSON_DEPOSITS_PID : 'files/deposits-id.json',
            PS_JSON_DEPOSITS_DTL : 'files/deposits-dtl.json',
            PS_JSON_LOANS_PID : 'files/loans-id.json',
            PS_JSON_LOANS_DTL : 'files/loans-dtl.json', 
            
            PS_TOKEN_VAL_RESPONSE_TYPE : 'token',
            PS_TOKEN_VAL_STATE : 'openapi',
            PS_TOKEN_VAL_CLIENT_ID : '',
            PS_TOKEN_VAL_CLIENT_SECRET : '',
            PS_ACCESS_TOKEN : '',
            
            PS_DEFAULT_GW : Constants.PS_GATEWAY_TYK,
            PS_DEFAULT_CONN : Constants.PS_CONN_DB,

            PS_CFG_TYK : 'js/common/config-tyk.js',
            PS_CFG_GIO : 'js/common/config-gio.js',
            
            PS_VERSION : '0.1.3.3',
            
            PI_REQ_TIMEOUT : 20000,
            PI_REQ_TIMEOUT_LONG : 600000,

            PO_USER_STORE : {
                'user01' : 'user01',
                'user02' : 'user02',
                'user03' : 'user03',
                'user04' : 'user04',
                'user05' : 'user05',
                'user06' : 'user06',
                'user07' : 'user07',
                'user08' : 'user08',
                'user09' : 'user09',
                'user10' : 'user10'
            },

            PB_IS_DEBUG : true
        };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Config = Config;
}(window));