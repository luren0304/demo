package com.excelhk.openapi.app;


import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;


public class MainActivity extends AppWebActivity {

    private final String VS_JS_ANDROID = "androidJS";

    private AppWebView v_mainWebView;
    private AppWebView v_subWebView;

    private AppWebInterface v_jsWebInterface;

    private MainActivity v_mainActivity;

    ConstraintLayout layout;
    ConstraintLayout.LayoutParams layoutParams;

    @Override
    protected void onCreate(@Nullable Bundle a_savedInstanceState) {
        super.onCreate(a_savedInstanceState);

        v_mainActivity = this;

        v_jsWebInterface = new AppWebInterface(v_mainActivity);

        v_mainWebView = new AppWebView(this);
        v_mainWebView.setWebInterface(VS_JS_ANDROID, v_jsWebInterface);
        v_mainWebView.setViewUrl("file:///android_asset/api-0.1.0.0/index.html");

        v_mainWebView.initDefaultApiView();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            WebView.setWebContentsDebuggingEnabled(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(v_mainWebView, true);
        }

        v_mainWebView.setWebViewClient(new AppWebViewClient(v_mainActivity));

        v_mainWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView a_view, boolean a_isDialog, boolean a_isUserGesture, Message a_resultMsg) {
                v_subWebView = new AppWebView(a_view.getContext());

                v_subWebView.setWebInterface(VS_JS_ANDROID, v_jsWebInterface);
                v_subWebView.initDefaultApiView();

                v_subWebView.setWebViewClient(new AppWebViewClient(v_mainActivity));
                v_subWebView.setWebChromeClient(this);

                layout.addView(v_subWebView, layoutParams);

                WebView.WebViewTransport transport = (WebView.WebViewTransport) a_resultMsg.obj;
                transport.setWebView(v_subWebView);
                a_resultMsg.sendToTarget();

                setCurrentWebView(v_subWebView);

                return true;
            }

            @Override
            public void onCloseWindow(WebView a_webView) {
                if (v_subWebView != null) {
                    v_subWebView.setVisibility(View.GONE);

                    if (layout != null) {
                        layout.removeView(v_subWebView);
                    }

                    v_subWebView.destroy();

                    v_subWebView = null;

                    setCurrentWebView(v_mainWebView);
                }
            }
        });

        setCurrentWebView(v_mainWebView);

        //setContentView(v_mainWebView);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        setContentView(R.layout.activity_main);
        layout = findViewById(R.id.activity_main);

        layoutParams = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        layout.addView(v_mainWebView, layoutParams);
    }
}


