package com.excelhk.openapi.app;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

/**
 * Create by yyh on 2018/10/31
 */
public abstract class AppWebActivity extends AppCompatActivity {

    private AppWebView v_currentWebView;

    private String vs_error;

    private boolean vb_hasError = false;

    @Override
    public void onBackPressed() {
        if (v_currentWebView != null) {
            v_currentWebView.loadUrl(buildUrlScript("web.forcedBack()"));
        }
    }

    @Override
    protected void onDestroy() {
        if (v_currentWebView != null) {
            v_currentWebView.removeWebInterface();
            v_currentWebView.removeAllViews();
            v_currentWebView.destroy();

            v_currentWebView = null;
        }

        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration a_newConfig) {
        if (a_newConfig.fontScale != 1) {
            getResources();
        }

        super.onConfigurationChanged(a_newConfig);
    }

    @Override
    public Resources getResources() {
        Resources l_resource = super.getResources();
        Configuration l_newConfig = new Configuration();

        if (l_resource.getConfiguration().fontScale != 1) {
            //l_newConfig.setToDefaults();
            l_newConfig.fontScale = 1;
            l_resource.updateConfiguration(l_newConfig, l_resource.getDisplayMetrics());
        }

        return l_resource;
    }


    public String buildUrlScript(String as_method) {
        return "javascript:window." + as_method;
    }

    public AppWebView getCurrentWebView() {
        return v_currentWebView;
    }

    public void setCurrentWebView(AppWebView a_currentWebView) {
        this.v_currentWebView = a_currentWebView;
    }

    public void showToken(String as_content) {
        Toast.makeText(this.getApplicationContext(), as_content, Toast.LENGTH_SHORT).show();
    }

    public boolean hasError() {
        return vb_hasError;
    }

    public void setHasError(boolean ab_error) {
        vb_hasError = ab_error;
    }

    public String getError() {
        return vs_error;
    }

    public void setError(String as_error) {
        vs_error =  as_error;
    }
}
