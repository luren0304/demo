package com.excelhk.openapi.app;

import android.util.DisplayMetrics;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/**
 * Create by yyh on 2018/10/29
 */
public class AppWebInterface {

    private final long VL_DURATION_TIME = 800L;

    private AppWebActivity v_activity;
    private long vl_currentTime;
    private DisplayMetrics v_display;

    private Toast v_toast;

    AppWebInterface(AppWebActivity a_activity) {
        v_activity = a_activity;
        v_display = v_activity.getResources().getDisplayMetrics();
    }

    @JavascriptInterface
    public void exit() {
        if(System.currentTimeMillis() - vl_currentTime < VL_DURATION_TIME) {
            if (v_toast != null) {
                v_toast.cancel();
            }

            v_activity.finish();
        } else {
            vl_currentTime = System.currentTimeMillis();

            showToken("Press back again to exit the app!");
        }
    }

    @JavascriptInterface
    public String getError() {
        String  ls_error = "";

        if (v_activity.hasError()) {
            ls_error = v_activity.getError();

            //v_activity.setHasError(false);
            //v_activity.setError("");
        }

        return ls_error;
    }

    @JavascriptInterface
    public int getDpi() {
        return v_display.densityDpi;
    }

    @JavascriptInterface
    public int getHeight() {
        return v_display.heightPixels;
    }

    @JavascriptInterface
    public int getWidth() {
        return v_display.widthPixels;
    }

    private void showToken(String as_content) {
        if (v_activity != null) {
            v_activity.showToken(as_content);
            //Toast.makeText(v_activity.getApplicationContext(), as_content, Toast.LENGTH_SHORT).show();
        }
    }
}
