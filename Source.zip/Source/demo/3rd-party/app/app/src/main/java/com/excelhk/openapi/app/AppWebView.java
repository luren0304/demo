package com.excelhk.openapi.app;

import android.content.Context;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Create by yyh on 2018/10/31
 */
public class AppWebView extends WebView {
    private String vs_viewName;
    private String vs_viewUrl;
    private String vs_jsInterfaceName;

    private AppWebInterface v_webInterface;
    private WebSettings v_webSettings;

    public AppWebView(Context a_context) {
        super(a_context);
    }

    public AppWebView(Context a_context, String as_viewName) {
        super(a_context);

        vs_viewName = as_viewName;
    }

    public void initDefaultApiView() {
        v_webSettings = getSettings();

        initDefaultWebSettings();

        // Support use the js call the interface method
        if (v_webInterface != null) {
            addJavascriptInterface(v_webInterface, vs_jsInterfaceName);
        }

        // Load the html by the web view
        if (vs_viewUrl != null && vs_viewUrl.length() > 0) {
            loadUrl(vs_viewUrl);
        }

        requestFocusFromTouch();

        // Open inner link will not dispatch to outer browser
        setWebViewClient(new WebViewClient());
        setWebChromeClient(new WebChromeClient());
    }

    public WebSettings getWebSettings() {
        return v_webSettings;
    }

    public String getViewName() {
        return vs_viewName;
    }

    public void setViewName(String as_viewName) {
        this.vs_viewName = as_viewName;
    }

    public void setViewUrl(String as_url) {
        vs_viewUrl = as_url;
    }

    public void setWebInterface(String as_jsInterfaceName, AppWebInterface a_jsInterface) {
        vs_jsInterfaceName = as_jsInterfaceName;
        v_webInterface = a_jsInterface;
    }

    public void removeWebInterface() {
        if (vs_jsInterfaceName != null) {
            removeJavascriptInterface(vs_jsInterfaceName);
        }
    }

    public void initDefaultWebSettings() {

        if (v_webSettings != null) {
            v_webSettings.setTextZoom(100);

            // Support execute the javascript
            v_webSettings.setJavaScriptEnabled(true);

            // Support allow the local file
            v_webSettings.setAllowFileAccess(true);
            v_webSettings.setAllowFileAccessFromFileURLs(true);
            //v_webSettings.setAllowContentAccess(true);

            // Support use local store
            v_webSettings.setDomStorageEnabled(true);

            // Other Setting
            v_webSettings.setSupportMultipleWindows(true);
            //v_webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
            v_webSettings.setUseWideViewPort(true);
            v_webSettings.setLoadWithOverviewMode(true);
            v_webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
            //v_webSettings.setLoadsImagesAutomatically(true);
        }
    }

    public class ApiWebLayoutParams extends ViewGroup.MarginLayoutParams {

        public ApiWebLayoutParams() {
            super(MATCH_PARENT, MATCH_PARENT);
        }
    }
}