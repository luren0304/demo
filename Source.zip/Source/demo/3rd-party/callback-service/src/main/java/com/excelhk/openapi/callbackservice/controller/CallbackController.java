package com.excelhk.openapi.callbackservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.PostConstruct;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class CallbackController {

    private static final String VS_CLASS_NAME = CallbackController.class.getName();

    @Autowired
    Environment environment;

    @RequestMapping("/callback")
    public String callbackPage(HttpServletRequest request, HttpServletResponse response) {

        System.out.println(VS_CLASS_NAME + " - callbackPage ...");

        Cookie[] l_requestCookies = request.getCookies();
        Cookie l_requestCookie = null;

        String ls_cookieName;
        String ls_cookieDomain;
        String ls_cookiePath;

        try {
            if (l_requestCookies != null) {
                for (Cookie l_cookie : l_requestCookies) {
                    ls_cookieName = l_cookie.getName();
                    ls_cookieDomain = (l_cookie.getDomain() == null) ? request.getRemoteHost() : l_cookie.getDomain();
                    ls_cookiePath = (l_cookie.getPath() == null) ? request.getContextPath() : l_cookie.getPath();

                    System.out.println(VS_CLASS_NAME + " - callbackPage : cookie name = " + ls_cookieName);
                    System.out.println(VS_CLASS_NAME + " - callbackPage : cookie domain = " + ls_cookieDomain);
                    System.out.println(VS_CLASS_NAME + " - callbackPage : cookie path = " + ls_cookiePath);
                    System.out.println(VS_CLASS_NAME + " - callbackPage : cookie value = " + l_cookie.getValue());

                    if ("JSESSIONID".equals(ls_cookieName)) {
                        l_requestCookie = new Cookie(ls_cookieName, "");
                        l_requestCookie.setMaxAge(0);
                        l_requestCookie.setDomain(ls_cookieDomain);
                        l_requestCookie.setPath(ls_cookiePath);

                        response.addCookie(l_requestCookie);

                        System.out.println(VS_CLASS_NAME + " - callbackPage : set cookie [JSESSIONID] is expired!");
                    } else {
                        System.out.println(VS_CLASS_NAME + " - callbackPage : passed ");
                    }
                }
            } else {
                System.out.println(VS_CLASS_NAME + " - callbackPage : none cookie!");
            }

            return "callback.html";
        } catch (Exception a_exception) {
            a_exception.printStackTrace();

            return a_exception.getMessage();
        }
    }
}
