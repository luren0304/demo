package com.excelhk.openapi.callbackservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenapiCallbackApplication {

    public static void main(String[] args) {
        SpringApplication.run(OpenapiCallbackApplication.class, args);
    }
}
