# import fieldMapping collection
mongoimport -d excel-demo -c fieldMapping --file excel-demo-fieldMapping.json