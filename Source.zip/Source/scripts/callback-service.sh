# define
JENKINS_JAR_HOME=${WORKSPACE}/OpenAPI/Source/demo/3rd-party/callback-service/build/libs
echo $JENKINS_JAR_HOME
DOCKERFILE_HOME=${WORKSPACE}/OpenAPI/Source/dockerfile/callback-service
echo $DOCKERFILE_HOME
HARBOR_IP='10.4.2.76'
echo $HARBOR_IP
REPOSITORIES='openapi/callback-service'
echo $REPOSITORIES
HARBOR_USER='admin'
HARBOR_USER_PWD='Harbor12345'
echo $HARBOR_USER
echo $HARBOR_USER_PWD

echo "build_tag" ${build_tag}


cp -f ${JENKINS_JAR_HOME}/*.jar ${DOCKERFILE_HOME}/callback-service.jar
docker login -u ${HARBOR_USER} -p ${HARBOR_USER_PWD} ${HARBOR_IP}
IMAGE_ID=`docker images |grep ${REPOSITORIES} | awk '{print $3}'`
echo IMAGE_ID=$IMAGE_ID
if [ -n "$IMAGE_ID" ]
 then
 echo "callback-service ------------- remove image"
  docker rmi $IMAGE_ID
fi
cd ${DOCKERFILE_HOME}
TAG=`date +%Y%m%d-%H%M%S`
echo $TAG
echo "callback-service -------------  build image"
docker build -t ${HARBOR_IP}/${REPOSITORIES}:<BUILD_TAG> .
echo "callback-service ------------- push to harbor"
docker push ${HARBOR_IP}/${REPOSITORIES}:<BUILD_TAG>
echo "callback-service ------------- push end"