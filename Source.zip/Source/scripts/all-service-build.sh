# build jars
# build bank-user-service-adapter
 cd ${WORKSPACE}/OpenAPI/Source/security/bank-user-service-adapter/ 
pwd
#ls
#chmod +x gradlew
#./gradlew clean bootjar
gradle clean bootjar
# build client-register-service
 cd ${WORKSPACE}/OpenAPI/Source/security/client-register-service/ 
pwd
#ls
#chmod +x gradlew
#./gradlew clean bootjar
gradle clean bootjar
# build user-certification-service
 cd ${WORKSPACE}/OpenAPI/Source/security/user-certification-service/ 
pwd
#ls
#chmod +x gradlew
#./gradlew clean bootjar
gradle clean bootjar
# build demo-service
 cd ${WORKSPACE}/OpenAPI/Source/demo/demo-service/
pwd
#ls
#chmod +x gradlew
#./gradlew clean bootjar
gradle clean bootjar
# build callback-service
 cd ${WORKSPACE}/OpenAPI/Source/demo/3rd-party/callback-service/
pwd
#ls
#chmod +x gradlew
#./gradlew clean bootjar
gradle clean bootjar

