# define
K8S_CONFIG_HOME=${WORKSPACE}/OpenAPI/Source/k8s-config/demo-service
DEPLOYMENT_DEMO='demo-service'

DEPLOYMENT_NAME=`kubectl get deployment |grep 'mongodb' | awk '{print $1}'`
if [ -z "$DEPLOYMENT_NAME" ]
then
    cd ${K8S_CONFIG_HOME}
    kubectl apply -f mongodb.yaml
else
    STATUS=`kubectl get deployment |grep 'mongodb' | awk '{print $4}'`
    echo STATUS=$STATUS
    
    if [ $STATUS = 0 ]
    then 
       echo 'mongodb deployment failed, reset the image'
       kubectl set image deployment/mongodb mongodb=10.4.2.76/openapi/demo-service-mongo
    fi   
fi
DEPLOYMENT_NAME=`kubectl get deployment |grep 'demo-service' | awk '{print $1}'`

if [ -n "$DEPLOYMENT_NAME" ]
then
    # upgrade
    kubectl set image deployment/demo-service demo-service=10.4.2.76/openapi/demo-service:<BUILD_TAG>
else
    cd ${K8S_CONFIG_HOME}
    kubectl apply -f demo.yaml
fi
:<<!
for file in ${K8S_CONFIG_HOME}/*.yaml
do 
    echo $file 
       
    kubectl apply -f $file
done
!
#cd ${K8S_CONFIG_HOME}
#kubectl apply -f demo.yaml
#kubectl apply -f mongodb.yaml
