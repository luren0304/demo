./bank-user-service-adapter.sh
./callback-service.sh
./client-register-service.sh
./demo-service.sh
./user-certification-service.sh