(function (window, document, $) {
	'use strict';

	//******************************************************************************
	//*   Variable definitions(include external reference and internal variable)   *
	//******************************************************************************

	var
	/********************* External reference ***************************/
	Config = window.Config,
	StringUtil = window.StringUtil,
    CommonUtil = window.CommonUtil,
    Constants = window.Constants,    
    Message = window.Message,
    Product = window.Product,
    Deposits = window.Deposits,
    Loans = window.Loans,
    Module = window.Module,
    About = window.About,
    Setting = window.Setting,
    AccessVO = window.AccessVO,
    
    androidJS = window.androidJS,
	/********************* Internal variable ****************************/
    VS_ID_MAIN = '#app-home',
    VS_ID_ABOUT = '#app-about',
    VS_ID_MOBILE_MAIN = '#app-phone-main',
    VS_ID_CONTENT_DEPOSITS = '#app-cont-deposits',
    VS_ID_CONTENT_LOANS = '#app-cont-loans',
    VS_ID_CONTENT_ABOUT = '#app-cont-about',
    VS_ID_CONTENT_SETTING = '#app-cont-setting',
    
    VS_CSS_PAGES = '.app-mui-pages',
    VS_CSS_PRD_PAGE_LINK = '.app-mui-page-content ul li a[data-ref*="PRD"]',
    VS_CSS_SINGLE_PAGE_LINK = '.app-mui-page-content ul li a[data-ref="SINGLE"]',
    VS_CSS_TITLE_CENTER = '.app-nav-title-center',
    VS_CSS_TITLE_LEFT = '.app-nav-title-left',
    VS_CSS_REFRESH = '.app-mui-navbar .app-btn-refresh',
    VS_CSS_CURRENT_WRAPPER = '.mui-page-center .app-scroll-wrapper',
	
    VS_PAGE_PRD_DEPOSITS = 'views/deposits.html',
    VS_PAGE_PRD_LOANS = 'views/loans.html',
    VS_PAGE_ABOUT = 'views/about.html',
    VS_PAGE_SETTING = 'views/setting.html',
    
    vo_viewApi = null,
    vo_product = null,
    vo_module = null,
    vs_currentTitle = '',
    vs_parentTitle = '',
    va_accessHistory = [];

	//******************************************************************************
	//*                           Private function definitions                     *
	//******************************************************************************
    function _init() {                    
        _initPages();
        
        _initMui();
        
        _initMuiEvent();
        
        _initCustomEvent();
    }
    
    function _initPages() {
        var lo_$depositsCont = $(VS_ID_CONTENT_DEPOSITS),
            lo_$loansCont = $(VS_ID_CONTENT_LOANS),
            lo_$about = $(VS_ID_CONTENT_ABOUT),
            lo_$setting = $(VS_ID_CONTENT_SETTING);

        lo_$depositsCont.load(VS_PAGE_PRD_DEPOSITS);        
        lo_$loansCont.load(VS_PAGE_PRD_LOANS);
        lo_$about.load(VS_PAGE_ABOUT);
        lo_$setting.load(VS_PAGE_SETTING);
    }

    function _initMui() {
        mui.init();

        vo_viewApi = mui(VS_ID_MOBILE_MAIN).view({
            defaultPage: VS_ID_MAIN
        });
    }
    
    function _initPullRefresh() {
        mui(VS_CSS_CURRENT_WRAPPER).pullRefresh({
            down: {
                style: 'circle',
                contentinit: Constants.PS_MSG_PULLDOWN_REFERSH,
                contentdown: Constants.PS_MSG_PULLDOWN_REFERSH,
                contentover: Constants.PS_MSG_RELEASE_REFERSH,
                contentrefresh: Constants.PS_MSG_LOADING,
                callback: _pulldownRefresh
            }
        }); 
    }
    
    function _pullupRefresh() {
        var lo_me = this;
        lo_me.endPullupToRefresh(false);
        
        setTimeout(function() {            
            if (vo_product) {
                vo_product.setLoaded(true);
                vo_product.refresh();
            }
                      
            mui.toast(Constants.PS_MSG_RECORD_UPDATED);
        }, 1000);        
    }
    
    function _pulldownRefresh() {
        var lo_me = this;
        
        setTimeout(function() {            
            if (vo_product) {
                vo_product.setLoaded(true);
                vo_product.refresh();
            }
            
            lo_me.endPulldownToRefresh();                        
            //mui.toast(Constants.PS_MSG_RECORD_UPDATED);
        }, 1000);        
    }
    
    function _initMuiEvent() {
        var lf_oldBack,
            lo_view;
                
        lo_view = vo_viewApi.view;
        lf_oldBack = mui.back;
        
        // Back event
        mui.back = function() {
            if (vo_viewApi.canBack()) {
                vo_viewApi.back();
            } else {
                //lf_oldBack();
                
                // Call android exit method
                androidJS.exit();
                
                vo_product = null;
            }
        }
        
        // Before page show event
        $(lo_view).on('pageBeforeShow', _pageBeforeShow);
        
        // Page show evnet
        $(lo_view).on('pageShow', _pageShow);
        
        // Before page back event
        $(lo_view).on('pageBeforeBack', _pageBeforeBack);
        
        // Page back event
        $(lo_view).on('pageBack', _pageBack);
    }
    
    function _initCustomEvent() {                
        $(VS_CSS_PAGES).on('tap', VS_CSS_PRD_PAGE_LINK, function(ao_event) {
            _eventTarget(ao_event, _initProduct);
        });
        
        $(VS_CSS_PAGES).on('tap', VS_CSS_SINGLE_PAGE_LINK, function(ao_event) {
            _eventTarget(ao_event, _initModule);
        });      
    }
    
    function _eventTarget(ao_event, af_callback) {
        var lo_target = ao_event.target,
            lo_currentTarget = ao_event.currentTarget,
            lo_$currentTarget;
            
        if (lo_target && lo_target.tagName === 'A') {
            lo_currentTarget = lo_target;
        }
        
        if (lo_currentTarget && lo_currentTarget.tagName === 'A') {
            if (af_callback) {
                af_callback(lo_currentTarget);
            }            
        } else {
            vs_currentTitle = '';
        } 
    }
            
    function _initProduct(ao_target) {
        var ls_prdCode,
            ls_key,
            ls_refer,
            lo_$currentTarget = $(ao_target);
        
        ls_prdCode = lo_$currentTarget.data('prd');
        ls_refer = lo_$currentTarget.data('ref');
        ls_key = lo_$currentTarget.data('title');
        
        vs_currentTitle = ls_key;

        if (!vo_product) {
            vo_product = _createProduct(ls_prdCode);
        } else {
            vo_product.addParam(Constants.PS_KEY_PRD_ID, ls_key);
        }
        
        if (vo_product && vo_product instanceof Product) {
            vo_product.setLoaded(false);
            vo_product.setRef(ls_refer);
        }
    }
    
    function _createProduct(as_prdCode) {
        var lo_product;
        
        switch(as_prdCode) {
            case Constants.PS_PRD_DEPOSITS:
                lo_product = new Deposits();
                break;
            case Constants.PS_PRD_LOANS:
                lo_product = new Loans();                
                break;                        
        }
        
        if (lo_product) {
            lo_product.setProductCode(as_prdCode);
        }
        
        return lo_product;
    }
    
    function _initModule(ao_target) {
        var ls_mdlCode,
            ls_key,
            ls_refer,
            lo_$currentTarget = $(ao_target);
        
        ls_mdlCode = lo_$currentTarget.data('mdl');
        ls_refer = lo_$currentTarget.data('ref');
        ls_key = lo_$currentTarget.data('title');
        
        vs_currentTitle = ls_key;

        if (!vo_module) {
            vo_module = _createModule(ls_mdlCode);
        } 
    }
    
    function _createModule(as_mdlCode) {
        var lo_module;
        
        switch(as_mdlCode) {
            case Constants.PS_MDL_ABOUT:
                lo_module = new About();
                break;
            case Constants.PS_MDL_SETTING:
                lo_module = new Setting();                
                break;                        
        }
        
        if (lo_module) {
            lo_module.setModuleCode(as_mdlCode);
        }
        
        return lo_module;
    }
    
    function _pageBeforeShow() {
        var ls_parentTitle,
            lo_$activeNavbar = $(vo_viewApi.activeNavbar),
            lo_$previousNavbar = $(vo_viewApi.previousNavbar),
            lo_access,
            lo_currentPage;

        if (vo_viewApi.isBack) {
            lo_currentPage = vo_viewApi.previousPage;                        
        } else {
            ls_parentTitle = lo_$previousNavbar.find(VS_CSS_TITLE_CENTER).text();
            
            lo_$activeNavbar.find(VS_CSS_TITLE_LEFT).text(vs_currentTitle);
//            lo_$activeNavbar.find(VS_CSS_TITLE_CENTER).text(vs_currentTitle);
            
            lo_currentPage = vo_viewApi.activePage;            
        }
        
        if (vo_product) {
            vo_product.setPage(lo_currentPage);
            vo_product.refresh(); 
        }
        
        if (vo_module) {            
            vo_module.setPage(lo_currentPage);
            vo_module.init();
            vo_module.refresh();
        }
    }
    
    function _pageShow() {
        var lo_access;

        if (!vo_viewApi.isBack) {
            if (vo_product) {
                lo_access = null;
                lo_access = new AccessVO();  
                lo_access.setRef(vo_product.getRef());
                lo_access.setParamObj(_clone(vo_product.getParams()));
                
                va_accessHistory.push(lo_access);
            }
        }
     
        _initPullRefresh();
    }
    
    function _pageBeforeBack() {
        var lo_access;
        
        // Home page
        if (!CommonUtil.isValidArray(vo_viewApi.history)) {
            vo_product = null;
            vo_module = null;
        } else {
            if (CommonUtil.isValidArray(va_accessHistory)) {
                 va_accessHistory.pop();
            
                if (vo_product) {
                    lo_access = va_accessHistory[va_accessHistory.length - 1];
                    
                    vo_product.setLoaded(false);
                    vo_product.setRef(lo_access.getRef());
                    vo_product.setParams(_clone(lo_access.getParamObj()));
                }
            }           
        }
    }
    
    function _pageBack() {
        var la_history = vo_viewApi.history;
    }
    
    function _clone(ao_target) {
        if (ao_target) {
            return $.extend(true, {}, ao_target);
        } else {
            return null;
        }        
    }
	//******************************************************************************
	//*                           Public function definitions                      *
	//******************************************************************************
    
	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
    (function main() {
        _init();
    }());
}(window, document, jQuery));
