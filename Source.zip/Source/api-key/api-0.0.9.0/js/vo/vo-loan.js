(function (window){
    'use strict';

    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * LoanVO constructor function
     *
     * @constructor
     */
    function LoanVO() {
        this.pid = null;
        this.prd = null;
        this.type = null;
        this.subtype = null;
        this.intRate = null;
        this.pinfo1 = null;
        this.pinfo2 = null;
        this.pinfo3 = null;
        this.fee = null;
        this.remark = null;
    }
    
    /**
     * LoanVO prototype
     */
    LoanVO.prototype = {
        constructor: LoanVO,

        /**
         * Set current refresh function into monitor, when switcher resume will call this function
         */
        load : function(ao_result) {
            this.pid = ao_result["prodId"];
            this.prd = ao_result["product"];
            this.type = ao_result["type"];
            this.subtype = ao_result["subtype"];
            this.intRate = ao_result["interestRate"];
            this.pinfo1 = ao_result["prdinfo1"];
            this.pinfo2 = ao_result["prdinfo2"];
            this.pinfo3 = ao_result["prdinfo3"];
            this.fee = ao_result["fee"];
            this.remark = ao_result["remark"];
        }
    };
    
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.LoanVO = LoanVO;

}(window));
