(function (window){
    'use strict';

    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * AccessVO constructor function
     *
     * @constructor
     */
    function AccessVO() {
        this._ref = '';
        this._params = null;

    }
    
    /**
     * AccessVO prototype
     */
    AccessVO.prototype = {
        constructor: AccessVO,

        getRef : function() {
            return this._ref;
        },
        
        setRef : function(as_ref) {
            this._ref = as_ref;
        },

        getParamObj : function() {
            return this._params;
        },
        
        setParamObj : function(ahm_param) {
            this._params = ahm_param;
        }
    };
    
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.AccessVO = AccessVO;

}(window));
