(function (window){
    'use strict';

    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * DepositVO constructor function
     *
     * @constructor
     */
    function DepositVO() {
        this.pid = null;
        this.prd = null;
        this.type = null;
        this.subtype = null;
        this.ccy = null;
        this.intRate = null;
        this.minAmt = null;
        this.fee = null;
        this.remark = null;
    }
    
    /**
     * DepositVO prototype
     */
    DepositVO.prototype = {
        constructor: DepositVO,

        load : function(ao_result) {
            this.pid = ao_result["prodId"];
            this.prd = ao_result["product"];
            this.type = ao_result["type"];
            this.subtype = ao_result["subtype"];
            this.ccy = ao_result["currency"];
            this.intRate = ao_result["interestRate"];
            this.minAmt = ao_result["minamount"];
            this.fee = ao_result["fee"];
            this.remark = ao_result["remark"];
        }
    };
    
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.DepositVO = DepositVO;

}(window));
