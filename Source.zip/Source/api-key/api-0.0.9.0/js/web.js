(function (window, document, $, mui) {
	'use strict';

	//******************************************************************************
	//*   Variable definitions(include external reference and internal variable)   *
	//******************************************************************************

	var
	/********************* External reference ***************************/
	Config = window.Config,
    StringUtil = window.StringUtil,
    CommonUtil = window.CommonUtil,    
    Constants = window.Constants,  
    Mapping = window.Mapping,
    Store = window.Store,
    Message = window.Message,

	/********************* Internal variable ****************************/
	vs_urlProjectPath = '',
    vs_gatewayUrl = Config.PS_URL_GATEWAY,
    vs_gateway = Config.PS_DEFAULT_GW,
    vs_connType = Config.PS_DEFAULT_CONN,
    vs_version = Config.PS_VERSION,
    
	vb_isDebugModel = Config.PB_IS_DEBUG,
    vb_isRestRequest = false,
    vb_isConfig = false,
    vb_isCompleteRequest = true,
    
    vi_timeout = Config.PI_REQ_TIMEOUT,
    
    vo_this = {},
    vo_ajaxRequest = null,
    vo_store = null,
    vo_gateway = null,
    vo_config = null,
    vo_connTypeHeader = null,
	vo_apiKey = null;

	//******************************************************************************
	//*                           Private function definitions                     *
	//******************************************************************************
    function _init(ab_reset) {
        vo_store = new Store();

        if (vo_store.isValidStore()) {
            _syncStore();

            if (ab_reset) {
                vo_store.remove();
            }

             // Not match current version, will clear all store
             _setVersion();

             _setGateway();

             _setConnectionType();

             _setTimeout();

             // Get config from store, if not exist will merge gateway config and current config
             _setConfig();

             // Get api key from json file
             _setApiKey();
        } else {
            Message.showMuiErrorMsg(Constants.PS_MSG_NO_STORE, 'Error');
        }
    }

    function _syncStore(ab_push) {
        if (vo_store && vo_store.isValidStore()) {
            if (ab_push) {
                vo_store.push();
            } else {
                vo_store.pull();
            }
        }
    }

    function _setVersion() {
        var ls_version;

        ls_version = vo_store.get(Constants.PS_KEY_VERSION);

        if (ls_version) {
            if (vs_version !== ls_version) {
                vo_store.remove();
            }
        }

        vs_version && vo_store.put(Constants.PS_KEY_VERSION, vs_version);
    }

    function _setGateway() {
        var ls_gateway;

        ls_gateway = vo_store.get(Constants.PS_KEY_GATEWAY);

        if (ls_gateway) {
            vs_gateway = ls_gateway;
        }

        vs_gateway && vo_store.put(Constants.PS_KEY_GATEWAY, vs_gateway);
    }

    function _setApiKey() {
        var lo_apikey = vo_store.get(Constants.PS_KEY_API_KEY, true);

        if (lo_apikey) {
            vo_apiKey = lo_apikey;
        } else {
            _setApiKeyFromJson();
        }

        vo_apiKey && vo_store.put(Constants.PS_KEY_API_KEY, vo_apiKey);
    }

    function _setApiKeyFromJson() {
        vo_ajaxRequest = $.getJSON(Config.PS_JSON_API_KEY)
            .done(function(ao_result) {
                var lo_apiKey = ao_result[0],
                    ls_name,
                    ls_value;

                if (CommonUtil.isValidArray(ao_result)) {
                    lo_apiKey = ao_result[0];
                    ls_name = Object.keys(lo_apiKey)[0];
                    ls_value = lo_apiKey[ls_name];
                }

                if (ls_name && ls_value) {
                    vo_apiKey = {
                        'name' : ls_name,
                        'value' : ls_value
                    };

                    vo_store.put(Constants.PS_KEY_API_KEY, vo_apiKey);
                }
            })
            .fail(_errorCallback);
    }

    function _setConnectionType() {
        var ls_connectionType;

        ls_connectionType = vo_store.get(Constants.PS_KEY_CONNECTION);

        if (ls_connectionType) {
            vs_connType = ls_connectionType;
        }

        vs_connType && vo_store.put(Constants.PS_KEY_CONNECTION, vs_connType);

        _setConnectionTypeHeader();
    }

    function _setConnectionTypeHeader() {
        if (vs_connType) {
            vo_connTypeHeader = {
                'name' : Constants.PS_HEADER_CONN,
                'value' : vs_connType
            };
        } else {
            vo_connTypeHeader = null;
        }
    }

    function _setTimeout() {
        var ls_timeout;

        if (vs_connType === Constants.PS_CONN_FTP) {
            vi_timeout = Config.PI_REQ_TIMEOUT_LONG;
        } else {
            vi_timeout = Config.PI_REQ_TIMEOUT;
        }

        ls_timeout = vo_store.get(Constants.PS_KEY_TIMEOUT);

        if (ls_timeout) {
            vi_timeout = Number(ls_timeout);
        }

        vi_timeout && vo_store.put(Constants.PS_KEY_TIMEOUT, vi_timeout);
    }

    function _setConfig() {
        var lo_config;

        lo_config = vo_store.get(Constants.PS_KEY_CONFIG, true);

        if (lo_config) {
            vo_config = lo_config;
        }

        if (vo_config) {
            Config = window.Config = vo_config;

            vs_gatewayUrl = Config.PS_URL_GATEWAY;
            vb_isConfig = true;
        } else {
            _mergeGatewayConfig();
        }
    }

    function _mergeGatewayConfig() {
        var ls_gatewayConfig,
            lo_gateway,
            lo_gatewayConfig;

        lo_gateway = Mapping['Gateways'][vs_gateway];
        ls_gatewayConfig = lo_gateway['config'];

        if (StringUtil.isNotEmpty(ls_gatewayConfig) && ls_gatewayConfig.indexOf('.js') >= 0) {
           vo_this.sendScriptRequest(ls_gatewayConfig, function(ao_result) {
               Config = window.Config = $.extend(true, {}, Config, window.SubConfig);

               vo_store.put(Constants.PS_KEY_CONFIG, Config);

               vs_gatewayUrl = Config.PS_URL_GATEWAY;

               vb_isConfig = true;
           }, function(ao_xmlHttpRequest, ao_textStatus, ao_errorThrown) {
               vb_isConfig = false;

               Message.showMuiErrorMsg('Load config script file[' + ls_gatewayConfig + '] fail!', 'Error');
           });
        }
    }

    function _addRequestHeader(a_request, ao_header) {
        var ls_headerName,
            ls_headerValue;

        if (ao_header) {
            ls_headerName = ao_header['name'];
            ls_headerValue = ao_header['value'];

            a_request.setRequestHeader(ls_headerName, ls_headerValue);
        }
    }

    function _sendLoadScriptRequest(as_url, af_success, af_error) {
        vo_ajaxRequest = $.ajax({
            url: as_url,
            async: false,
            dataType: 'script',
            success: function (result) {
                if (af_success) {
                    af_success(result);
                } else {
                    _successCallback(result);
                }
			},
			error: function (a_xmlHttpRequest, a_textStatus, a_errorThrown) {
				if (af_error) {
					af_error(a_xmlHttpRequest, a_textStatus, a_errorThrown);
				} else {
                    _errorCallback(a_xmlHttpRequest, a_textStatus, a_errorThrown);
                }
			}
        });
    }
    
	/**
	 * Send ajax request with 'json', if not set success/error/failure callback function, will call the default function
	 *
	 * @param {String} as_url
	 * @param {Object} ao_data
	 * @param {boolean} ab_sync
	 * @param {Function} [af_success]
	 * @param {Function} [af_error]
	 * @param {Function} [af_failure]
	 *
	 * @private
	 */
	function _sendAjaxRequest(as_url, ao_data, ab_sync, af_success, af_error, af_failure) {
		vo_ajaxRequest = $.ajax({
			type: vb_isRestRequest ? 'GET' : 'POST',
			cache: false,
			async: ab_sync,
			url: as_url,
			timeout: vi_timeout,
			dataType: 'json',
			contentType: 'application/json',
			data: ao_data ? JSON.stringify(ao_data) : undefined,
            crossDomain: true,
			xhrFiels: {
				widthCredentials: true
			},
			beforeSend: function (a_request) {
                _addRequestHeader(a_request, vo_apiKey);
                _addRequestHeader(a_request, vo_connTypeHeader);
                
                _requestLoading(true);
			},
			success: function (result) {
				if (StringUtil.isNotEmpty(result.code)) {
					if (af_failure) {
						af_failure(result);
					}
				} else {
					if (af_success) {
						af_success(result);
					}
				}
			},
			error: function (a_xmlHttpRequest, a_textStatus, a_errorThrown) {
				if (af_error) {
					af_error(a_xmlHttpRequest, a_textStatus, a_errorThrown);
				}
			},
            complete : function(a_xmlHttpRequest, a_textStatus) {
               _requestLoading();
            }
		});
	}

	/**
	 * Set request full path and then send request to web
	 *
	 * @param {String} as_url
	 * @param {Object} ao_data
	 * @param {boolean} ab_sync
	 * @param {Function} [af_success]
	 * @param {Function} [af_error]
	 * @param {Function} [af_failure]
	 *
	 * @private
	 */
	function _sendRequest(as_url, ao_data, ab_sync, af_success, af_error, af_failure) {
		var lf_successCallback,
            lf_errorCallback,
            lf_failureCallback;

		if (af_success) {
			lf_successCallback = af_success;
		} else {
			lf_successCallback = _successCallback;
		}

		if (af_error) {
			lf_errorCallback = af_error;
		} else {
			lf_errorCallback = _errorCallback;
		}

		if (af_failure) {
			lf_failureCallback = af_failure;
		} else {
			lf_failureCallback = _failureCallback;
		}

		_sendAjaxRequest(vs_gatewayUrl + as_url, ao_data, ab_sync, lf_successCallback, lf_errorCallback, lf_failureCallback);
	}

	/**
	 * Default response success callback
	 *
	 * @param ao_result
	 *
	 * @private
	 */
	function _successCallback(ao_result) {
		// To do something
	}

	/**
	 * Default response failure callback
	 *
	 * @param ao_result
	 *
	 * @private
	 */
	function _failureCallback(ao_result) {
		var ls_errorCode = ao_result.code || '',
            ls_errorMessage = ao_result.message || '';

		if (ls_errorCode.indexOf(Constants.CS_MSG_SYS_ERROR_CODE) !== -1) {
			Message.showSysErrorMsg(ls_errorMessage, "Failure", function () {
				vo_this.logout(true);
			});
		} else {
			Message.showMuiErrorMsg(ls_errorMessage, "Failure");
		}
	}

	/**
	 * Default response error callback
	 *
	 * @param ao_xmlHttpRequest
	 * @param ao_textStatus
	 * @param ao_errorThrown
	 *
	 * @private
	 */
    function _errorCallback(ao_xmlHttpRequest, ao_textStatus, ao_errorThrown) {
         var li_status = ao_xmlHttpRequest.status,
             ls_statusText = ao_xmlHttpRequest.statusText,
             ls_responesText = ao_xmlHttpRequest.responseText,
             ls_error,
             lo_response;

         if (ls_responesText) {
             try {
                 lo_response = JSON.parse(ls_responesText);
             } catch (exception) {
                 lo_response = null;
             }

             if (lo_response) {
                 ls_error = lo_response.error;
             }

             if (!ls_error) {
                 ls_error = ls_statusText;
             }
         }

         if (ao_textStatus === 'abort') {
             return;
         }

         if (ao_textStatus === 'timeout') {
             Message.showMuiErrorMsg(Constants.PS_MSG_REQ_TIMEOUT);
         } else if (li_status === 0) {
             Message.showMuiErrorMsg(Constants.PS_MSG_REQ_NO_SENT);
         } else {
             Message.showMuiErrorMsg(ls_error);
         }

         console.error('_errorCallback', ls_error)
    }

    function _requestLoading(ab_show, ab_abort) {
        if (ab_abort) {
            _hideLoading();

            if (vo_ajaxRequest) {
                vo_ajaxRequest.abort();
            }
        } else {
            if (ab_show) {
                _showLoading();
            } else {
                _hideLoading();

                vo_ajaxRequest = null;
            }
        }
    }

    function _hideLoading() {
        mui.hideLoading();
    }

    function _showLoading(as_content) {
	    var ls_content = as_content || 'Loading...';

        mui.showLoading(ls_content, 'div');
    }

	function _redirectLogin() {
		vo_this.redirectPage(Config.CS_URL_APP_LOGIN);
	}

	//******************************************************************************
	//*                           Public function definitions                      *
	//******************************************************************************
	/**
	 * Web constructor function
	 *
	 * @constructor
	 */
	function Web() {
		vo_this = this;

        _init();

        vo_this.updateStore();
	}

	/**
	 * Web prototype
	 */
    Web.prototype = {
		constructor: Web,

		/**
		 * If is debug model, true will enable switcher, otherwise will disabled.
		 *
		 * @returns {Config.CB_IS_DEBUG|*}
		 */
		isDebug: function () {
			return vb_isDebugModel;
		},

		isPhone: function () {
            return mui.isTouchable;
		},
        
        isConfig : function() {
            return vb_isConfig;
        },
        
        isCompleteRequest : function() {
            return vb_isCompleteRequest;
        },
        
        getVersion : function() {
            return vs_version;
        },
        
        getGateway : function() {
            return vs_gateway;
        },

        getConnectionType : function() {
            return vs_connType;
        },
        
        getHost : function() {
            return vs_gatewayUrl;
        },
        
        getApiKey : function() {
            return vo_apiKey;
        },
        
        getTimeout : function() {
            return Number(vi_timeout / 1000);
        },

        getOS : function() {
            var ls_os = '',
                lo_os = mui.os;

            if (lo_os) {
                if (lo_os.android) {
                    ls_os = 'Android ' + lo_os.version;
                } else {
                    ls_os = 'Others ' + lo_os.version;
                }
            }

            return ls_os;
        },
        
		/**
		 * Get element by id during document, if document is null, will get current window document
		 *
		 * @param {String} as_selector
		 * @param {Object} [a_document]
		 * @returns {*|HTMLElement}
		 */
		$domain: function (as_selector, a_document) {
			return a_document ? $(as_selector, a_document) : $(as_selector);
		},

		/**
		 * Send synchronous request
		 *
		 * @param {String} as_url
		 * @param {Object} ao_data
		 * @param {Function} [af_success]
		 * @param {Function} [af_error]
		 * @param {Function} [af_failure]
		 */
		sendSyncRequest: function (as_url, ao_data, af_success, af_error, af_failure) {
            vb_isRestRequest = false;
            
			_sendRequest(as_url, ao_data, true, af_success, af_error, af_failure);
		},

		/**
		 * Send asynchronous request
		 *
		 * @param {String} as_url
		 * @param {Object} ao_data
		 * @param {Function} [af_success]
		 * @param {Function} [af_error]
		 * @param {Function} [af_failure]
		 */
		sendAsycRequest: function (as_url, ao_data, af_success, af_error, af_failure) {
            vb_isRestRequest = false;
            
			_sendRequest(as_url, ao_data, false, af_success, af_error, af_failure);
		},
        
        sendRestRequest: function(as_url, ao_data, af_success, af_error, af_failure) {
            var ls_url = as_url,
                lo_data = ao_data,
                la_data = [];
                
                if (lo_data) {
                    for (var ls_key in lo_data) {
                        la_data.push(lo_data[ls_key]);
                    }
                }
                
            ls_url = StringUtil.messageFormat(ls_url, la_data);
            vb_isRestRequest = true;
            
            _sendRequest(ls_url, null, true, af_success, af_error, af_failure);
        },

        sendScriptRequest: function(as_url, af_success, af_error) {
            as_url = as_url + '?_=' + new Date().getTime();
            
            _sendLoadScriptRequest(as_url, af_success, af_error);
        },
        
        forcedBack: function() {
            _requestLoading(false, true);
                        
            mui.back();
            
            console.info('forcedBack');
        },

        delayCall : function(af_callback, ai_delay) {
            var li_delayTime = ai_delay || 50;

            af_callback && mui.later(af_callback, li_delayTime);
        },

        reload : function() {
            this.delayCall(function() {
                _syncStore(true);

                window.location.hash = '';
                window.location.reload();
            }, 500);
        },
        
		redirectPage: function (as_url) {
			window.location.href = vs_urlProjectPath + as_url;
		},

        updateConfig : function(as_gateway, ai_timeout, as_connType, af_callback) {
            var lb_configChange = false;

            vs_connType = as_connType;

            if (as_gateway !== vs_gateway) {
                vs_gateway = as_gateway;

                vo_apiKey = null;
                vo_config = null;

                lb_configChange = true;
            }

            if (vi_timeout !== ai_timeout) {
                vi_timeout = Number(ai_timeout);

                lb_configChange = true;
            }

            if (lb_configChange) {
                _init(true);

                af_callback && af_callback();
            }
        },

        updateStore : function() {
            this.delayCall(function() {
                _syncStore(true);
            }, 500);
        }
	};

	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
	(function main(){
        window.web = new Web();
    })();
}(window, document, jQuery, mui));
