(function (window, $){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,                
        Config = topWindow.Config,
        Constants = topWindow.Constants,
        StringUtil = topWindow.StringUtil,
        CommonUtil = topWindow.CommonUtil,
        Product = topWindow.Product,
        web = topWindow.web,

	    /********************* Internal variable ****************************/
        VS_CSS_PRD = '.app-prd',
        VS_CSS_PRD_ID = '.app-prd-id',
        VS_CSS_TYPE = '.app-type',
        VS_CSS_SUB_TYPE = '.app-subtype',        
        VS_CSS_CCY = '.app-ccy',
        VS_CSS_INT_RATE = '.app-int-rate',
        VS_CSS_FEE = '.app-fee',
        VS_CSS_PRD_INFO_1 = '.app-prd-info1',
        VS_CSS_PRD_INFO_2 = '.app-prd-info2',
        VS_CSS_PRD_INFO_3 = '.app-prd-info3',
        VS_CSS_REMARK = '.app-remark';

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************
    function _showLoans(ao_view, ao_loan) {
        ao_view.find(VS_CSS_TYPE).html(ao_loan.type);
        ao_view.find(VS_CSS_SUB_TYPE).html(ao_loan.subtype);
        ao_view.find(VS_CSS_INT_RATE).html(ao_loan.intRate);
        ao_view.find(VS_CSS_FEE).html(ao_loan.fee);
    }
    
    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function Loans() {
        Product.call(this);
    }

    CommonUtil.$extends(Loans, Product, {
        showPrdItems : function(ao_row, ao_item) {
            var lo_loans = new LoanVO();
            
            lo_loans.load(ao_item);
            
            this.setVO(lo_loans);
            
            _showLoans(ao_row, lo_loans);

            this.$super.showPrdItems(ao_row, ao_item);
        },
        
        showPrdItem : function(ao_page, ao_loan) {
            if (ao_loan) {
                _showLoans(ao_page, ao_loan);
                
                ao_page.find(VS_CSS_PRD).html(ao_loan.prd);
                ao_page.find(VS_CSS_PRD_ID).html(ao_loan.pid);
                ao_page.find(VS_CSS_PRD_INFO_1).html(ao_loan.pinfo1);
                ao_page.find(VS_CSS_PRD_INFO_2).html(ao_loan.pinfo2);
                ao_page.find(VS_CSS_PRD_INFO_3).html(ao_loan.pinfo3);
                ao_page.find(VS_CSS_REMARK).html(ao_loan.remark);
            }
        }
    });
   
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Loans = Loans;

}(window, jQuery));
