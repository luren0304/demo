(function (window, $){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,                
        Config = topWindow.Config,
        Constants = topWindow.Constants,
        StringUtil = topWindow.StringUtil,
        CommonUtil = topWindow.CommonUtil,
        Product = topWindow.Product,
        DepositVO = topWindow.DepositVO,
        web = topWindow.web,

	    /********************* Internal variable ****************************/
        VS_CSS_PRD = '.app-prd',
        VS_CSS_PRD_ID = '.app-prd-id',
        VS_CSS_TYPE = '.app-type',
        VS_CSS_SUB_TYPE = '.app-subtype',        
        VS_CSS_CCY = '.app-ccy',
        VS_CSS_INT_RATE = '.app-int-rate',
        VS_CSS_MIN_AMT = '.app-min-amt',
        VS_CSS_FEE = '.app-fee',
        VS_CSS_REMARK = '.app-remark';

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************
    function _showDeposits(ao_view, avo_deposit) {
        ao_view.find(VS_CSS_CCY).html(avo_deposit.ccy);
        ao_view.find(VS_CSS_TYPE).html(avo_deposit.type);
        ao_view.find(VS_CSS_SUB_TYPE).html(avo_deposit.subtype);
        ao_view.find(VS_CSS_INT_RATE).html(avo_deposit.intRate);
        ao_view.find(VS_CSS_MIN_AMT).html(avo_deposit.minAmt);
        ao_view.find(VS_CSS_FEE).html(avo_deposit.fee);
    }
    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function Deposits() {
        Product.call(this);
    }

    CommonUtil.$extends(Deposits, Product, {
        showPrdItems : function(ao_row, ao_item) {
            var lo_deposits = new DepositVO();
            
            lo_deposits.load(ao_item);
            
            this.setVO(lo_deposits);
            
            _showDeposits(ao_row, lo_deposits);

            this.$super.showPrdItems(ao_row, ao_item);
        },
        
        showPrdItem : function(ao_page, avo_deposit) {
            if (avo_deposit) {
                _showDeposits(ao_page, avo_deposit);
                
                ao_page.find(VS_CSS_PRD).html(avo_deposit.prd);
                ao_page.find(VS_CSS_PRD_ID).html(avo_deposit.pid);
                ao_page.find(VS_CSS_REMARK).html(avo_deposit.remark);
            }
        }
    });
   
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Deposits = Deposits;

}(window, jQuery));
