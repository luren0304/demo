(function (window, $, mui){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,
        Constants = topWindow.Constants,
        StringUtil = topWindow.StringUtil,
        Module = topWindow.Module,
        Message = topWindow.Message,
        web = topWindow.web,

	    /********************* Internal variable ****************************/
	    VI_DB_TIMEOUT_MAX = 60,
        VI_DB_TIMEOUT_STEP = 5,
        VI_DB_TIMEOUT_DEFAULT = Config.PI_REQ_TIMEOUT,
        VI_FTP_TIMEOUT_MAX = 900,
        VI_FTP_TIMEOUT_STEP = 100,
        VI_FTP_TIMEOUT_DEFAULT = Config.PI_REQ_TIMEOUT_LONG,
        VI_TIMEOUT_MIN_DEFAULT = 0,

        VS_CSS_RADIO_GW = '.app-radio[name="gateway"]',
        VS_CSS_RADIO_CONN = '.app-radio[name="connection"]',
        VS_CSS_RADIO_GIO = '.app-radio.app-gw-gio',
        VS_CSS_RADIO_TYK = '.app-radio.app-gw-tyk',
        VS_CSS_RADIO_DB = '.app-radio.app-conn-db',
        VS_CSS_RADIO_FTP = '.app-radio.app-conn-ftp',
        VS_CSS_BTN_SAVE = '.app-btn-save',
        VS_CSS_TIMEOUT = '.app-timeout',
        VS_CSS_NUM_BOX = '.app-numbox',
        //VS_CSS_TOGGLE_NUM = '.mui-btn[class*=mui-btn-numbox]',

        vo_numBox,
        vs_gateway,
        vs_connType,
        vi_timeout,
        vb_duplicateClick = false;

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************
    function _showSetting(ao_view) {
        /*
        vs_gateway = web.getGateway();
        vs_connection = web.getConnectionType();
        vi_timeout = web.getTimeout();
        
        $(ao_view).find(VS_CSS_RADIO_GW + '[value="' + vs_gateway + '"]').attr('checked', true);
        $(ao_view).find(VS_CSS_RADIO_CONN + '[value="' + vs_connection + '"]').attr('checked', true);

        vo_numBox.setValue(vi_timeout);
        */

        vi_timeout = web.getTimeout();

        _initGateway(ao_view);

        _initConnectionType(ao_view);

        _initTimeout(ao_view, vi_timeout);

        _toggleSave(ao_view);
    }
    
    function _initGateway(ao_view) {
        vs_gateway = web.getGateway();

        $(ao_view).find(VS_CSS_RADIO_GIO).val(Constants.PS_GATEWAY_GIO);
        $(ao_view).find(VS_CSS_RADIO_TYK).val(Constants.PS_GATEWAY_TYK);

        $(ao_view).find(VS_CSS_RADIO_GW + '[value="' + vs_gateway + '"]').prop('checked', true);
    }
    
    function _initConnectionType(ao_view) {
        vs_connType = web.getConnectionType();

        $(ao_view).find(VS_CSS_RADIO_DB).val(Constants.PS_CONN_DB);
        $(ao_view).find(VS_CSS_RADIO_FTP).val(Constants.PS_CONN_FTP);

        $(ao_view).find(VS_CSS_RADIO_CONN + '[value="' + vs_connType + '"]').prop('checked', true);
    }

    function _initTimeout(ao_view, ai_timeout) {
        var lo_$numberBox = $(ao_view).find(VS_CSS_NUM_BOX),
            li_timeoutMax,
            li_timeoutMin,
            li_timeoutStep,
            li_timeout;

        if (vs_connType === Constants.PS_CONN_DB) {
            li_timeoutMax = VI_DB_TIMEOUT_MAX;
            li_timeoutMin = VI_TIMEOUT_MIN_DEFAULT;
            li_timeoutStep = VI_DB_TIMEOUT_STEP;
            li_timeout = Number(VI_DB_TIMEOUT_DEFAULT / 1000);
        } else if (vs_connType === Constants.PS_CONN_FTP) {
            li_timeoutMax = VI_FTP_TIMEOUT_MAX;
            li_timeoutMin = VI_TIMEOUT_MIN_DEFAULT;
            li_timeoutStep = VI_FTP_TIMEOUT_STEP;
            li_timeout = Number(VI_FTP_TIMEOUT_DEFAULT / 1000);
        }

        if (ai_timeout) {
            li_timeout = ai_timeout;
        }

        if (vo_numBox) {
            vo_numBox.setOption('max', li_timeoutMax);
            vo_numBox.setOption('min', li_timeoutMin);
            vo_numBox.setOption('step', li_timeoutStep);
            vo_numBox.setValue(li_timeout);
        }

        vi_timeout = li_timeout;
    }
    
    function _toggleSave(ao_view) {
        var lo_$saveBtn = $(ao_view).find(VS_CSS_BTN_SAVE);
        
        if (vs_gateway === web.getGateway() && vi_timeout === web.getTimeout()) {
            lo_$saveBtn.attr('disabled', true);
        } else {
            lo_$saveBtn.attr('disabled', false);
        }                 
    }
    
    function _bindEvent(ao_view) {  
        vo_numBox = mui(VS_CSS_NUM_BOX).numbox();

        $(ao_view).on('change', VS_CSS_RADIO_GW, function(ao_event) {
            vs_gateway = $(ao_event.target).val();
            
            _toggleSave(ao_view);
        });

        $(ao_view).on('change', VS_CSS_RADIO_CONN, function(ao_event) {
            vs_connType = $(ao_event.target).val();
            _initTimeout(ao_view);

            _toggleSave(ao_view);
        });
        
        $(ao_view).on('change', VS_CSS_TIMEOUT, function(ao_event) {
            vi_timeout = vo_numBox.getValue();
            
            _toggleSave(ao_view);
        });

        $(ao_view).on('tap', VS_CSS_BTN_SAVE, function() {  
            var ls_confrimMsg = StringUtil.messageFormat(Constants.PS_MSG_CFG_CHANGE, [vs_gateway]),
                ls_updateMsg = StringUtil.messageFormat(Constants.PS_MSG_CFG_UPDATE, [vs_gateway]),
                li_timeout = vi_timeout * 1000;

            // Will popup more times confirm dialog
            if (!vb_duplicateClick) {

                vb_duplicateClick = true;
                
                Message.showMuiConfirmMsg(ls_confrimMsg, null, function(ao_event) {
                    web.updateConfig(vs_gateway, li_timeout, vs_connType, function() {
                        mui.toast(ls_updateMsg);
                        
                        _toggleSave(ao_view);
                        
                        web.reload();
                    });
                });
                
                setTimeout(function() {
                    vb_duplicateClick = false;
                }, 1000);                
            }    
        });
    }
    
    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function Setting() {
        Module.call(this);
    }

    CommonUtil.$extends(Setting, Module, {
        bindEvent : function() {            
            _bindEvent(this.getPage());
        },
        
        refresh : function() {
            _showSetting(this.getPage());
        }
    });
   
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Setting = Setting;

}(window, jQuery, mui));
