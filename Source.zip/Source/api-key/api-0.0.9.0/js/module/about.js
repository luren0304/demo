(function (window, $){
    'use strict';

    //******************************************************************************
    //*   Variable definitions(include external reference and internal variable)   *
    //******************************************************************************

    var
        /********************* External reference ***************************/
        topWindow = window.top,                
        Module = topWindow.Module,
        web = topWindow.web,
        Constants = topWindow.Constants,

	    /********************* Internal variable ****************************/
        VS_CSS_VERSION = '.app-version',
        VS_CSS_GATEWAY = '.app-gateway',
        VS_CSS_OS = '.app-os',
        VS_CSS_HOST = '.app-host',
        VS_CSS_RESOLUTION = '.app-resolution',
        VS_CSS_SIZE = '.app-size',

        VS_CSS_IS_PHONE = '.app-is-mobile',
        VS_CSS_IS_CONFIG = '.app-is-config',
        VS_CSS_KEY_NAME = '.app-key-name',
        VS_CSS_KEY_VALUE = '.app-key-value',
        VS_CSS_DEBUG = '.app-debug';

    //******************************************************************************
    //*                           Private function definitions                     *
    //******************************************************************************
    function _showAbout(ao_view) {
        var lo_$view = $(ao_view),
            lo_apiKey,
            ls_phoneSize,
            ls_screenSize;
        
        lo_$view.find(VS_CSS_VERSION).html('V ' + web.getVersion());
        lo_$view.find(VS_CSS_GATEWAY).html(web.getGateway());
        lo_$view.find(VS_CSS_HOST).html(web.getHost());
        
        if (web.isDebug()) {  
            lo_apiKey = web.getApiKey();

            if (lo_apiKey) {
                lo_$view.find(VS_CSS_KEY_NAME).html(lo_apiKey['name']);
                lo_$view.find(VS_CSS_KEY_VALUE).html(lo_apiKey['value']);
            }
            
            if (web.isPhone()) {
                lo_$view.find(VS_CSS_IS_PHONE).html(Constants.PS_VAL_YES);

                ls_phoneSize = ' H :' + androidJS.getHeight();
                ls_phoneSize += ' W :' + androidJS.getWidth();
                ls_phoneSize += ' DPI :' + androidJS.getDpi();

                lo_$view.find(VS_CSS_RESOLUTION).html(ls_phoneSize);
                lo_$view.find(VS_CSS_OS).html(web.getOS());
            } else {
                lo_$view.find(VS_CSS_IS_PHONE).html(Constants.PS_VAL_NO);
            }
            
            if (web.isConfig()) {
                lo_$view.find(VS_CSS_IS_CONFIG).html(Constants.PS_VAL_YES);
            } else {
                lo_$view.find(VS_CSS_IS_CONFIG).html(Constants.PS_VAL_NO);
            }

            ls_screenSize = ' H : ' + $(window).height();
            ls_screenSize += ' W : ' + $(window).width();

            lo_$view.find(VS_CSS_SIZE).html(ls_screenSize);
        } else {
            lo_$view.find(VS_CSS_DEBUG).hide();
        }
    }
    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function About() {
        Module.call(this);
    }

    CommonUtil.$extends(About, Module, {
        bindEvent : function() {
            var lo_$view = $(this.getPage());
            
            if (web.isDebug()) {
                lo_$view.find(VS_CSS_DEBUG).removeClass('mui-hidden');
            } else {
                lo_$view.find(VS_CSS_DEBUG).addClass('mui-hidden');
            }
        },
        
        refresh : function() {
            _showAbout(this.getPage());
        }
    });
   
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.About = About;

}(window, jQuery));
