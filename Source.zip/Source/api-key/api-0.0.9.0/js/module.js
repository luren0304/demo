(function (window, $){
    'use strict';

    //******************************************************************************
    //*                           Public function definitions                      *
    //******************************************************************************
    /**
     * Status constructor function
     *
     * @constructor
     */
    function Module() {
        this._mdlCode = '',  
        this._page = null;
    }

    /**
     * Status prototype
     */
    Module.prototype = {
        constructor: Module,

        setPage : function(ao_page) {
            this._page = ao_page;
        },
        
        getPage : function() {
            return this._page;
        },
        
        setModuleCode : function(as_mdlCode) {
            this._mdlCode = as_mdlCode;
        },
        
        getModuleCode : function() {
            return this._mdlCode;
        },

        init : function() {
            this.bindEvent();
        },
        
        bindEvent : function() {},
        
        refresh : function() {}
    };
    
    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Module = Module;

}(window, jQuery));
