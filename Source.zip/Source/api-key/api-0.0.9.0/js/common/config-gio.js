(function(window){
    'use strict';

    //******************************************************************************
    //*                             Config definitions                             *
    //******************************************************************************
    var SubConfig = {		
        PS_URL_GATEWAY : 'http://118.143.64.116:9878',
        PS_URL_DEPOSITS_PID : '/testapikey/deposits/prod',
        PS_URL_DEPOSITS_DTL : '/testapikey/deposits/one/{prodId}',
        PS_URL_LOANS_PID : '/testapikey/loans/prod',
        PS_URL_LOANS_DTL : '/testapikey/loans/one/{prodId}',
                     
        PS_JSON_API_KEY : 'files/api-key-gio.json'
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.SubConfig = SubConfig;
}(window));