(function(window){
    'use strict';

    //******************************************************************************
    //*                             Config definitions                             *
    //******************************************************************************
    var SubConfig = {		
        PS_URL_GATEWAY : 'https://118.143.64.116:9879',
        //PS_URL_GATEWAY : 'https://www.excelopenapi.com:9879',
        PS_URL_DEPOSITS_PID : '/testapikey/deposits/prod',
        PS_URL_DEPOSITS_DTL : '/testapikey/deposits/one/{prodId}',
        PS_URL_LOANS_PID : '/testapikey/loans/prod',
        PS_URL_LOANS_DTL : '/testapikey/loans/one/{prodId}',
        
        PS_JSON_API_KEY : 'files/api-key-tyk.json'
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.SubConfig = SubConfig;
}(window));