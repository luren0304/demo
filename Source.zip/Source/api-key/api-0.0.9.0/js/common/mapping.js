(function(window){
    'use strict';

    //******************************************************************************
    //*                             Mapping definitions                             *
    //******************************************************************************
    var Mapping = {		
        Product : {
            'DEPOSIT' : {
                'PRD_ID_PATH' : 'Config.PS_URL_DEPOSITS_PID',
                'PRD_DTL_PATH' : 'Config.PS_URL_DEPOSITS_DTL',
                'PRD_ID_JSON' : 'Config.PS_JSON_DEPOSITS_PID',
                'PRD_DTL_JSON' : 'Config.PS_JSON_DEPOSITS_DTL'
            },            
            'LOAN' : {
                'PRD_ID_PATH' : 'Config.PS_URL_LOANS_PID',
                'PRD_DTL_PATH' : 'Config.PS_URL_LOANS_DTL',
                'PRD_ID_JSON' : 'Config.PS_JSON_LOANS_PID',
                'PRD_DTL_JSON' : 'Config.PS_JSON_LOANS_DTL'
            }
        },
        Handler : {
            'REF_PRD_1' : {
                url : 'PRD_ID_PATH',
                method : 'refreshPrdIds'
            },
            'REF_PRD_2' : {
                url : 'PRD_DTL_PATH',
                method : 'refreshPrdIdItems'
            },
            'REF_PRD_3' : {
                url : 'CACHE',
                method : 'refreshPrdIdItem'
            },
        },
        Gateways : {
            'Gravitee' : {
                config : Config.PS_CFG_GIO
            },
            'Tyk' : {
                config : Config.PS_CFG_TYK
            } 
        }
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Mapping = Mapping;
}(window));