(function (window, document) {
	'use strict';

	var vs_namespace = 'api-key';

	//******************************************************************************
	//*                           Public function definitions                      *
	//******************************************************************************
	/**
	 * Store constructor function
	 *
	 * @constructor
	 */
	function Store() {
		//this._store = window.localStorage;
		this._store = window.localStorage;
		this._container = {};
	}

	/**
	 * Store prototype
	 */
    Store.prototype = {
		constructor: Store,

        _put : function(as_key, as_value) {
            if (this.isValidStore()) {
                this._store.setItem(as_key, JSON.stringify(as_value));
            }
        },

        _get : function(as_key, ab_unserial) {
            var lo_value;

            if (this.isValidStore()) {
                lo_value = this._store.getItem(as_key);

                if (lo_value) {
                    lo_value = JSON.parse(lo_value);
                }
            }

            return lo_value;
        },

        _remove : function(as_key) {
            if (this.isValidStore()) {
                if (as_key) {
                    this._store.removeItem(as_key);
                } else {
                    this._store.clear();
                }
            }
        },

        put : function(as_key, as_value) {
            if (this.isValidStore()) {
                this._container[as_key] = as_value;
            }
        },
        
        get : function(as_key, ab_unserial) {
            var lo_value;
            
            if (this.isValidStore()) {
                lo_value = this._container[as_key];
            }
            
            return lo_value; 
        },

        remove : function(as_key) {
            if (this.isValidStore()) {
                if (as_key) {
                     this._container[as_key] = null;
                } else {
                    this._container = {};
                }

                this._remove(vs_namespace);
            }
        },

        push : function() {
            this._put(vs_namespace, this._container);
        },

        pull : function() {
            this._container = this._get(vs_namespace, true) || {};
        },
        
        isValidStore : function() {
            return !!this._store;
        }
	};

	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
	window.Store = Store;

}(window, document));
