(function(window){
    'use strict';

    //******************************************************************************
    //*                             Config definitions                             *
    //******************************************************************************
    var Constants = window.Constants,    
        Config = {		
            PS_URL_GATEWAY : '',
            PS_URL_DEPOSITS_PID : '',
            PS_URL_DEPOSITS_DTL : '',
            PS_URL_LOANS_PID : '',
            PS_URL_LOANS_DTL : '',
            
            PS_JSON_DEPOSITS_PID : 'files/deposits-id.json',
            PS_JSON_DEPOSITS_DTL : 'files/deposits-dtl.json',
            PS_JSON_LOANS_PID : 'files/loans-id.json',
            PS_JSON_LOANS_DTL : 'files/loans-dtl.json', 
            
            PS_DEFAULT_GW : Constants.PS_GATEWAY_TYK,
            PS_DEFAULT_CONN : Constants.PS_CONN_DB,

            PS_CFG_TYK : 'js/common/config-tyk.js',
            PS_CFG_GIO : 'js/common/config-gio.js',
            
            PS_VERSION : '0.0.9.9',
            
            PI_REQ_TIMEOUT : 20000,
            PI_REQ_TIMEOUT_LONG : 600000,
            PB_IS_DEBUG : true
        };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Config = Config;
}(window));