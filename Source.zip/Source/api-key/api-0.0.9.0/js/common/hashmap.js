(function (window) {
	'use strict';

	//******************************************************************************
	//*                           Public function definitions                      *
	//******************************************************************************
	/**
	 * HashMap constructor function
	 *
	 * @constructor
	 */
	function HashMap() {
		this._map = {};
	}

	/**
	 * HashMap prototype
	 */
	HashMap.prototype = {
		constructor: HashMap,

		/**
		 * Add new object with {key:value}
		 *
		 * @param {String} as_key
		 * @param {Object} ao_value
		 */
		put: function (as_key, ao_value) {
			this._map[as_key] = ao_value;
		},

		/**
		 * Get value by key
		 *
		 * @param {String} as_key
		 *
		 * @returns {*}
		 */
		get: function (as_key) {
			if (this._map.hasOwnProperty(as_key)) {
				return this._map[as_key];
			} else {
				return null;
			}
		},

		/**
		 *  Remove value by key
		 * @param {String} as_key
		 *
		 * @returns {boolean}
		 */
		remove: function (as_key) {
			if (this._map.hasOwnProperty(as_key)) {
				return delete this._map[as_key];
			} else {
				return false;
			}
		},

		/**
		 * Remove all value
		 */
		removeAll: function () {
			this._map = {};
		},

		/**
		 * Get key set
		 *
		 * @returns {Array}
		 */
		keySet: function () {
			return Object.keys(this._map);
		},

		valueSet: function () {
			Object.values(this._map);
		},
        
        getMap : function() {            
            return this._map;
        }
	};

	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
	window.HashMap = HashMap;
}(window));
