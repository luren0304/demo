(function(window){
    'use strict';

    //******************************************************************************
    //*                      Util function definitions                             *
    //******************************************************************************
    var
        CommonUtil = {
        
            /**
             * Judge the value is null(undefined and null all is null value)
             *
             * @param {Object} ao_value
             *
             * @returns {boolean}
             */
            isNull : function(ao_value) {
                return ao_value == undefined || ao_value == null;
            },
        
            /**
             *  Judge the value is not null
             *
             * @param {Object} ao_value
             *
             * @returns {boolean}
             */
            isNotNull : function(ao_value) {
                return !this.isNull(ao_value);
            },
        
            /**
             *  Value is Array and length > 0
             *
             * @param ao_value
             *
             * @returns {boolean}
             */
            isValidArray : function(ao_value) {
                return this.isNotNull(ao_value) && Array.isArray(ao_value) && ao_value.length > 0
            },
        
            isValidDate : function(ao_value) {
                return StringUtil.isNotEmpty(ao_value) && (new Date(ao_value) != 'Invalid Date');
            },
            
            isValidObj : function(ao_value) {
                return this.isNotNull(ao_value) && (typeof ao_value === 'object');
            },
            
            isValidStr : function(ao_value) {
                return this.isNotNull(ao_value) && (typeof ao_value === 'string');
            },
        
            /**
             * Create dynamic html element
             *
             * @param {String} as_tag
             * @param {String} [as_html]
             * @param {String} [as_class]
             * @param {String} [as_id]
             *
             * @returns {*|jQuery|HTMLElement}
             */
            createElement : function(as_tag, as_html, as_class, as_id){
                var lo_element = $('<' + as_tag + '></' + as_tag + '>'),
                    lo_domElement = lo_element.get(0);
             
                if (as_id) {
                    lo_domElement.id = as_id;
                }
             
                if (as_html) {
                    lo_domElement.innerHTML = as_html;
                }
             
                if (as_class) {
                    lo_domElement.className = as_class;
                }
             
                return $(lo_domElement);
            },
        
            /**
             * Subtype inherit supper type properties and functions(can use instanceof to judge object type)
             *
             * @param {Object} ao_subType
             * @param {Object} [ao_superType]
             * @param {Object} [ao_subOptions]
             */
            $extends: function(ao_subType, ao_superType, ao_subOptions){
                var ls_propertyName,
                    lo_superPrototype = {},
                    lo_subPrototype = {},
                    F = function() {};
        
                // If have super type, will set super type prototype to new F Object
                if (ao_superType) {
                    lo_superPrototype = Object(ao_superType.prototype);
                    F.prototype = lo_superPrototype;
                }
        
                // Set F Object prototype to sub type prototype
                // If sub type prototype change will not affect super type
                if (ao_subType) {
                    ao_subType.prototype = new F();
                    lo_subPrototype = ao_subType.prototype;
                    lo_subPrototype.constructor = ao_subType;
                    lo_subPrototype.$super = lo_superPrototype;
        
                    // If sub type have function, will append to sub type prototype
                    if (ao_subOptions) {
                        for(ls_propertyName in ao_subOptions) {
                            lo_subPrototype[ls_propertyName] = ao_subOptions[ls_propertyName];
                        }
                    }
                }
            }
        },
        
        StringUtil = {
        
            /**
             *  Judge string if is empty
             *
             * @param {String} as_input
             *
             * @returns {boolean}
             */
            isEmpty : function(as_input){
                return CommonUtil.isNull(as_input) || /^[\s\n\t]*$/.test(as_input); 
            },
        
            /**
             *  Judge string if is not empty
             *
             * @param {String} as_input
             *
             * @returns {boolean}
             */
            isNotEmpty : function(as_input) {
                return !this.isEmpty(as_input);
            },
        
            /**
             *  Judge if contain special string
             *
             * @param {String} as_input
             * @param {String} as_search
             *
             * @returns {boolean}
             */
            $contain : function(as_input, as_search) {
         	      return as_input.indexOf(as_search) >= 0;
            },
        
            /**
             * Append some char before/after string
             *
             * @param {Object} ao_value
             * @param {Number} [ai_length] default is 0
             * @param {String} [as_char] default is ''
             * @param {boolean} [ab_append] default is false
             *
             * @returns {String}
             */
            fillChar: function(ao_value, ai_length, as_char, ab_append) {
                var ls_value = String(ao_value),
                    li_length = ai_length || 0,
                    ls_char = as_char || '';
          
                while (ls_value.length < li_length) {
          	         if (ab_append) {
                        ls_value += ls_char;
          	         } else {
          	             ls_value = ls_char + ls_value;
          	         }
                }
          
                return ls_value;
            },
          
        /**
        * Fill some ellipsis char in special index
             *
        * @param {Object} ai_startLength
        * @param {Object} ai_endLength
        * @param {Object} as_input
             *
        * @return {String}
        */
        fillEllipsis : function(ai_startLength, ai_endLength, as_input) {
            var ls_ellipsisInput = '',
                ls_input = as_input || '',
                ls_start = '',
                ls_end = '',
                li_startLength = ai_startLength || 0,
                li_endLength = ai_endLength || 0,
                li_inputLength = ls_input.length;
          
            if (li_inputLength > (li_startLength + li_endLength )) {
          	     ls_start = ls_input.substr(0, li_startLength);
          	     ls_end = ls_input.substr(li_inputLength - li_endLength, li_endLength);
          	     ls_ellipsisInput = ls_start + '...' + ls_end;	        	
            } else {
          	     ls_ellipsisInput = ls_input;
            }
          
            return ls_ellipsisInput;
        },
        
        /**
         * If value length not enough, will fill with zero
         *
         * @param {Object} ao_value
         * @param {Number} [ai_length] default is 2
         * @param {boolean} [ab_append] default is false
         *
         * @returns {String}
         */
        zeroize : function(ao_value, ai_length, ab_append) {
            var li_length = ai_length || 2;
        
            return StringUtil.fillChar(ao_value, li_length, '0', ab_append);
        },
        
        /**
         *  Add thousand characters
         *
         * @param ao_value
         *
         * @returns {String}
         */
        toThousandth : function(ao_value) {
             var ls_value = String(ao_value),
                 l_reg;
             
             if (!isNaN(ls_value)) {         
                 if (ls_value.indexOf('.') > -1) {
                     l_reg = /(\d{1,3})(?=(?:\d{3})+\.)/g;
                 } else {
                     l_reg = /(\d{1,3})(?=(?:\d{3})+$)/g;
                 }
                 
                 return ls_value.replace(l_reg, '$1,');
             } else {
                 return ao_value;
             }
         },
        
        /**
         * Keep few decimal places, not enough fill zero
         *
         * @param {Object} ao_value
         * @param {Number} ai_decimal default is 2
         *
         * @returns {Object|Number}
         */
        toDecimal : function(ao_value, ai_decimal) {
            var ls_value = String(ao_value),
                li_decimal = ai_decimal || 2;
             
            if (isNaN(ls_value) || isNaN(li_decimal)) {
             	  return ao_value;
            } else {
             	  if (li_decimal < 0 || li_decimal >= 100) {
             		     return ao_value;
             	  } else {
             		     return Number(ls_value).toFixed(li_decimal);     
             	  }
            }
        },
        
        /**
         *  Date formatting, if not set date, will get current date
         *
         *  @example :
         *  d/dd -> digit date, ddd -> english simple date, dddd -> english full date
         *  M/MM -> digit month, MMM -> english simple month, MMMM -> english full month
         *  yy -> last two position of digit year, yyyy -> full digit year
         *  h -> 12 digit simple hour, hh -> 12 digit full hour, H -> 24 digit simple hour, HH -> 24 digit full hour
         *  m -> digit simple minute, mm -> digit full minute
         *  s -> digit simple second, ss -> digit full second
         *  L -> digit simple millisecond, l -> digit full millisecond
         *  tt -> am/pm, TT -> AM/PM
         *  Z -> UTC
         *
         * @param {String} as_mask
         * @param {Date} [a_date]
         *
         * @returns {Object|String}
         */
        dateFormat : function(as_mask, a_date){
            var l_date = a_date || new Date(),
                lf_zeroize = this.zeroize;
        
            return as_mask.replace(/'[^']*'|'[^']*'|\b(?:d{1,4}|M{1,4}|yy(?:yy)?|([hHmstT])\1?|[lLZ])\b/g, function (as_format) {
                switch (as_format) {
                    case 'd'    :
                        return l_date.getDate();
                    case 'dd'   :
                        return lf_zeroize(l_date.getDate());
                    case 'ddd'  :
                        return ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'][l_date.getDay()];
                    case 'dddd' :
                        return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][l_date.getDay()];
                    case 'M'    :
                        return l_date.getMonth() + 1;
                    case 'MM'   :
                        return lf_zeroize(l_date.getMonth() + 1);
                    case 'MMM'  :
                        return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][l_date.getMonth()];
                    case 'MMMM' :
                        return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][l_date.getMonth()];
                    case 'yy'   :
                        return String(l_date.getFullYear()).substr(2);
                    case 'yyyy' :
                        return l_date.getFullYear();
                    case 'h'    :
                        return l_date.getHours() % 12 || 12;
                    case 'hh'   :
                        return lf_zeroize(l_date.getHours() % 12 || 12);
                    case 'H'    :
                        return l_date.getHours();
                    case 'HH'   :
                        return lf_zeroize(l_date.getHours());
                    case 'm'    :
                        return l_date.getMinutes();
                    case 'mm'   :
                        return lf_zeroize(l_date.getMinutes());
                    case 's'    :
                        return l_date.getSeconds();
                    case 'ss'   :
                        return lf_zeroize(l_date.getSeconds());
                    case 'l'    :
                        return lf_zeroize(l_date.getMilliseconds(), 3);
                    case 'L'    :
                        var m = l_date.getMilliseconds();
                        m = m > 99 ? Math.round(m / 10) : m;
        
                        return lf_zeroize(m);
                    case 'tt'   :
                        return l_date.getHours() < 12 ? 'am' : 'pm';
                    case 'TT'   :
                        return l_date.getHours() < 12 ? 'AM' : 'PM';
                    case 'Z'    :
                        return l_date.toUTCString().match(/[A-Z]+$/);   
                    default     :
                        return as_format.substr(1, as_format.length - 2);
                }
            });
        },
        
        contentFormat : function(ao_regex, as_content, aa_params) {
            var la_params = aa_params.slice(),
                ls_param;
            
            return as_content.replace(ao_regex, function(as_match) {
                if (CommonUtil.isValidArray(la_params)) {
                    return la_params.shift();
                } else {
                    return as_match;
                }                
            });
        },
        
        messageFormat : function(as_msg, aa_params) {
            var ls_formatMsg = as_msg;
         	
            ls_formatMsg = this.contentFormat(/{\w+}/g, as_msg, aa_params);
            
         	return ls_formatMsg;
        },
        
        notEmptyMessage : function(ao_value) {
            return StringUtil.messageFormat(Constants.CS_MSG_NOT_EMPTY, ao_value);
        },
        
        noErrorCodeMessage : function(as_errorCode, as_errorMsg) {
            var ls_errorCode = as_errorCode || '',
                ls_errorMsg = as_errorMsg || '',
                li_errorCodeIndex;
    
            li_errorCodeIndex = ls_errorMsg.indexOf(ls_errorCode);
    
            if (li_errorCodeIndex >= 0) {
                ls_errorMsg = ls_errorMsg.substring(li_errorCodeIndex + ls_errorCode.length)
            }
    
            return ls_errorMsg;
        }
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    (function main() {
        window.CommonUtil = CommonUtil;
        window.StringUtil = StringUtil;
    }());

}(window));
