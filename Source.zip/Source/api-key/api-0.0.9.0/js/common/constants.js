(function(window){
    'use strict';

    //******************************************************************************
    //*                             Constants definitions                          *
    //******************************************************************************
    var Constants = {
        PS_PRD_DEPOSITS : 'DEPOSIT',
        PS_PRD_LOANS : 'LOAN',
        PS_MDL_ABOUT : 'ABOUT',
        PS_MDL_SETTING : 'SETTING',

        PS_KEY_PRD_ID : 'prodId',
        PS_KEY_API_KEY : 'API_KEY',
        PS_KEY_CONFIG : 'CONFIG',
        PS_KEY_GATEWAY : 'GATEWAY',
        PS_KEY_VERSION : 'VERSION',
        PS_KEY_TIMEOUT : 'TIMEOUT',
        PS_KEY_CONNECTION : 'CONNECTION',
        
        PS_GATEWAY_GIO : 'Gravitee',
        PS_GATEWAY_TYK : 'Tyk',

        PS_CONN_DB : 'DB',
        PS_CONN_FTP : 'FTP',
        
        PS_CACHE : 'CACHE',  

        PS_VAL_YES : 'Yes',
        PS_VAL_NO : 'No',

        //PS_HEADER_CONN : 'connection-type',
        PS_HEADER_CONN : 'tyk-conn-type',
        
        PS_MSG_PULLDOWN_REFERSH : 'Pulldown refresh!',
        PS_MSG_PULLUP_REFERSH : 'Pullup refresh!',
        PS_MSG_RELEASE_REFERSH : 'Release refresh!',
        PS_MSG_LOADING : 'Loading...',
        PS_MSG_NO_MORE_RECORD : 'No more record!',
        PS_MSG_NO_FOUND_RECORD : 'Not found any record',
        PS_MSG_RECORD_UPDATED : 'Records have been updated!',
        PS_MSG_REQ_NO_SENT : 'Request send failed, please check the service if is running!',
        PS_MSG_REQ_TIMEOUT : 'Request is timeout!',
        PS_MSG_NO_STORE : 'Current browser not support the localStorage(only support IE9+, Chrome and Firefox)!',
        PS_MSG_CFG_UPDATE : '{cfg} config has been updated!', 
        PS_MSG_CFG_CHANGE : 'Are you sure to change config to {cfg}(will override old config)?',
        PI_CODE_BAD_REQ : 400,
        PI_CODE_NO_AUTH : 401,
        PI_CODE_NO_ALLOW : 403,
        PI_CODE_SERVER_ERR : 500
    };

    //******************************************************************************
    //*                           Internal Execute Function                        *
    //******************************************************************************
    window.Constants = Constants;
}(window));