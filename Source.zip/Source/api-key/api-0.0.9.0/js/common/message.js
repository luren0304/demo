(function (window, document, layer, mui) {
	'use strict';

    //******************************************************************************
    //*                      Message function definitions                             *
    //******************************************************************************
    var
        Message = {
            /**
             * Clear all display dialog
             */
            clearLayer: function () {
                layer.closeAll();
            },
            
            /**
             * Show information message
             *
             * @param {String} as_message
             * @param {Object} [ao_option]
             */
            showInfoMsg: function (as_message, ao_option) {
                var lo_option = ao_option,
                    lo_defaultOption = {
                        icon: 1,
                        time: 1000,
                        end: undefined
                    };

                if (lo_option) {
                    if (!lo_option.icon) {
                        lo_option.icon = lo_defaultOption.icon;
                    }

                    if (!lo_option.time) {
                        lo_option.time = lo_defaultOption.time;
                    }

                    if (lo_option.callback) {
                        lo_option.end = lo_option.callback;
                    }

                    layer.msg(as_message, lo_option);
                } else {
                    layer.msg(as_message, lo_defaultOption);
                }
            },
            
            showInfoMsg2: function (as_message, as_title, af_callback) {
                layer.info(as_message, as_title, function () {
                    layer.closeAll();

                    if (af_callback) {
                        af_callback();
                    }
                });
            },
            
            /**
             * Show error message(Only one error message will be popup)
             *
             * @param {String} as_message
             * @param {String} [as_title]
             */
            showErrorMsg: function (as_message, as_title, af_callback) {
                layer.error(as_message, as_title, function () {
                    layer.closeAll();

                    if (af_callback) {
                        af_callback();
                    }
                });
            },
            
            showMuiErrorMsg : function(as_message, as_title, af_callback) {
                var la_btn = ['OK'],
                    ls_title = as_title || 'Error';
                
                mui.alert(as_message, ls_title, la_btn, af_callback);
            },
                
            /**
             * Show confirm message
             *
             * @param {String} as_message
             * @param {String} [as_title]
             * @param {Function} [af_callback]
             */
            showConfirmMsg: function (as_message, as_title, af_callback) {
                layer.confirm(as_message, as_title, af_callback);                
            },
            
            showMuiConfirmMsg : function(as_message, as_title, af_callback) {
                var la_btn = ['Yes', 'No'],
                    ls_title = as_title || 'Confirm';
                
                mui.confirm(as_message, ls_title, la_btn, af_callback);
            }
        };

    
	//******************************************************************************
	//*                           Internal Execute Function                        *
	//******************************************************************************
	window.Message = Message;

}(window, document, layer, mui));
