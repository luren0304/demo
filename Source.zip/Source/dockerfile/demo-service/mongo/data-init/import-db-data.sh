cd /data-init
pattern="./"
folderpattern="/"
initpattern="data-init"
for D in `find . -type d`
do	
   folder=${D#$pattern}
   echo "Reading folder ${folder}"
   ls -1 ${folder}/*.json | sed 's/.json$//' | while read col; do 
        filename=${col#$folder}
        echo "Read folder ${folder#initpattern} and file .${filename}.json" 
        filename=${filename#$folderpattern}
        mongoimport -h mongo -d ${filename%-*} -c ${filename##*-} --file ${filename}.json
   done
done

# import loans collection
#mongoimport -d excel-demo -c deposits --file excel-demo-deposits.json
# import loans collection
#mongoimport -d excel-demo -c loans --file excel-demo-loans.json
# import fieldMapping collection
#mongoimport -d excel-demo -c fieldMapping --file excel-demo-fieldMapping.json