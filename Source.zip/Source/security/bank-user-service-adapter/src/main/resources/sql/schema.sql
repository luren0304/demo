CREATE SCHEMA IF NOT EXISTS `userinfo` DEFAULT CHARACTER SET utf8 ;
USE `userinfo` ;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`.`user`;
CREATE TABLE `userinfo`.`user` (
  `userId` int(50) NOT NULL AUTO_INCREMENT,
  `userName` varchar(50) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;