package com.excelhk.openapi.bankuserserviceadapter.controller;

import com.excelhk.openapi.bankuserserviceadapter.security.PasswordCrypt;
import com.excelhk.openapi.bankuserserviceadapter.bean.User;
import com.excelhk.openapi.bankuserserviceadapter.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Controller to operate user
 *
 * @author zhoulicheng
 * @date 2019/1/22
 */
@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/registerUser")
    @ResponseBody
    public String registerUser(HttpServletRequest request){
        String username = request.getParameter("username");
        String userpassword = request.getParameter("userpassword");
        String useremail = request.getParameter("useremail");
        User user = new User();
        user.setUserName(username);
        user.setPassword(userpassword);
        user.setEmail(useremail);
        int iFlag = userService.insertSelective(user);
        if(iFlag == 0){
            return "failed";
        }
        return "success";
    }


    @RequestMapping("/verifyUserByName")
    @ResponseBody
    public Boolean verifyUserByUsername(String username){
        User user =  userService.getUserDetailByUsername(username);
        if(user == null){
            return false;
        }
        return true;
    }

    @RequestMapping("/verifyUserByNameAndPwd")
    @ResponseBody
    public Boolean verifyUserByNameAndPwd(String username,String password){
        User user =  userService.getUserDetailByUsername(username);
        if(user == null){
            return false;
        }
        if (!PasswordCrypt.matcher(password,user.getPassword())){
            return false;
        }
        return true;
    }

    @RequestMapping("/user")
    public String forward(){
        return "Register";
    }



}
