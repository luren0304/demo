package com.excelhk.openapi.bankuserserviceadapter.service;

import com.excelhk.openapi.bankuserserviceadapter.bean.User;

/**
 * service for user
 *
 * @author  zhoulicheng
 * @date  2019/1/22
 * */
public interface UserService {
    /**
     * get user message by username
     *
     * @param vsUsername
     * @return User
     * */
    public User getUserDetailByUsername(String vsUsername);

    /**
     * insert user message into database
     *
     * @param record
     * @return int
     * */
    public int insertSelective(User record);
}
