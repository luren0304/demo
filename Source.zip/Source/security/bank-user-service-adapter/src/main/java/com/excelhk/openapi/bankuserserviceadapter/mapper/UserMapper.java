package com.excelhk.openapi.bankuserserviceadapter.mapper;

import com.excelhk.openapi.bankuserserviceadapter.bean.User;
import org.springframework.stereotype.Repository;

/**
 * operate user data in database
 *
 * @author zhoulicheng
 * @date 2019/1/22
 */
@Repository
public interface UserMapper {
    /**
     * register app for oauth client details
     *
     * @param record register message
     * @return int
     * */
    int insertSelective(User record);

    /**
     * register app for oauth client details
     *
     * @param vsUsername register message
     * @return User
     * */
    User getUserDetailByUsername(String vsUsername);

}