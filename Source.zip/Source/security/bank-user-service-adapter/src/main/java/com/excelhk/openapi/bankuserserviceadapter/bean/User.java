package com.excelhk.openapi.bankuserserviceadapter.bean;

import com.excelhk.openapi.bankuserserviceadapter.security.PasswordCrypt;

/**
 * User entity
 *
 * @author zhoulicheng
 * @date 2019/1/22
 */
public class User {
    private int viUserId;

    private String vsUserName;

    private String vsPassword;

    private String vsEmail;

    public void setUserId(int aiUserId) {
        this.viUserId = aiUserId;
    }

    public String getUserName() {
        return vsUserName;
    }

    public void setUserName(String asUserName) {
        this.vsUserName = asUserName;
    }

    public String getPassword() {
        return vsPassword;
    }

    public void setPassword(String asPassword) {
        this.vsPassword = PasswordCrypt.encode(asPassword);
    }

    public String getEmail() {
        return vsEmail;
    }

    public void setEmail(String email) {
        this.vsEmail = email;
    }


}