package com.excelhk.openapi.bankuserserviceadapter.service;

import com.excelhk.openapi.bankuserserviceadapter.bean.User;
import com.excelhk.openapi.bankuserserviceadapter.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * service to operate user
 *
 * @author zhoulicheng
 * @date 2019/1/22
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public int insertSelective(User record) {
       return userMapper.insertSelective(record);
    }

    @Override
    public User getUserDetailByUsername(String vsUsername) {

        User user =  userMapper.getUserDetailByUsername(vsUsername);
        return user;
    }

}
