package com.excelhk.openapi.bankuserserviceadapter.security;


import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * security  password encoder
 *
 * @author zhoulicheng
 * @date 2019/1/22
 */
@Component
public class PasswordCrypt {

    private static PasswordEncoder v_crypt = new BCryptPasswordEncoder();

    public static String encode(String asRawPassword) {
        return v_crypt.encode(asRawPassword);
    }

    public static boolean matcher(String asRawPassword, String asEncodedPassword) {
        return v_crypt.matches(asRawPassword, asEncodedPassword);
    }

    public static PasswordEncoder getPasswordEncoder() {
        return v_crypt;
    }


}

