package com.excelhk.openapi.bankuserserviceadapter.controller;

import com.excelhk.openapi.bankuserserviceadapter.BankuserserviceadapterApplicationTests;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@Transactional
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserControllerTest {
    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void registerUser() throws Exception{
        MultiValueMap<String,String> valueMap = new LinkedMultiValueMap();
        valueMap.add("username","abc");
        valueMap.add("userpassword","abc");
        valueMap.add("useremail","abc");
        String responseString = mockMvc.perform(post("/registerUser")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED) //数据格式
                        .params(valueMap)  //请求的参数
        ).andExpect(status().isOk()) //返回的状态200
                .andDo(print())
                .andReturn().getResponse().getContentAsString();
        System.out.println(responseString);
    }

    @Test
    public void verifyUserByUsername() throws Exception{
        String responseString = mockMvc.perform(post("/verifyUserByName")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED) //数据格式
                .param("username","abc")  //请求的参数
        ).andExpect(status().isOk()) //返回的状态200
                .andDo(print())
                .andReturn().getResponse().getContentAsString();
        System.out.println(responseString);
    }

    @Test
    public void verifyUserByNameAndPwd() throws Exception{
        MultiValueMap<String,String> valueMap = new LinkedMultiValueMap();
        valueMap.add("username","admin");
        valueMap.add("password","admin");
        String responseString = mockMvc.perform(get("/verifyUserByNameAndPwd")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED) //数据格式
                .params(valueMap)  //请求的参数
        ).andExpect(status().isOk()) //返回的状态200
                .andDo(print())
                .andReturn().getResponse().getContentAsString();
        System.out.println(responseString);
    }

    @Test
    public void setPassword() {
    }
}