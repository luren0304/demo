package com.excelhk.openapi.bankuserserviceadapter;

import com.excelhk.openapi.bankuserserviceadapter.bean.User;
import com.excelhk.openapi.bankuserserviceadapter.service.UserService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@RunWith(SpringRunner.class)
@SpringBootTest
public class BankuserserviceadapterApplicationTests {

    @Autowired
    private UserService userService;

    @Test
    public void insertSelectiveTest(){
        User user = new User();
        user.setUserName("aaa");
        user.setPassword("aaa");
        user.setEmail("aaa");
        Assert.assertNotEquals(0,userService.insertSelective(user));
    }

    @Test
    public void getUserDetailByUsernameTest(){
        Assert.assertNotNull(userService.getUserDetailByUsername("admin"));
        Assert.assertNull(userService.getUserDetailByUsername("notexist"));
    }

    @Test
    public void contextLoads() {
    }
}

