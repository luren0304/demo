package com.excelhk.openapi.bankuserserviceadapter;

import com.excelhk.openapi.bankuserserviceadapter.controller.UserControllerTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({UserControllerTest.class,BankuserserviceadapterApplicationTests.class})
public class SuitTest {
}
