package com.excelhk.openapi.clientregisterservice.controller;

import com.excelhk.openapi.clientregisterservice.util.SkipSslVerificationHttpRequestFactory;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.client.BaseClientDetails;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.util.*;

/**
 * Controller for register app
 *
 * @author zhoulicheng
 * @date 2019/1/22
 * */
@Controller
public class RegisterController {

    @Autowired
    private DataSource dataSource;
    @Autowired
    private Environment environment;

    @RequestMapping("/validateAppName")
    @ResponseBody
    public boolean validateAppName(HttpServletRequest request) {
        String oauthApplicationName = request.getParameter("oauthApplicationName");
        JdbcClientDetailsService jdbcClientDetailsService = new JdbcClientDetailsService(dataSource);
        List<ClientDetails> list = jdbcClientDetailsService.listClientDetails();
        for (ClientDetails clientDetails : list) {
            Object applicationName = clientDetails.getAdditionalInformation().get("applicationName");
            if (oauthApplicationName == applicationName.toString()) {
                return true;
            }
        }
        return false;
    }
    /**
     * forward to register page
     *
     * @return String
     * */
    @RequestMapping("/client")
    public String register() {

        return "Register";
    }

    /**
     * register app for oauth client details
     *
     * @param request register message
     * @param  model
     * @return String
     * */
    @RequestMapping(value = "/addRegisterMsg")
    public String addRegisterMsg(HttpServletRequest request,Model model) {
        JdbcClientDetailsService registerClientDetails = new JdbcClientDetailsService(dataSource);

        String oauthAppName = request.getParameter("oauth_application[name]");
        String oauthAppDesc = request.getParameter("oauth_application[description]");
        String oauthAppCallbackUrl = request.getParameter("oauth_application[callback_url]");
        String[] permissions = request.getParameterValues("oauth_application[permission]");

        Collection authorizedScope = null;
        if(permissions != null){
            authorizedScope = Arrays.asList(permissions);
        }

        RestTemplate restTemplate = new RestTemplate(new SkipSslVerificationHttpRequestFactory());
        //get api id
        String lsParamAuthorization = environment.getProperty("client.request.parameter.authorization");

        //headers authorization
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add("authorization", lsParamAuthorization);
        //HttpEntity
        HttpEntity requestEntityForId = new HttpEntity(requestHeaders);

        String urlForId = environment.getProperty("client.api.url") + "?q=" +environment.getProperty("client.request.parameter.q");
        ResponseEntity<String> appEntity = restTemplate.exchange(urlForId, HttpMethod.GET,requestEntityForId,String.class);

        String lsApis = JSONObject.fromObject(appEntity.getBody()).getString("apis");
        String lsApiDefinition = JSONObject.fromObject(lsApis.substring(1, lsApis.length() - 1)).getString("api_definition");
        String lsId = JSONObject.fromObject(lsApiDefinition).getString("id");

        String urlForClientId = environment.getProperty("client.clientid.url") + lsId;

        //body
        Map requestBody = new HashMap(2);
        requestBody.put("redirectUri", oauthAppCallbackUrl);
        //HttpEntity
        HttpEntity requestEntity = new HttpEntity(requestBody, requestHeaders);
        //post
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(urlForClientId, requestEntity, String.class);

        String clientId = JSONObject.fromObject(responseEntity.getBody()).getString("clientId");
        String clientSecret = JSONObject.fromObject(responseEntity.getBody()).getString("secret");
        String redirectUri = JSONObject.fromObject(responseEntity.getBody()).getString("redirectUri");

        Map<String, String> mapAppName = new HashMap(4);
        mapAppName.put("applicationName", oauthAppName);
        mapAppName.put("application_desc", oauthAppDesc);

        Set<String> setRedirectUri = new HashSet();
        setRedirectUri.add(oauthAppCallbackUrl);


        BaseClientDetails clientDetails = new BaseClientDetails();
        clientDetails.setClientId(clientId);
        clientDetails.setClientSecret(clientSecret);
        clientDetails.setAdditionalInformation(mapAppName);
        clientDetails.setRegisteredRedirectUri(setRedirectUri);
        clientDetails.setScope(authorizedScope);
        registerClientDetails.addClientDetails(clientDetails);

        model.addAttribute("redirectUri", redirectUri);
        model.addAttribute("clientDetails", clientDetails);

        return "RegisterMsg";
    }
}
