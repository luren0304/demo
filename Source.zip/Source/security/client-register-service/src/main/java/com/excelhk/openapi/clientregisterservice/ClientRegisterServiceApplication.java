package com.excelhk.openapi.clientregisterservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientRegisterServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientRegisterServiceApplication.class, args);
    }

}

