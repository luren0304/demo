package com.excelhk.openapi.clientregisterservice.util;

import org.springframework.http.client.SimpleClientHttpRequestFactory;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 * for skip https ssl verification
 *
 * @author zhoulicheng
 * @date 2019/1/22
 */
public class SkipSslVerificationHttpRequestFactory extends SimpleClientHttpRequestFactory {
    @Override
    protected void prepareConnection(HttpURLConnection httpURLConnection, String asHttpMethod) throws IOException {
        if (httpURLConnection instanceof HttpsURLConnection) {
            prepareHttpsConnection((HttpsURLConnection) httpURLConnection);
        }
        super.prepareConnection(httpURLConnection, asHttpMethod);
    }

    private void prepareHttpsConnection(HttpsURLConnection httpURLConnection) {
        httpURLConnection.setHostnameVerifier(new SkipHostnameVerifier());
        try {
            httpURLConnection.setSSLSocketFactory(createSslSocketFactory());
        } catch (Exception ex) {
            // Ignore
        }
    }

    private SSLSocketFactory createSslSocketFactory() throws Exception {
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[] { new SkipX509TrustManager() },
                new SecureRandom());

        return sslContext.getSocketFactory();
    }

    private class SkipHostnameVerifier implements HostnameVerifier {

        @Override
        public boolean verify(String s, SSLSession sslSession) {
            return true;
        }

    }

    private class SkipX509TrustManager implements X509TrustManager {

        @Override
        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
}
