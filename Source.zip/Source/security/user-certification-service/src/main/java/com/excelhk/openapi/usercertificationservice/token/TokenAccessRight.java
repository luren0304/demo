package com.excelhk.openapi.usercertificationservice.token;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Set;

public class TokenAccessRight implements Serializable, Cloneable {

    private String vs_apiName;
    private String vs_apiId;
    private Set<String> vss_versions;

    public TokenAccessRight() {}

    public TokenAccessRight(String as_apiName, String as_apiId, Set<String> ass_versions) {
        this.vs_apiName = as_apiName;
        this.vs_apiId = as_apiId;
        this.vss_versions = ass_versions;
    }

    @JsonProperty("api_name")
    public String getApiName() {
        return vs_apiName;
    }

    public void setApiName(String apiName) {
        this.vs_apiName = apiName;
    }

    @JsonProperty("api_id")
    public String getApiId() {
        return vs_apiId;
    }

    public void setApiId(String apiId) {
        this.vs_apiId = apiId;
    }

    @JsonProperty("versions")
    public Set<String> getVersions() {
        return vss_versions;
    }

    public void setVersions(Set<String> versions) {
        this.vss_versions = versions;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
