package com.excelhk.openapi.usercertificationservice.dao.impl;

import com.excelhk.openapi.usercertificationservice.common.SerializationUtils;
import com.excelhk.openapi.usercertificationservice.dao.IUserApprovalDao;
import com.excelhk.openapi.usercertificationservice.entity.UserApproval;
import com.excelhk.openapi.usercertificationservice.sql.SqlConstants;
import com.excelhk.openapi.usercertificationservice.token.TokenKeyRule;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Repository
public class UserApprovalDaoImpl extends BaseDaoImpl implements IUserApprovalDao {

    private static final String VS_PARAM_EXPIRES_AT = "expiresAt";
    private static final String VS_PARAM_USER_ID = "userId";
    private static final String VS_PARAM_CLIENT_ID = "clientId";
    private static final String VS_PRAM_KEY_RULES = "keyRules";

    private boolean handleRevocationsAsExpiry = false;

    @Override
    public boolean addUserApprovals(UserApproval a_userApproval) {
        boolean lb_success = true;

        if (!updateUserApproval(getSql(SqlConstants.CS_SQL_USER_APPROVE_UPDATE), a_userApproval)) {
            if (!updateUserApproval(getSql(SqlConstants.CS_SQL_USER_APPROVE_ADD), a_userApproval)) {
                lb_success = false;
            }
        }

        return lb_success;
    }

    @Override
    public boolean revokeUserApprovals(UserApproval a_userApproval) {
        boolean success = true;

        if (handleRevocationsAsExpiry) {
            success = updateUserApproval(getSql(SqlConstants.CS_SQL_USER_APPROVE_UPDATE_EXPIRED), a_userApproval);
        } else {
            success = updateUserApproval(getSql(SqlConstants.CS_SQL_USER_APPROVE_DELETE), a_userApproval);
        }

        return success;
    }

    @Override
    public boolean purgeExpiredUserApprovals() {
        Map<String, Object> lhm_paramMap = new HashMap<String, Object>();
        lhm_paramMap.put(VS_PARAM_EXPIRES_AT, new Timestamp(System.currentTimeMillis()));

        return update(getSql(SqlConstants.CS_SQL_USER_APPROVE_DELETE_EXPIRED), lhm_paramMap);
    }

    @Override
    public UserApproval getUserUnexpiredApproval(String userName, String clientId) {
        UserApproval l_userApproval = null;
        TokenKeyRule l_tokenKeyRule = null;

        String ls_sql = getSql(SqlConstants.CS_SQL_USER_APPROVE_SEARCH);

        Map<String, Object> lhm_paramMap = new HashMap<String, Object>();
        lhm_paramMap.put(VS_PARAM_USER_ID, userName);
        lhm_paramMap.put(VS_PARAM_CLIENT_ID, clientId);
        lhm_paramMap.put(VS_PARAM_EXPIRES_AT, new Timestamp(System.currentTimeMillis()));

        try {

            l_tokenKeyRule = getJdbcTemplate().queryForObject(ls_sql, lhm_paramMap, new RowMapper<TokenKeyRule>() {
                @Override
                public TokenKeyRule mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return SerializationUtils.deserialize(rs.getBytes(VS_PRAM_KEY_RULES));
                }
            });
        } catch (EmptyResultDataAccessException exception) {
            // eat it
        }

        if (l_tokenKeyRule != null) {
            l_userApproval = new UserApproval();
            l_userApproval.setKeyRules(l_tokenKeyRule);
        }

        return l_userApproval;
    }

    private boolean updateUserApproval(String sql, UserApproval approval) {
        Map<String, Object> lhm_paramMap = new HashMap<String, Object>();

        if (approval.getExpiresAt() != null) {
            lhm_paramMap.put(VS_PARAM_EXPIRES_AT, new Timestamp(approval.getExpiresAt().getTime()));
        }

        if (approval.getKeyRules() != null) {
            lhm_paramMap.put(VS_PRAM_KEY_RULES, new SqlParameterValue(Types.BLOB, new SqlLobValue(SerializationUtils.serialize(approval.getKeyRules()))));
        }

        lhm_paramMap.put(VS_PARAM_USER_ID, approval.getUserId());
        lhm_paramMap.put(VS_PARAM_CLIENT_ID, approval.getClientId());

        return this.update(sql, lhm_paramMap);
    }
}
