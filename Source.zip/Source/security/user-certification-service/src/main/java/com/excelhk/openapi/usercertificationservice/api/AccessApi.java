package com.excelhk.openapi.usercertificationservice.api;

import java.util.List;

public class AccessApi {
    private List<Api> vl_apis;

    public AccessApi() {}

    public List<Api> getApis() {
        return vl_apis;
    }

    public void setApis(List<Api> al_apis) {
        this.vl_apis = al_apis;
    }
}
