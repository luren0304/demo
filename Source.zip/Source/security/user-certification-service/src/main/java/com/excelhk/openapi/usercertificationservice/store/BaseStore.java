package com.excelhk.openapi.usercertificationservice.store;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;

public abstract class BaseStore {
    private String vs_alias;
    private int vi_count;

    @Autowired
    private Environment v_environment;

    @PostConstruct
    public void init() {
        String ls_keyPrefix;

        int li_keyIndex;

        if (vi_count > 0) {
            for (li_keyIndex = 1; li_keyIndex <= vi_count; li_keyIndex ++) {
                ls_keyPrefix = vs_alias + "." + li_keyIndex + ".";

                loadPropertiesData(ls_keyPrefix);
            }
        }
    }

    protected String getPropertiesValue(String as_key) {
        return v_environment.getProperty(as_key);
    }

    protected abstract void loadPropertiesData(String as_prefix);

    public String getAlias() {
        return vs_alias;
    }

    public void setAlias(String as_alias) {
        this.vs_alias = as_alias;
    }

    public int getCount() {
        return vi_count;
    }

    public void setCount(int count) {
        this.vi_count = count;
    }

}
