package com.excelhk.openapi.usercertificationservice.sql;

import java.util.HashMap;

public class UserApprovalSqlConstants {

    public static void loadSql(HashMap<String, String> ahm_sqlPool) {

        ahm_sqlPool.put(SqlConstants.CS_SQL_USER_APPROVE_SEARCH,
            " SELECT" +
                " keyRules" +
                " FROM oauth_user_approvals" +
            " WHERE 1=1" +
                " AND userId = :userId" +
                " AND clientId = :clientId" +
                " AND expiresAt > :expiresAt"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_USER_APPROVE_ADD,
            " INSERT INTO oauth_user_approvals" +
                " (" +
                    " userId," +
                    " clientId," +
                    " expiresAt," +
                    " keyRules" +
                " )" +
                " VALUES" +
                " (" +
                    ":userId, :clientId, :expiresAt, :keyRules" +
                " )"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_USER_APPROVE_DELETE,
            " DELETE FROM oauth_user_approvals " +
            " WHERE 1=1" +
                " AND userId = :userId" +
                " AND clientId = :clientId"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_USER_APPROVE_DELETE_EXPIRED,
            " DELETE FROM oauth_user_approvals " +
            " WHERE 1=1" +
                " AND expiresAt <= :expiresAt"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_USER_APPROVE_UPDATE,
            " UPDATE oauth_user_approvals SET" +
                " expiresAt = :expiresAt," +
                " keyRules = :keyRules" +
            " WHERE 1=1" +
                " AND userId = :userId" +
                " AND clientId = :clientId"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_USER_APPROVE_UPDATE_EXPIRED,
            " UPDATE oauth_user_approvals SET" +
                " expiresAt = :expiresAt" +
            " WHERE 1=1" +
                " AND userId = :userId" +
                " AND clientId = :clientId"
        );
    }
}
