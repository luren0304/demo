package com.excelhk.openapi.usercertificationservice.common;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JsonUtil {
	
	private static ObjectMapper vom_json = new ObjectMapper();
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	
	static {
		// Null and Empty value are not display
		vom_json.setSerializationInclusion(Include.NON_NULL);
		vom_json.setSerializationInclusion(Include.NON_EMPTY);
	}
	
    public static Object toJavaBean(String as_json, Class<?> a_clz) throws Exception {
		return vom_json.readValue(as_json, a_clz);
	}
	
	public static String toJsonStr(Object ao_source) throws Exception {
		return vom_json.writeValueAsString(ao_source);
	}
	
	public static String toJsonStrWithFormat(Object ao_source) throws Exception {
		return vom_json.writerWithDefaultPrettyPrinter().writeValueAsString(ao_source);
	}

    public static class JsonDateDeserializer extends StdDeserializer<Date> {

        public JsonDateDeserializer() {
            this(null);
        }

        public JsonDateDeserializer(Class a_clz) {
            super(a_clz);
        }

        @Override
        public Date deserialize(JsonParser parser, DeserializationContext context) throws IOException, JsonProcessingException {
            try {
                synchronized (dateFormat) {
                    return dateFormat.parse(parser.getText());
                }
            } catch (ParseException e) {
                throw new JsonParseException("Could not parse date", parser.getCurrentLocation(), e);
            }
        }
    }

    public static class JsonDateSerializer extends StdSerializer<Date> {

	    public JsonDateSerializer() {
	        this(null);
        }

        public JsonDateSerializer(Class a_clz) {
	        super(a_clz);
        }

        @Override
        public void serialize(Date date, JsonGenerator generator, SerializerProvider provider) throws IOException {
            synchronized (dateFormat) {
                String formatted = dateFormat.format(date);
                generator.writeString(formatted);
            }
        }
    }
}
