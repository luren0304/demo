package com.excelhk.openapi.usercertificationservice.entity;

import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.token.TokenKeyRule;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Date;

public class UserApproval {

    private String ls_userId;

    private String ls_clientId;

    private Date ld_expiresAt;

    private TokenKeyRule l_keyRule;

    public UserApproval() {}

    public UserApproval(String as_userId, String as_clientId, Date ad_expiresAt) {
        ls_userId = as_userId;
        ls_clientId = as_clientId;
        ld_expiresAt = ad_expiresAt;
    }

    public String getUserId() {
        return ls_userId;
    }

    public void setUserId(String userId) {
        this.ls_userId = userId;
    }

    public String getClientId() {
        return ls_clientId;
    }

    public void setClientId(String clientId) {
        this.ls_clientId = clientId;
    }

    @JsonSerialize(using = JsonUtil.JsonDateSerializer.class, include = JsonSerialize.Inclusion.NON_NULL)
    public Date getExpiresAt() {
        return ld_expiresAt;
    }

    @JsonDeserialize(using = JsonUtil.JsonDateDeserializer.class)
    public void setExpiresAt(Date expiresAt) {
        this.ld_expiresAt = expiresAt;
    }

    public TokenKeyRule getKeyRules() {
        return l_keyRule;
    }

    public void setKeyRules(TokenKeyRule keyRule) {
        this.l_keyRule = keyRule;
    }
}
