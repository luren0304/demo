package com.excelhk.openapi.usercertificationservice.controller;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.CommonUtil;
import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.entity.SysPermission;
import com.excelhk.openapi.usercertificationservice.request.AccessTokenRequest;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequestFactory;
import com.excelhk.openapi.usercertificationservice.service.IApiScopeService;
import com.excelhk.openapi.usercertificationservice.service.IRestService;
import com.excelhk.openapi.usercertificationservice.service.IUserApprovalService;
import com.excelhk.openapi.usercertificationservice.store.PermissionStore;
import com.excelhk.openapi.usercertificationservice.token.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.*;

@Controller
@SessionAttributes(GlobalConstant.GS_AUTHORIZATION_REQUEST)
public class AuthorizationController {
    private static final String VS_KEY_APP_NAME = "appName";
    private static final String VS_KEY_APP_SCOPES = "appScopes";
    private static final String VS_KEY_APP_SCOPE_CODE = "code";
    private static final String VS_KEY_APP_SCOPE_DESC = "desc";
    private static final String VS_KEY_APP_SCOPE_APPROVE = "approve";

    private String vs_confirmAccessUrl = "forward:/oauth/confirm_access";
    private String vs_approvalPageUrl = "forward:/approve";

    private final Object implicitLock = new Object();

    private AuthorizationRequestFactory v_requestFactory = AuthorizationRequestFactory.getInstance();

    @Autowired
    private IApiScopeService approvalService;

    @Autowired
    private IUserApprovalService userApprovalService;

    @Autowired
    private IRestService restService;

    @Autowired
    private PermissionStore permissionStore;


    @RequestMapping(value = "/oauth/authorize")
    public ModelAndView authorize(Map<String, Object> am_model, @RequestParam Map<String, String> am_parameters,
                                  SessionStatus a_sessionStatus, Principal a_principal) throws Exception {
        AuthorizationRequest l_authRequest;
        Authentication l_authentication;

        AppLogger.info("AuthorizationController - authorize ...");

        try {
            AppLogger.info("AuthorizationController - authorize : createAuthorizationRequest...");

            l_authRequest = v_requestFactory.createAuthorizationRequest(am_parameters);

            AppLogger.debug("AuthorizationController - authorize : RequestParameters = " + JsonUtil.toJsonStr(l_authRequest.getRequestParameters()));

            if (!(a_principal instanceof Authentication) || !((Authentication) a_principal).isAuthenticated()) {
                throw new InsufficientAuthenticationException(
                        "User must be authenticated with Spring Security before authorization can be completed.");
            }

            if (l_authRequest.getClientId() == null) {
                throw new AuthenticationServiceException("Missing the client id");
            }

            if (l_authRequest.getResponseType() == null) {
                throw new AuthenticationServiceException("Missing the response type");
            }

            l_authentication = (Authentication) a_principal;

            AppLogger.info("AuthorizationController - authorize : checkForPreUserApproval...");
            l_authRequest = userApprovalService.checkForPreUserApproval(l_authRequest, l_authentication);

            if (l_authRequest.isApproved()) {
                if (l_authRequest.getResponseType().contains("token")) {
                    return getImplicitGrantResponse(l_authRequest, l_authentication);
                } else {
                    throw new AuthenticationServiceException("Only support implicit grant with response type = 'token'");
                }
            }

            AppLogger.info("AuthorizationController - authorize : loadPreApprovalApiScopes...");
            l_authRequest = approvalService.loadPreApprovalApiScopes(l_authRequest, l_authentication);

            am_model.put(GlobalConstant.GS_AUTHORIZATION_REQUEST, l_authRequest);

            AppLogger.info("AuthorizationController - authorize : getUserApprovalPageResponse...");
            return getUserApprovalPageResponse(am_model, l_authRequest, l_authentication);
        } catch (Exception exception) {
            a_sessionStatus.setComplete();

            AppLogger.error("AuthorizationController - authorize : Failure", exception);

            throw exception;
        }
    }

    @RequestMapping(value = "/oauth/approval", method = RequestMethod.POST, params = GlobalConstant.GS_USER_OAUTH_APPROVAL)
    public View approveOrDeny(@RequestParam Map<String, String> approvalParameters, Map<String, Object> model,
                              SessionStatus a_sessionStatus, Principal a_principal, HttpServletRequest request) throws Exception {
        AuthorizationRequest l_authorizationRequest;
        Authentication l_authentication;

        AppLogger.info("AuthorizationController - approveOrDeny ...");

        if (!(a_principal instanceof Authentication)) {
            a_sessionStatus.setComplete();
            throw new InsufficientAuthenticationException(
                    "User must be authenticated with Spring Security before authorizing an access token.");
        }

        l_authorizationRequest = getAuthorizationRequest(model, request);
        l_authentication = (Authentication) a_principal;

        try {
            AppLogger.debug("AuthorizationController - approveOrDeny : ApprovalParameters = " + JsonUtil.toJsonStr(approvalParameters));

            String responseType = l_authorizationRequest.getResponseType();
            l_authorizationRequest.setApprovalParameters(approvalParameters);

            AppLogger.info("AuthorizationController - approveOrDeny : updateApiScopesAfterApproval...");
            l_authorizationRequest = approvalService.updateApiScopesAfterApproval(l_authorizationRequest, l_authentication);

            AppLogger.info("AuthorizationController - approveOrDeny : updateUserApprovalAfterApproval...");
            l_authorizationRequest = userApprovalService.updateUserApprovalAfterApproval(l_authorizationRequest, l_authentication);

            if (!l_authorizationRequest.isApproved()) {
                AppLogger.warn("AuthorizationController - approveOrDeny : Not approved any scope!");
            }

            if (responseType.contains("token")) {
                AppLogger.info("AuthorizationController - approveOrDeny : getImplicitGrantResponse...");

                return getImplicitGrantResponse(l_authorizationRequest, l_authentication).getView();
            } else {
                throw new AuthenticationServiceException("Only support implicit grant with response type = token");
            }

        } catch (Exception exception) {
            a_sessionStatus.setComplete();

            AppLogger.error("AuthorizationController - approveOrDeny : Failure", exception);

            throw exception;
        }
    }

    @RequestMapping("/oauth/confirm_access")
    public Object getAccessConfirmation(Map<String, Object> model, HttpServletRequest request)  throws Exception {
        AuthorizationRequest l_authorizationRequest;
        String ls_scopeCode;

        boolean lb_approve;

        SysPermission l_permission;

        Map<String, String> lm_requestScopes;
        Map<String, Object> lm_displayScopes;
        Map<String, SysPermission> lm_permission;
        List<Object> ll_displayScopes;

        AppLogger.info("AuthorizationController - getAccessConfirmation ...");

        l_authorizationRequest = getAuthorizationRequest(model, request);

        if (model.containsKey(GlobalConstant.GS_SCOPES)) {
            lm_requestScopes = (Map<String, String>) model.get(GlobalConstant.GS_SCOPES);
        } else {
            lm_requestScopes = (Map<String, String>) request.getAttribute(GlobalConstant.GS_SCOPES);
        }

        if (lm_requestScopes == null) {
            throw new AuthenticationServiceException("Missing the request scopes");
        }

        AppLogger.debug("AuthorizationController - getAccessConfirmation : Scopes = " + JsonUtil.toJsonStr(lm_requestScopes));

        ll_displayScopes = new ArrayList<Object>();
        lm_permission = permissionStore.getPermissions();

        for (String ls_scopeKey : lm_requestScopes.keySet()) {
            lm_displayScopes = new HashMap<String, Object>();

            lb_approve = Boolean.parseBoolean(lm_requestScopes.get(ls_scopeKey));
            ls_scopeCode = ls_scopeKey.substring(ls_scopeKey.indexOf(".") + 1);

            //lb_approve = true;

            lm_displayScopes.put(VS_KEY_APP_SCOPE_CODE, ls_scopeKey);
            lm_displayScopes.put(VS_KEY_APP_SCOPE_DESC, CommonUtil.toUpperCaseFirstOne(ls_scopeCode));
            lm_displayScopes.put(VS_KEY_APP_SCOPE_APPROVE, lb_approve);

            l_permission = lm_permission.get(ls_scopeCode);

            if (l_permission != null) {
                lm_displayScopes.put(VS_KEY_APP_SCOPE_DESC, l_permission.getDescription());
            }

            ll_displayScopes.add(lm_displayScopes);
        }

        model.put(VS_KEY_APP_NAME, l_authorizationRequest.getAppName());
        model.put(VS_KEY_APP_SCOPES, ll_displayScopes);

        return vs_approvalPageUrl;
    }

    private ModelAndView getImplicitGrantResponse(AuthorizationRequest authorizationRequest, Authentication authentication) throws Exception {
        AccessTokenRequest  l_accessTokenRequest = v_requestFactory.createAccessTokenRequest(authorizationRequest);
        AccessToken accessToken = getAccessTokenForImplicitGrant(l_accessTokenRequest);

        String ls_redirectTo = accessToken.getRedirectTo();

        if (!ls_redirectTo.contains(GlobalConstant.GS_STATE)) {
            ls_redirectTo += "&" + GlobalConstant.GS_STATE + "=" + authorizationRequest.getState();
        }

        ls_redirectTo += "&" + GlobalConstant.GS_USER + "=" + authentication.getName();

        return new ModelAndView(new RedirectView(ls_redirectTo, false, true, false));
    }

    private AccessToken getAccessTokenForImplicitGrant(AccessTokenRequest a_accessTokenRequest) throws Exception {
        AccessToken accessToken = null;

        synchronized (this.implicitLock) {
            accessToken = restService.retrieveAccessToken(a_accessTokenRequest);
        }

        return accessToken;
    }

    private ModelAndView getUserApprovalPageResponse(Map<String, Object> model,
                                                     AuthorizationRequest authorizationRequest, Authentication principal) {
        model.putAll(approvalService.getApiScopesForApprovalRequest(authorizationRequest, principal));

        return new ModelAndView(vs_confirmAccessUrl, model);
    }

    private AuthorizationRequest getAuthorizationRequest(Map<String, Object> model, HttpServletRequest request) {
        if (model.containsKey(GlobalConstant.GS_AUTHORIZATION_REQUEST)) {
            return (AuthorizationRequest) model.get(GlobalConstant.GS_AUTHORIZATION_REQUEST);
        } else {
            return (AuthorizationRequest) request.getAttribute(GlobalConstant.GS_AUTHORIZATION_REQUEST);
        }
    }

}
