package com.excelhk.openapi.usercertificationservice.dao;

import com.excelhk.openapi.usercertificationservice.entity.ApiScope;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface IApiScopeDao {

    boolean addApprovals(Collection<ApiScope> approvals);

    boolean revokeApprovals(Collection<ApiScope> approvals);

    boolean purgeExpiredApprovals();

    List<ApiScope> getApprovals(String userName, String clientId);

    List<ApiScope> getApprovals(String userName, String clientId, ApiScope.ApprovalStatus a_status);

    Map<String, Object> getApprovals(String clientId);
}
