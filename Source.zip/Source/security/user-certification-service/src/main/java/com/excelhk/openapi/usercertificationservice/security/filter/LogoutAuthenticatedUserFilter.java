package com.excelhk.openapi.usercertificationservice.security.filter;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

public class LogoutAuthenticatedUserFilter extends OncePerRequestFilter {

    private static final String VS_CLASS_NAME = LogoutAuthenticatedUserFilter.class.getName();

    private RequestMatcher v_requiredRequestMatcher;

    @Autowired
    SessionRegistry sessionRegistry;

    public LogoutAuthenticatedUserFilter(String as_requireRequestPath) {
        v_requiredRequestMatcher = new AntPathRequestMatcher(as_requireRequestPath, null);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest a_request, HttpServletResponse a_response, FilterChain a_filterChain) throws ServletException, IOException {
        AppLogger.info(VS_CLASS_NAME + " - doFilterInternal... ");

        // Pass the static resources path
        if (!a_request.getRequestURI().contains(".")) {
            AppLogger.info(VS_CLASS_NAME + " - doFilterInternal : uri  = " + a_request.getRequestURI());

            if (isRequiredRequest(a_request)) {
                // Print online users and sessions
                printAllOnlineUserAndSessions();

                // Print request parameters and header
                printRequestParameterAndHeader(a_request);

                // Logout before authenticated user
                logoutAuthenticatedUser(a_request);
            } else {
                AppLogger.info(VS_CLASS_NAME + " - doFilterInternal : passed");
            }
        }

        a_filterChain.doFilter(a_request, a_response);
    }

    private boolean isRequiredRequest(HttpServletRequest request) {
        return v_requiredRequestMatcher.matches(request);
    }

    private boolean isFilterRequest(HttpServletRequest request) {
        return Boolean.valueOf(request.getParameter(GlobalConstant.GS_LOGOUT));
    }

    /**
     *  This method will be call two times during one request, first bring the parameter, second none parameter
     *
     *  If bring the parameter and security context holder have authenticated user, will logout before authenticated user
     *  Otherwise will passed
     *
     * @param a_request
     */
    private void logoutAuthenticatedUser(HttpServletRequest a_request) {
        Authentication authentication;
        String ls_sessionUser;

        AppLogger.info(VS_CLASS_NAME + " - logoutAuthenticatedUser... ");

        authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.isAuthenticated()) {
            ls_sessionUser = authentication.getName();

            AppLogger.info(VS_CLASS_NAME + " - logoutAuthenticatedUser : find authentication user = " + ls_sessionUser);

            if (isFilterRequest(a_request)) {
                new SecurityContextLogoutHandler().logout(a_request, null,null);

                AppLogger.info(VS_CLASS_NAME + " - logoutAuthenticatedUser : "+ ls_sessionUser + " is logout!");
            } else {
                AppLogger.info(VS_CLASS_NAME + " - logoutAuthenticatedUser : "+ ls_sessionUser + " is active!");
            }
        } else {
            AppLogger.info(VS_CLASS_NAME + " - logoutAuthenticatedUser : none authentication");
        }
    }

    private void printRequestParameterAndHeader(HttpServletRequest a_request) {
        String ls_headerName;
        String ls_headerValue;

        Enumeration<String> le_headerNames;

        AppLogger.info(VS_CLASS_NAME + " - printRequestParameterAndHeader...");

        try {
            AppLogger.debug(VS_CLASS_NAME + " - printRequestParameterAndHeader : parameter  = " + JsonUtil.toJsonStr(a_request.getParameterMap()));

            le_headerNames = a_request.getHeaderNames();

            while (le_headerNames.hasMoreElements()) {
                ls_headerName = le_headerNames.nextElement();
                ls_headerValue = a_request.getHeader(ls_headerName);

                AppLogger.debug(VS_CLASS_NAME + " - printRequestParameterAndHeader : header = " + ls_headerName + ":" +  ls_headerValue);
            }
        } catch (Exception e) {
            // eat it
        }
    }

    private void printAllOnlineUserAndSessions() {
        AppLogger.info(VS_CLASS_NAME + " - printAllOnlineUserAndSessions...");

        int li_userIndex;
        int li_userSize;

        User l_userTemp;

        List<SessionInformation> ll_sessionInformation;
        List<Object> ll_allPrincipals;

        StringBuffer lsb_session;

        if (sessionRegistry != null) {
            ll_allPrincipals = sessionRegistry.getAllPrincipals();

            if (ll_allPrincipals != null) {
                li_userSize = ll_allPrincipals.size();

                AppLogger.info(VS_CLASS_NAME + " - printAllOnlineUserAndSessions : online user size = " + li_userSize);

                for (li_userIndex = 0; li_userIndex < li_userSize; li_userIndex++) {
                    l_userTemp = (User) ll_allPrincipals.get(li_userIndex);
                    ll_sessionInformation = sessionRegistry.getAllSessions(l_userTemp, false);

                    AppLogger.info(VS_CLASS_NAME + " - printAllOnlineUserAndSessions : user[" + (li_userIndex + 1) + "] = " + l_userTemp.getUsername());

                    if (ll_sessionInformation != null) {
                        lsb_session = new StringBuffer();

                        for (SessionInformation l_sessionInformation : ll_sessionInformation) {
                            lsb_session.append(l_sessionInformation.getSessionId());
                            lsb_session.append(" | ");
                        }

                        AppLogger.info(VS_CLASS_NAME + " - printAllOnlineUserAndSessions : user[" + (li_userIndex + 1) + "] session = " + lsb_session.toString());
                    }
                }
            }
        }
    }
}
