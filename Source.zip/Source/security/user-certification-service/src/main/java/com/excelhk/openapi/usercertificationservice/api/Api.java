package com.excelhk.openapi.usercertificationservice.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public class Api {


    private Date vd_createdAt;
    private ApiDefinition v_apiDefinition;

    private static final String VS_JSON_FIELD_CREATED_AT = "created_at";
    private static final String VS_JSON_FIELD_API_DEFINITION = "api_definition";

    public Api() {}

    public Api(Date ad_createdAt, ApiDefinition a_apiDefinition) {
        vd_createdAt = ad_createdAt;
        v_apiDefinition = a_apiDefinition;
    }

    @JsonProperty(VS_JSON_FIELD_CREATED_AT)
    public Date getCreatedAt() {
        return vd_createdAt;
    }

    @JsonProperty(VS_JSON_FIELD_CREATED_AT)
    public void setCreatedAt(Date createdAt) {
        this.vd_createdAt = createdAt;
    }

    @JsonProperty(VS_JSON_FIELD_API_DEFINITION)
    public ApiDefinition getApiDefinition() {
        return v_apiDefinition;
    }

    @JsonProperty(VS_JSON_FIELD_API_DEFINITION)
    public void setApiDefinition(ApiDefinition apiDefinition) {
        this.v_apiDefinition = apiDefinition;
    }
}
