package com.excelhk.openapi.usercertificationservice.request;

import com.excelhk.openapi.usercertificationservice.token.TokenKeyRule;
import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;
import java.util.*;

public class AuthorizationRequest extends BaseRequest {
    private String vs_state;
    private String vs_redirectUri;
    private String vs_responseType;
    private String vs_appName;

    private boolean vb_approved = false;

    private TokenKeyRule v_tokenKeyRule;
    private Date vd_approvalExpireAt;

    private Map<String, String> vm_approvalParameters = Collections.unmodifiableMap(new HashMap<>());

    public AuthorizationRequest() {}

    public AuthorizationRequest(Map<String, String> am_requestParameters, Set<String> ass_scope,
                                String as_clientId, String as_state, String as_redirectUri, String as_responseTypes) {
        setClientId(as_clientId);
        setRequestParameters(am_requestParameters);
        setScope(ass_scope);

        if (as_responseTypes != null) {
            this.vs_responseType = as_responseTypes;
        }

        this.vs_redirectUri = as_redirectUri;
        this.vs_state = as_state;
    }

    public String getState() {
        return vs_state;
    }

    public void setState(String as_state) {
        this.vs_state = as_state;
    }

    public String getRedirectUri() {
        return vs_redirectUri;
    }

    public void setRedirectUri(String as_redirectUri) {
        this.vs_redirectUri = as_redirectUri;
    }

    public String getAppName() {
        return vs_appName;
    }

    public void setAppName(String appName) {
        this.vs_appName = appName;
    }

    public boolean isApproved() {
        return vb_approved;
    }

    public void setApproved(boolean ab_approved) {
        this.vb_approved = ab_approved;
    }

    public Map<String, String> getApprovalParameters() {
        return vm_approvalParameters;
    }

    public void setApprovalParameters(Map<String, String> am_approvalParameters) {
        this.vm_approvalParameters = am_approvalParameters;
    }

    public String getResponseType() {
        return vs_responseType;
    }

    public void setResponseType(String as_responseTypes) {
        this.vs_responseType = as_responseTypes;
    }

    public TokenKeyRule getTokenKeyRule() {
        return v_tokenKeyRule;
    }

    public void setTokenKeyRule(TokenKeyRule tokenKeyRule) {
        this.v_tokenKeyRule = tokenKeyRule;
    }

    public Date getApprovalExpireAt() {
        return vd_approvalExpireAt;
    }

    public void setApprovalExpireAt(Date approvalExpireAt) {
        this.vd_approvalExpireAt = approvalExpireAt;
    }
}
