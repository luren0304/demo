package com.excelhk.openapi.usercertificationservice.request;

import org.springframework.http.HttpMethod;

import java.util.HashMap;
import java.util.Map;

public class AccessApiRequest extends AccessRequest {

    private String ls_apiName;

    public AccessApiRequest(String as_apiName) {
        super(HttpMethod.GET);

        ls_apiName = as_apiName;
    }

    public AccessApiRequest(String as_apiName, HttpMethod a_method) {
        super(a_method);

        ls_apiName = as_apiName;
    }

    @Override
    protected void buildHeader(AccessHeader a_header) {}

    @Override
    protected void buildBody(AccessBody a_body) {}

    public Map<String, String> getUriAttribute() {
        Map<String, String> lm_uriAttribute = new HashMap<>();
        lm_uriAttribute.put("api", ls_apiName);

        return lm_uriAttribute;
    }

    public String getApiName() {
        return ls_apiName;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof AccessApiRequest) {
            return ls_apiName.equals(((AccessApiRequest) obj).getApiName());
        } else {
            return false;
        }
    }
}
