package com.excelhk.openapi.usercertificationservice.request;

import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import org.springframework.http.HttpMethod;

public class AccessTokenRequest extends AccessRequest {

    private AuthorizationRequest v_authRequest;

    public AccessTokenRequest() {
        super();
    }

    public AccessTokenRequest(AuthorizationRequest a_authRequest) {
        super();

        v_authRequest = a_authRequest;
    }

    public AccessTokenRequest(HttpMethod a_method, AuthorizationRequest a_authRequest) {
        super(a_method);

        v_authRequest = a_authRequest;
    }

    @Override
    protected void buildHeader(AccessHeader a_header) throws Exception {}

    @Override
    protected void buildBody(AccessBody a_body) throws Exception {
        if (a_body != null) {
            a_body.addItem(GlobalConstant.GS_RESPONSE_TYPE, v_authRequest.getResponseType());
            a_body.addItem(GlobalConstant.GS_CLIENT_ID, v_authRequest.getClientId());
            a_body.addItem(GlobalConstant.GS_REDIRECT_URI, v_authRequest.getRedirectUri());

            a_body.addItem(GlobalConstant.GS_KEY_RULES, JsonUtil.toJsonStr(v_authRequest.getTokenKeyRule()));
            a_body.addItem(GlobalConstant.GS_STATE, v_authRequest.getState());
        }
    }
}
