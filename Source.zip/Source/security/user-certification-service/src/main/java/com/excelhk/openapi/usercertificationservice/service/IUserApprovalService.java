package com.excelhk.openapi.usercertificationservice.service;

import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import org.springframework.security.core.Authentication;

public interface IUserApprovalService {

    AuthorizationRequest checkForPreUserApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception;

    AuthorizationRequest updateUserApprovalAfterApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception;
}
