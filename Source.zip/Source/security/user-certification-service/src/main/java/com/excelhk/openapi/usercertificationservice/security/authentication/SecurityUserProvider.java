package com.excelhk.openapi.usercertificationservice.security.authentication;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

public class SecurityUserProvider extends DaoAuthenticationProvider {

    @Override
	public Authentication authenticate(Authentication a_authenticate) throws AuthenticationException {
		Authentication l_authentication = null;
		
		try {
			l_authentication = super.authenticate(a_authenticate);
		} catch (AuthenticationException a_exception) {
			AppLogger.error(SecurityUserProvider.class.getName() + " - authenticate : failure", a_exception);
			
			throw a_exception;
		}
		
		return l_authentication;
	}

	@Override
	protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
        try {
            ISecurityUserService l_userService = (ISecurityUserService) this.getUserDetailsService();
            l_userService.additionalAuthenticationChecks(userDetails, authentication);

        } catch (BadCredentialsException a_exception) {
            throw a_exception;
        } catch (Exception a_exception) {
            throw new AuthenticationServiceException(a_exception.getMessage());
        }
	}
}
