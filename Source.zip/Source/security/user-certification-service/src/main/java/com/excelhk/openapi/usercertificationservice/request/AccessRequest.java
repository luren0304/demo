package com.excelhk.openapi.usercertificationservice.request;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.List;

public abstract class AccessRequest {

    private AccessHeader l_accessHeader;

    private AccessBody l_accessBody;

    private AccessHttpEntity l_httpEntity;

    private HttpMethod l_method = HttpMethod.POST;

    private String ls_authorization;

    public AccessRequest() { }

    public AccessRequest(HttpMethod a_method) {
        l_method = a_method;
    }

    public void build() throws Exception {
        buildHeaderAndBody();
        buildEntity();
    }

    protected void buildHeaderAndBody() throws Exception {
        if (l_accessHeader == null) {
            l_accessHeader = createAccessHeaderInstance(l_method);

            if (ls_authorization != null) {
                l_accessHeader.setAccessAuth(ls_authorization);
            }

            buildHeader(l_accessHeader);
        }

        if (l_accessBody == null) {
            l_accessBody = createAccessBodyInstance();

            buildBody(l_accessBody);
        }
    }

    protected abstract void buildHeader(AccessHeader a_header) throws Exception;

    protected abstract void buildBody(AccessBody a_body) throws Exception;

    protected void buildEntity() {
        if ((l_httpEntity == null) && (l_accessHeader != null) && (l_accessBody != null)) {
            l_httpEntity = createAccessHttpEntityInstance(l_accessHeader, l_accessBody);
        }
    }

    protected AccessBody createAccessBodyInstance() {
        return new AccessBody();
    }

    protected AccessBody createAccessBodyInstance(MultiValueMap<String, String> amvm_paramMap) {
        return new AccessBody(amvm_paramMap);
    }

    protected AccessHeader createAccessHeaderInstance() {
        return new AccessHeader();
    }

    protected AccessHeader createAccessHeaderInstance(HttpMethod a_method) {
        return new AccessHeader(a_method);
    }

    protected AccessHttpEntity createAccessHttpEntityInstance(AccessHeader a_header, AccessBody a_body) {
        return new AccessHttpEntity(a_header, a_body);
    }

    protected AccessHeader getAccessHeader() {
        return l_accessHeader;
    }

    protected AccessBody getAccessBody() {
        return l_accessBody;
    }

    public void setAuthorization(String as_authorization) {
        ls_authorization = as_authorization;
    }

    public HttpMethod getMethod() {
        return l_method;
    }

    public HttpEntity<MultiValueMap<String, String>> getAccessEntity() {
        return l_httpEntity.getEntity();
    }

    protected class AccessHttpEntity {
        private HttpEntity<MultiValueMap<String, String>> httpEntity;

        public AccessHttpEntity(AccessHeader a_header, AccessBody a_body) {
            httpEntity = new HttpEntity<MultiValueMap<String, String>>(a_body.getBodyItem(), a_header);
        }

        public AccessHeader getAccessHeader() {
            return (AccessHeader) httpEntity.getHeaders();
        }

        public AccessBody getAccessBody() {
            return new AccessBody(httpEntity.getBody());
        }

        public HttpEntity<MultiValueMap<String, String>> getEntity() {
            return httpEntity;
        }
    }

    protected class AccessHeader extends HttpHeaders {

        public AccessHeader() {
            super();
        }

        public AccessHeader(HttpMethod a_method) {
            super();

            if (a_method == HttpMethod.POST) {
                setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            }
        }

        public void setAccessAuth(String as_value) {
            set(AUTHORIZATION, as_value);
        }
    }

    protected class AccessBody {
        private MultiValueMap<String, String> lmvm_paramMap;

        public AccessBody() {
            lmvm_paramMap = new LinkedMultiValueMap<String, String>();
        }

        public AccessBody(MultiValueMap<String, String> am_params) {
            lmvm_paramMap = am_params;
        }

        public void addItem(String as_name, String ao_target) {
            lmvm_paramMap.add(as_name, ao_target);
        }

        public void addAllItem(String as_name, List<? extends String> al_targets) {
            lmvm_paramMap.addAll(as_name, al_targets);
        }

        public Object getItem(String as_name) {
            return lmvm_paramMap.get(as_name);
        }

        public MultiValueMap<String, String> getBodyItem() {
            return lmvm_paramMap;
        }
    }
}
