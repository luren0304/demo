package com.excelhk.openapi.usercertificationservice.token;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccessToken {

    private String vs_accessToken;
    private String vs_redirectTo;
    private String vs_tokenType;
    private String vs_state;

    private long vl_expiresIn;

    public String getAccessToken() {
        return vs_accessToken;
    }

    @JsonProperty("access_token")
    public void setAccessToken(String accessToken) {
        this.vs_accessToken = accessToken;
    }

    public String getRedirectTo() {
        return vs_redirectTo;
    }

    @JsonProperty("redirect_to")
    public void setRedirectTo(String redirectTo) {
        this.vs_redirectTo = redirectTo;
    }

    public String getTokenType() {
        return vs_tokenType;
    }

    @JsonProperty("token_type")
    public void setTokenType(String tokenType) {
        this.vs_tokenType = tokenType;
    }

    public String getState() {
        return vs_state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.vs_state = state;
    }

    public long getExpiresIn() {
        return vl_expiresIn;
    }

    @JsonProperty("expires_in")
    public void setExpiresIn(long expiresIn) {
        this.vl_expiresIn = expiresIn;
    }
}
