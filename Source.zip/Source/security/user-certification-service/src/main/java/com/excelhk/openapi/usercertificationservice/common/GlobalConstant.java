package com.excelhk.openapi.usercertificationservice.common;

public class GlobalConstant {

    public static final String GS_CLIENT_ID = "client_id";

    public static final String GS_USER = "user";

    public static final String GS_STATE = "state";

    public static final String GS_SCOPE = "scope";

    public static final String GS_SCOPES = "scopes";

    public static final String GS_LOGOUT = "logout";

    public static final String GS_REDIRECT_URI = "redirect_uri";

    public static final String GS_RESPONSE_TYPE = "response_type";

    public static final String GS_USER_OAUTH_APPROVAL = "user_oauth_approval";

    public static final String GS_KEY_RULES = "key_rules";

    public static final String GS_SCOPE_PREFIX = "scope.";

    public static final String GS_AUTHORIZATION_REQUEST = "authorizationRequest";
}
