package com.excelhk.openapi.usercertificationservice.common;

import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;

/**
 * 
 * Common Utils
 *
 */
public class CommonUtil {
	
	public static boolean isEmptyString(String as_value) {
		return (as_value == null) || (as_value.trim().length() < 1);
	}
	
    public static String toUpperCaseFirstOne(String as_target){
        if(Character.isUpperCase(as_target.charAt(0))) {
            return as_target;
        } else {
            return (new StringBuilder()).append(Character.toUpperCase(as_target.charAt(0))).append(as_target.substring(1)).toString();
        }
    }

    public static String toLowerCaseFirstOne(String as_target){
        if(Character.isLowerCase(as_target.charAt(0))) {
            return as_target;
        } else {
            return (new StringBuilder()).append(Character.toLowerCase(as_target.charAt(0))).append(as_target.substring(1)).toString();
        }
    }

    public static int getOrderIdByUUId() {
        int vi_hashCodeValue = UUID.randomUUID().toString().hashCode();

        if(vi_hashCodeValue < 0) {
            vi_hashCodeValue = - vi_hashCodeValue;
        }

        return vi_hashCodeValue;
    }

    public static Set<String> parseParameterList(String values) {
        Set<String> result = new TreeSet<String>();
        if (values != null && values.trim().length() > 0) {
            // the spec says the scope is separated by spaces
            String[] tokens = values.split("[\\s+]");
            result.addAll(Arrays.asList(tokens));
        }
        return result;
    }
}
