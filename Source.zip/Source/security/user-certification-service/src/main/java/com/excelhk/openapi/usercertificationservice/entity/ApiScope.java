package com.excelhk.openapi.usercertificationservice.entity;

import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Calendar;
import java.util.Date;

public class ApiScope {

    private String userId;

    private String clientId;

    private String scope;

    public enum ApprovalStatus {
        /**
         * Approved
         */
        APPROVED,

        /**
         * Denied
         */
        DENIED;
    }

    private ApprovalStatus status;

    private Date expiresAt;

    private Date lastUpdatedAt;

    public ApiScope() {}

    public ApiScope(String userId, String clientId, String scope, int expiresIn, ApprovalStatus status) {
        this(userId, clientId, scope, new Date(), status, new Date());
        Calendar expiresAt = Calendar.getInstance();
        expiresAt.add(Calendar.MILLISECOND, expiresIn);
        setExpiresAt(expiresAt.getTime());
    }

    public ApiScope(String userId, String clientId, String scope, Date expiresAt, ApprovalStatus status) {
        this(userId, clientId, scope, expiresAt, status, new Date());
    }

    public ApiScope(String userId, String clientId, String scope, Date expiresAt, ApprovalStatus status, Date lastUpdatedAt) {
        setUserId(userId);
        setClientId(clientId);
        setScope(scope);
        setExpiresAt(expiresAt);
        this.status = status;
        this.lastUpdatedAt = lastUpdatedAt;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? "" : userId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId == null ? "" : clientId;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope == null ? "" : scope;
    }

    @JsonSerialize(using = JsonUtil.JsonDateSerializer.class, include = JsonSerialize.Inclusion.NON_NULL)
    public Date getExpiresAt() {
        return expiresAt;
    }

    @JsonDeserialize(using = JsonUtil.JsonDateDeserializer.class)
    public void setExpiresAt(Date expiresAt) {
        this.expiresAt = expiresAt;
    }

    @JsonSerialize(using = JsonUtil.JsonDateSerializer.class, include = JsonSerialize.Inclusion.NON_NULL)
    public Date getLastUpdatedAt() {
        return lastUpdatedAt;
    }

    @JsonDeserialize(using = JsonUtil.JsonDateDeserializer.class)
    public void setLastUpdatedAt(Date lastUpdatedAt) {
        this.lastUpdatedAt = lastUpdatedAt;
    }

    @JsonIgnore
    public boolean isCurrentlyActive() {
        return expiresAt != null && expiresAt.after(new Date());
    }

    @JsonIgnore
    public boolean isApproved() {
        return isCurrentlyActive() && status== ApprovalStatus.APPROVED;
    }

    public void setStatus(ApprovalStatus status) {
        this.status = status;
    }

    public ApprovalStatus getStatus() {
        return status;
    }

}
