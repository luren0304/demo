package com.excelhk.openapi.usercertificationservice.ssl;

import org.springframework.http.client.SimpleClientHttpRequestFactory;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class SkipSslVerificationHttpRequestFactory extends SimpleClientHttpRequestFactory {

    @Override
    protected void prepareConnection(HttpURLConnection a_connection, String as_httpMethod) throws IOException {
        if (a_connection instanceof HttpsURLConnection) {
            prepareHttpsConnection((HttpsURLConnection) a_connection);
        }
        super.prepareConnection(a_connection, as_httpMethod);
    }

    private void prepareHttpsConnection(HttpsURLConnection a_connection) {
        a_connection.setHostnameVerifier(new SkipHostnameVerifier());
        try {
            a_connection.setSSLSocketFactory(createSslSocketFactory());
        } catch (Exception ex) {
            // Ignore
        }
    }

    private SSLSocketFactory createSslSocketFactory() throws Exception {
        SSLContext l_sslContext = SSLContext.getInstance("TLS");
        l_sslContext.init(null, new TrustManager[] { new SkipX509TrustManager() },
                new SecureRandom());

        return l_sslContext.getSocketFactory();
    }

    private class SkipHostnameVerifier implements HostnameVerifier {

        @Override
        public boolean verify(String s, SSLSession sslSession) {
            return true;
        }

    }

    private class SkipX509TrustManager implements X509TrustManager {

        @Override
        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }

}
