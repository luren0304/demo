package com.excelhk.openapi.usercertificationservice.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.Map;

public class ApiVersionData {
    private Map<String, ApiVersion> vm_apiVersions = Collections.emptyMap();

    public ApiVersionData() {}

    @JsonProperty("versions")
    public Map<String, ApiVersion> getApiVersions() {
        return vm_apiVersions;
    }

    @JsonProperty("versions")
    public void setApiVersions(Map<String, ApiVersion> am_apiVersions) {
        this.vm_apiVersions = am_apiVersions;
    }
}

