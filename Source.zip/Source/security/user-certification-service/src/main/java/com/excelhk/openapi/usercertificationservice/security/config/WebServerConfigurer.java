package com.excelhk.openapi.usercertificationservice.security.config;

import com.excelhk.openapi.usercertificationservice.security.EnhancedHttpSessionEventPublisher;
import com.excelhk.openapi.usercertificationservice.security.authentication.ISecurityUserService;
import com.excelhk.openapi.usercertificationservice.security.authentication.SecurityUserProvider;
import com.excelhk.openapi.usercertificationservice.security.filter.LogoutAuthenticatedUserFilter;
import com.excelhk.openapi.usercertificationservice.store.SecurityStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.cors.CorsUtils;

import javax.servlet.Filter;
import java.util.Arrays;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebServerConfigurer extends WebSecurityConfigurerAdapter {

    @Autowired
    ISecurityUserService v_userServiceDetails;

    @Autowired
    SecurityStore v_securityStore;

    @Bean
    DaoAuthenticationProvider securityUserProvider() {
        DaoAuthenticationProvider l_authProvider = new SecurityUserProvider();
        l_authProvider.setUserDetailsService(v_userServiceDetails);
        l_authProvider.setHideUserNotFoundExceptions(false);

        return l_authProvider;
    }

    @Bean
    Filter logoutAuthenticatedFilter() {
        return new LogoutAuthenticatedUserFilter("/oauth/authorize");
    }

    @Bean
    SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new EnhancedHttpSessionEventPublisher();
    }

    @Bean
    @Override
    protected AuthenticationManager authenticationManager() throws Exception {
        ProviderManager l_providerManager;

        l_providerManager = new ProviderManager(Arrays.asList(securityUserProvider()));
        //l_providerManager.setEraseCredentialsAfterAuthentication(false);

        return l_providerManager;
    }

    @Override
    public void configure(WebSecurity a_webSecurity) throws Exception {
        a_webSecurity.ignoring().antMatchers(v_securityStore.getIgnoreUrl());
    }

    @Override
    protected void configure(HttpSecurity a_httpSecurity) throws Exception {

        a_httpSecurity.addFilterAfter(logoutAuthenticatedFilter(), LogoutFilter.class);

        // Close CSRF
        a_httpSecurity.csrf().disable();

        //http.headers().frameOptions().sameOrigin();
        a_httpSecurity.headers().frameOptions().disable();

        // Support CORS
        a_httpSecurity.cors();
        a_httpSecurity.httpBasic().disable();

        // In addition to matcher url, all other url are need authenticated
        a_httpSecurity.authorizeRequests()
                .requestMatchers(CorsUtils::isPreFlightRequest).permitAll()
                .antMatchers(v_securityStore.getPermitUrl()).permitAll()
                .anyRequest().authenticated();

        // Custom login logic
        a_httpSecurity.formLogin()
                .loginPage(v_securityStore.getLoginUrl())
                .failureForwardUrl(v_securityStore.getFailureUrl())
                .defaultSuccessUrl(v_securityStore.getCallbackUrl())
                .usernameParameter(v_securityStore.getUsernameParamName())
                .passwordParameter(v_securityStore.getPasswordParamName());

        // Custom logout logic
        a_httpSecurity.logout()
                .logoutUrl(v_securityStore.getLogoutUrl())
                .logoutSuccessUrl(v_securityStore.getCallbackUrl())
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("JSESSIONID");

        a_httpSecurity.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(false).sessionRegistry(sessionRegistry());
    }
}
