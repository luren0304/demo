package com.excelhk.openapi.usercertificationservice.dao;

import com.excelhk.openapi.usercertificationservice.entity.UserApproval;


public interface IUserApprovalDao {

    boolean addUserApprovals(UserApproval approvals);

    boolean revokeUserApprovals(UserApproval approvals);

    boolean purgeExpiredUserApprovals();

    UserApproval getUserUnexpiredApproval(String userName, String clientId);
}
