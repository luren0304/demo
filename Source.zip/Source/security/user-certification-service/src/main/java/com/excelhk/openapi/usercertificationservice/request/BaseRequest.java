package com.excelhk.openapi.usercertificationservice.request;

import com.excelhk.openapi.usercertificationservice.common.CommonUtil;

import java.util.*;

public abstract class BaseRequest {

    private String vs_clientId;

    private Set<String> vss_scopes = new HashSet<>();

    private Map<String, String> vm_requestParameters = Collections.unmodifiableMap(new HashMap<>());

    public String getClientId() {
        return vs_clientId;
    }

    public void setClientId(String as_clientId) {
        this.vs_clientId = as_clientId;
    }

    public Set<String> getScope() {
        return vss_scopes;
    }

    public void setScope(Collection<String> ass_scopes) {
        String ls_scope;

        if (ass_scopes != null && ass_scopes.size() == 1) {
            ls_scope = ass_scopes.iterator().next();

            if (ls_scope.contains(" ") || ls_scope.contains(",")) {
                ass_scopes = CommonUtil.parseParameterList(ls_scope);
            }
        }

        if (ass_scopes == null) {
            this.vss_scopes = Collections.unmodifiableSet(new LinkedHashSet<>());
        } else {
            this.vss_scopes = Collections.unmodifiableSet(new LinkedHashSet<>(ass_scopes));
        }
    }

    public Map<String, String> getRequestParameters() {
        return vm_requestParameters;
    }

    public void setRequestParameters(Map<String, String> am_requestParameters) {
        if (am_requestParameters != null) {
            this.vm_requestParameters = Collections.unmodifiableMap(new HashMap<>(am_requestParameters));
        }
    }
}
