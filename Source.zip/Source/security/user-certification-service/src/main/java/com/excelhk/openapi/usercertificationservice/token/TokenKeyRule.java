package com.excelhk.openapi.usercertificationservice.token;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class TokenKeyRule implements Serializable, Cloneable {

    private String vs_organizationalId;
    private String vs_authClientId;
    private String vs_hmacString;

    private boolean vb_hmacEnabled = false;

    private Map<String, TokenAccessRight> vm_accessRights;

    public TokenKeyRule() {}

    public TokenKeyRule(String as_orgId, String as_clientId, String as_hamc, boolean ab_hamcEnabled,
                        Map<String, TokenAccessRight> am_accessRights) {
        this.vs_organizationalId = as_orgId;
        this.vs_authClientId = as_clientId;
        this.vs_hmacString = as_hamc;
        this.vb_hmacEnabled = ab_hamcEnabled;
        this.vm_accessRights = am_accessRights;
    }

    @JsonProperty("org_id")
    public String getOrganizationalId() {
        return vs_organizationalId;
    }

    public void setOrganizationalId(String organizationalId) {
        this.vs_organizationalId = organizationalId;
    }

    @JsonProperty("oauth_client_id")
    public String getAuthClientId() {
        return vs_authClientId;
    }

    public void setAuthClientId(String authClientId) {
        this.vs_authClientId = authClientId;
    }

    @JsonProperty("hmac_string")
    public String getHmacString() {
        return vs_hmacString;
    }

    public void setHmacString(String hmacString) {
        this.vs_hmacString = hmacString;
    }

    @JsonProperty("hmac_enabled")
    public boolean isHmacEnabled() {
        return vb_hmacEnabled;
    }

    public void setHmacEnabled(boolean hmacEnabled) {
        this.vb_hmacEnabled = hmacEnabled;
    }

    @JsonProperty("access_rights")
    public Map<String, TokenAccessRight> getAccessRightMap() {
        return vm_accessRights;
    }

    public void setAccessRightMap(Map<String, TokenAccessRight> accessRightMap) {
        this.vm_accessRights = accessRightMap;
    }

    @Override
    public TokenKeyRule clone() throws CloneNotSupportedException {
        TokenKeyRule l_cloneTokenKeyRule = (TokenKeyRule) super.clone();
        Map<String, TokenAccessRight> lm_cloneAccessRights = new HashMap<String, TokenAccessRight>();

        for (String ls_key : vm_accessRights.keySet()) {
            lm_cloneAccessRights.put(ls_key, (TokenAccessRight)vm_accessRights.get(ls_key).clone());
        }

        l_cloneTokenKeyRule.setAccessRightMap(lm_cloneAccessRights);

        return l_cloneTokenKeyRule;
    }
}
