package com.excelhk.openapi.usercertificationservice.security.authentication;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.CommonUtil;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.service.IRestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SecurityUserServiceImpl implements ISecurityUserService {

    private static final String VS_ACCESS_PREFIX = "";
    private static final String VS_DEFAULT_ACCESS = "all";
    private static final String VS_DEFAULT_PASSWORD = "secreted";
    private static final String VS_CLASS_NAME = SecurityUserServiceImpl.class.getName();

    @Autowired
    private IRestService v_restService;

    @Override
    public void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws Exception {
        boolean lb_isFoundUser;

        String ls_inputUsername;
        String ls_inputPassword;

        AppLogger.info(VS_CLASS_NAME + " - additionalAuthenticationChecks...");

        ls_inputUsername = userDetails.getUsername();
        ls_inputPassword = authentication.getCredentials().toString();

        try {
            lb_isFoundUser = v_restService.verifyUser(ls_inputUsername, ls_inputPassword);

            if (!lb_isFoundUser) {
                throw new BadCredentialsException("Username or password incorrect");
            }

            AppLogger.info(VS_CLASS_NAME + " - additionalAuthenticationChecks : Success!");
        } catch (Throwable a_throw) {
            AppLogger.error(VS_CLASS_NAME + " - additionalAuthenticationChecks : Failure!", a_throw);

            throw new Exception(a_throw.getMessage());
        }
    }

    @Override
    public UserDetails loadUserByUsername(String as_username) throws UsernameNotFoundException {
        UserDetails l_userDetails = null;

        boolean lb_isFoundUser;

        AppLogger.info(VS_CLASS_NAME + " - loadUserByUsername...");
        AppLogger.debug(VS_CLASS_NAME + " - loadUserByUsername : username = " + as_username);

        try {
            lb_isFoundUser = v_restService.checkUser(as_username);

            if (!lb_isFoundUser) {
                throw new UsernameNotFoundException("Username or password incorrect");
            } else {
                l_userDetails = createSecurityUser(as_username);
            }

            AppLogger.debug(VS_CLASS_NAME + " - loadUserByUsername : Security user = " + JsonUtil.toJsonStr(l_userDetails));
            AppLogger.info(VS_CLASS_NAME + " - loadUserByUsername : Success!");
        } catch (Throwable a_throw) {
            AppLogger.error(VS_CLASS_NAME + " - loadUserByUsername : Failure!", a_throw);

            throw new UsernameNotFoundException(a_throw.getMessage());
        }

        return l_userDetails;
    }

    private User createSecurityUser(String as_rawUserName) {
        String ls_securityName = as_rawUserName;
        String ls_securityPassword = VS_DEFAULT_PASSWORD;
        String ls_securityAccess = VS_DEFAULT_ACCESS;

        List<GrantedAuthority> l_userAuthorities = createSecurityAccess(ls_securityAccess);

        return new User(ls_securityName, ls_securityPassword, l_userAuthorities);
    }

    private List<GrantedAuthority> createSecurityAccess(String as_accessChain) {
        List<GrantedAuthority> ll_grants = null;
        String[] lss_access;

        if (!CommonUtil.isEmptyString(as_accessChain)) {
            ll_grants = new ArrayList<GrantedAuthority>();

            lss_access = as_accessChain.split(",");

            for (String ls_access : lss_access) {
                ll_grants.add(new SimpleGrantedAuthority(VS_ACCESS_PREFIX + ls_access));
            }
        }

        return ll_grants;
    }

}
