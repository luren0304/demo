package com.excelhk.openapi.usercertificationservice.service;


import com.excelhk.openapi.usercertificationservice.request.AccessApiRequest;
import com.excelhk.openapi.usercertificationservice.request.AccessTokenRequest;
import com.excelhk.openapi.usercertificationservice.api.AccessApi;
import com.excelhk.openapi.usercertificationservice.token.AccessToken;

public interface IRestService {

    boolean checkUser(String as_username) throws Exception;

    boolean verifyUser(String as_username, String as_password) throws Exception;

    AccessToken retrieveAccessToken(AccessTokenRequest accessTokenRequest) throws Exception;

    AccessApi retrieveAccessApi(AccessApiRequest a_accessApiRequest) throws Exception;
}
