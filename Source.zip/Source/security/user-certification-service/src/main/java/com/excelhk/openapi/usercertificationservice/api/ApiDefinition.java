package com.excelhk.openapi.usercertificationservice.api;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ApiDefinition {

    private String vs_id;
    private String vs_name;
    private String vs_slug;

    private String vs_apiId;

    private String vs_orgId;

    private boolean vb_active;

    private ApiVersionData v_versionData;

    private static final String VS_JSON_FIELD_API_ID = "api_id";
    private static final String VS_JSON_FIELD_ORG_ID = "org_id";
    private static final String VS_JSON_FIELD_VERSION_DATA = "version_data";

    public ApiDefinition() {}

    public ApiDefinition(String as_apiId, String as_name, String as_orgId, boolean ab_active, ApiVersionData a_versionData) {
        vs_apiId = as_apiId;
        vs_orgId = as_orgId;
        vs_name = as_name;
        vb_active = ab_active;
        v_versionData = a_versionData;
    }

    public String getId() {
        return vs_id;
    }

    public void setId(String id) {
        this.vs_id = id;
    }

    public String getName() {
        return vs_name;
    }

    public void setName(String name) {
        this.vs_name = name;
    }

    public String getSlug() {
        return vs_slug;
    }

    public void setSlug(String slug) {
        this.vs_slug = slug;
    }

    @JsonProperty(VS_JSON_FIELD_API_ID)
    public String getApiId() {
        return vs_apiId;
    }

    @JsonProperty(VS_JSON_FIELD_API_ID)
    public void setApiId(String apiId) {
        this.vs_apiId = apiId;
    }

    @JsonProperty(VS_JSON_FIELD_ORG_ID)
    public String getOrgId() {
        return vs_orgId;
    }

    @JsonProperty(VS_JSON_FIELD_ORG_ID)
    public void setOrgId(String orgId) {
        this.vs_orgId = orgId;
    }

    public boolean isActive() {
        return vb_active;
    }

    public void setActive(boolean active) {
        this.vb_active = active;
    }

    @JsonProperty(VS_JSON_FIELD_VERSION_DATA)
    public ApiVersionData getVersionData() {
        return v_versionData;
    }

    @JsonProperty(VS_JSON_FIELD_VERSION_DATA)
    public void setVersionData(ApiVersionData a_versionData) {
        this.v_versionData = a_versionData;
    }
}


