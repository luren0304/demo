package com.excelhk.openapi.usercertificationservice.service.impl;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.request.AccessApiRequest;
import com.excelhk.openapi.usercertificationservice.request.AccessTokenRequest;
import com.excelhk.openapi.usercertificationservice.service.IRestService;
import com.excelhk.openapi.usercertificationservice.ssl.SkipSslVerificationHttpRequestFactory;
import com.excelhk.openapi.usercertificationservice.store.RestfulStore;
import com.excelhk.openapi.usercertificationservice.api.AccessApi;
import com.excelhk.openapi.usercertificationservice.token.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Service
public class RestServiceImpl implements IRestService {

    private RestTemplate v_restTemplate;

    @Autowired
    private RestfulStore restfulStore;

    private static final String VS_CLASS_NAME = RestServiceImpl.class.getName();

    @Override
    public boolean checkUser(String as_username) throws Exception {
        String ls_url;
        Map<String, Object> lm_param;

        Boolean lb_foundUser = false;

        AppLogger.info(VS_CLASS_NAME + " - checkUser...");

        try {
            ls_url = restfulStore.getCheckUserUrl();

            lm_param = new HashMap<String, Object>();
            lm_param.put("username", as_username);

            AppLogger.debug(VS_CLASS_NAME + " - checkUser : username = " + as_username);
            AppLogger.debug(VS_CLASS_NAME + " - checkUser : url = " + ls_url);

            lb_foundUser = v_restTemplate.getForObject(ls_url, Boolean.class, lm_param);

            AppLogger.info(VS_CLASS_NAME + " - checkUser : success = " + lb_foundUser);
        } catch (Throwable a_throw) {
            AppLogger.error(VS_CLASS_NAME + " - verifyUser : failure ! ", a_throw);

            if (a_throw instanceof NullPointerException) {
                throw new UsernameNotFoundException("Username not found");
            } else {
                throw new Exception(getErrorMessage(a_throw));
            }
        }

        return lb_foundUser;
    }

    @Override
    public boolean verifyUser(String as_username, String as_password) throws Exception {
        String ls_url;
        Map<String, Object> lm_param;

        Boolean lb_isAuthenticated = false;

        AppLogger.info(VS_CLASS_NAME + " - verifyUser...");

        try {
            ls_url = restfulStore.getVerifyUserUrl();

            lm_param = new HashMap<String, Object>();
            lm_param.put("username", as_username);
            lm_param.put("password", as_password);

            AppLogger.debug(VS_CLASS_NAME + " - verifyUser : username = " + as_username);
            AppLogger.debug(VS_CLASS_NAME + " - verifyUser : password = " + as_password);
            AppLogger.debug(VS_CLASS_NAME + " - verifyUser : url = " + ls_url);

            lb_isAuthenticated = v_restTemplate.getForObject(ls_url, Boolean.class, lm_param);

            AppLogger.info(VS_CLASS_NAME + " - verifyUser : success = " + lb_isAuthenticated);
        } catch (Throwable a_throw) {
            AppLogger.error(VS_CLASS_NAME + " - verifyUser : failure ! ", a_throw);

            if (a_throw instanceof NullPointerException) {
                throw new UsernameNotFoundException("Username not found");
            } else {
                throw new Exception(getErrorMessage(a_throw));
            }
        }

        return lb_isAuthenticated;
    }

    @Override
    public AccessToken retrieveAccessToken(AccessTokenRequest accessTokenRequest) throws Exception {
        String ls_url;

        ResponseEntity<AccessToken> l_responeEntity;
        AccessToken l_accessToken;

        AppLogger.info(VS_CLASS_NAME + " - retrieveAccessToken...");

        try {
            ls_url = restfulStore.getAccessTokenUrl();

            accessTokenRequest.setAuthorization(restfulStore.getAuthorization());
            accessTokenRequest.build();

            AppLogger.debug(VS_CLASS_NAME + " - retrieveAccessToken : url = " + ls_url);
            AppLogger.debug(VS_CLASS_NAME + " - retrieveAccessToken : params = " + JsonUtil.toJsonStr(accessTokenRequest.getAccessEntity()));

            l_responeEntity = v_restTemplate.exchange(
                    ls_url, accessTokenRequest.getMethod(), accessTokenRequest.getAccessEntity(), AccessToken.class);

            l_accessToken = l_responeEntity.getBody();

            AppLogger.info(VS_CLASS_NAME + " - retrieveAccessToken : success = " + JsonUtil.toJsonStr(l_accessToken));
        } catch (Throwable a_throw) {
            AppLogger.error(VS_CLASS_NAME + " - retrieveAccessToken : failure ! ", a_throw);

            throw new Exception(getErrorMessage(a_throw));
        }

        return l_accessToken;
    }

    @Override
    public AccessApi retrieveAccessApi(AccessApiRequest a_accessApiRequest) throws Exception {

        String ls_url;
        ResponseEntity<AccessApi> l_responeEntity;
        AccessApi l_accessApi;

        AppLogger.info(VS_CLASS_NAME + " - retrieveAccessApi...");

        try {
            ls_url = ls_url = restfulStore.getAccessApiUrl();
            a_accessApiRequest.setAuthorization(restfulStore.getAuthorization());
            a_accessApiRequest.build();

            AppLogger.info(VS_CLASS_NAME + " - retrieveAccessApi : url = " + ls_url);
            AppLogger.info(VS_CLASS_NAME + " - retrieveAccessApi : params = " + JsonUtil.toJsonStr(a_accessApiRequest.getAccessEntity()));
            AppLogger.info(VS_CLASS_NAME + " - retrieveAccessApi : attributes = " + JsonUtil.toJsonStr(a_accessApiRequest.getUriAttribute()));

            l_responeEntity = v_restTemplate.exchange(
                    ls_url, a_accessApiRequest.getMethod(), a_accessApiRequest.getAccessEntity(),
                    AccessApi.class, a_accessApiRequest.getUriAttribute());

            l_accessApi = l_responeEntity.getBody();


            AppLogger.debug(VS_CLASS_NAME + " - retrieveAccessApi : success = " + JsonUtil.toJsonStr(l_accessApi));
        } catch (Throwable a_throw) {
            AppLogger.error(VS_CLASS_NAME + " - retrieveAccessApi : failure ! ", a_throw);

            throw new Exception(getErrorMessage(a_throw));
        }

        return l_accessApi;
    }

    @PostConstruct
    public void init() {
        /*
        // Only support http request
        SimpleClientHttpRequestFactory l_requestFactory = new SimpleClientHttpRequestFactory();
        l_requestFactory.setConnectTimeout(restfulStore.getConnectionTimeout());
        l_requestFactory.setReadTimeout(restfulStore.getReadTimeout());
        */

        // Support http and https request
        SkipSslVerificationHttpRequestFactory l_requestFactory = new SkipSslVerificationHttpRequestFactory();
        l_requestFactory.setConnectTimeout(restfulStore.getConnectionTimeout());
        l_requestFactory.setReadTimeout(restfulStore.getReadTimeout());

        v_restTemplate = new RestTemplate(l_requestFactory);
    }

    private String getErrorMessage(Throwable a_throw) {
        String ls_errorMsg;

        if (a_throw.getCause() != null) {
            ls_errorMsg = a_throw.getCause().getLocalizedMessage();
        } else {
            ls_errorMsg = a_throw.getLocalizedMessage();
        }

        return ls_errorMsg;
    }
}
