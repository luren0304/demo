package com.excelhk.openapi.usercertificationservice.api;

public class ApiVersion {

    private String vs_name;
    private String vs_expires;

    public ApiVersion() {}

    public ApiVersion(String as_name, String as_expires) {
        vs_name = as_name;
        vs_expires = as_expires;
    }

    public String getName() {
        return vs_name;
    }

    public void setName(String name) {
        this.vs_name = name;
    }

    public String getExpires() {
        return vs_expires;
    }

    public void setExpires(String expires) {
        this.vs_expires = expires;
    }
}
