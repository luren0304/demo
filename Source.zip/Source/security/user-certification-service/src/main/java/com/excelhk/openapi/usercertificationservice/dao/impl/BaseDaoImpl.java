package com.excelhk.openapi.usercertificationservice.dao.impl;

import com.excelhk.openapi.usercertificationservice.dao.IBaseDao;
import com.excelhk.openapi.usercertificationservice.sql.SqlConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

@Repository
public abstract class BaseDaoImpl implements IBaseDao {

    @Autowired
    DataSource dataSource;

    private NamedParameterJdbcTemplate nameTemplate;

    @Override
    public Map<String, Object> queryForMap(String as_sql, Map<String, Object> am_params) {
        try {
            return nameTemplate.queryForMap(as_sql, am_params);
        } catch (EmptyResultDataAccessException exception) {
            return null;
        }
    }

    @Override
    public Object queryForMap(String as_sql, Map<String, Object> am_params, Class<?> a_class) {
        try {
            return nameTemplate.queryForObject(as_sql, am_params, new BeanPropertyRowMapper<Object>((Class<Object>) a_class));
        } catch (EmptyResultDataAccessException exception) {
            return null;
        }
    }

    @Override
    public List<? extends Object> queryAll(String as_sql, Map<String, Object> am_params, Class<?> a_class) {
        try {
            return nameTemplate.query(as_sql, am_params, new BeanPropertyRowMapper<Object>((Class<Object>) a_class));
        } catch (EmptyResultDataAccessException exception) {
            return null;
        }
    }

    @Override
    public boolean update(String as_sql, Map<String, Object> am_params) {
        int l_intChangeCnt;

        l_intChangeCnt = nameTemplate.update(as_sql, am_params);

        if (l_intChangeCnt > 0) {
            return true;
        } else {
            return false;
        }
    }

    @PostConstruct
    private void init() {
        nameTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    public String getSql(String as_sqlKey) {
        return SqlConstants.getSQL(as_sqlKey);
    }

    protected NamedParameterJdbcTemplate getJdbcTemplate() {
        return nameTemplate;
    }

}
