package com.excelhk.openapi.usercertificationservice.entity;

import com.excelhk.openapi.usercertificationservice.common.CommonUtil;

public class SysPermission {

    private int vi_permissionId;
    private String vs_permissionCode;
    private String vs_permissionUrl;
    private String vs_description;

    public SysPermission() {
        this.setPermissionId(CommonUtil.getOrderIdByUUId());
    }

    public void setPermissionId(int ai_permissionId) {
        this.vi_permissionId = ai_permissionId;
    }

    public void setPermissionCode(String permissionCode) {
        this.vs_permissionCode = permissionCode;
    }

    public void setPermissionUrl(String as_permissionUrl) {
        this.vs_permissionUrl = as_permissionUrl;
    }

    public String getDescription() {
        return vs_description;
    }

    public void setDescription(String as_description) {
        this.vs_description = as_description;
    }
}
