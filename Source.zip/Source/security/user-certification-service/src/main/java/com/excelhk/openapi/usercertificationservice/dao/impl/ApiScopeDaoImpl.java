package com.excelhk.openapi.usercertificationservice.dao.impl;

import com.excelhk.openapi.usercertificationservice.dao.IApiScopeDao;
import com.excelhk.openapi.usercertificationservice.entity.ApiScope;
import com.excelhk.openapi.usercertificationservice.sql.SqlConstants;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.*;

@Repository
public class ApiScopeDaoImpl extends BaseDaoImpl implements IApiScopeDao {

    private static final String VS_PARAM_EXPIRES_AT = "expiresAt";
    private static final String VS_PARAM_USER_ID = "userId";
    private static final String VS_PARAM_CLIENT_ID = "clientId";
    private static final String VS_PARAM_STATUS = "status";
    private static final String VS_PARAM_SCOPE = "scope";
    private static final String VS_PARAM_LAST_MODIFIED_AT = "lastModifiedAt";

    private boolean handleRevocationsAsExpiry = false;

    public void setHandleRevocationsAsExpiry(boolean handleRevocationsAsExpiry) {
        this.handleRevocationsAsExpiry = handleRevocationsAsExpiry;
    }

    @Override
    public boolean addApprovals(Collection<ApiScope> a_approvals) {
        boolean lb_success = true;

        for (ApiScope approval : a_approvals) {
            if (!updateApproval(getSql(SqlConstants.CS_SQL_APPROVE_UPDATE), approval)) {
                if (!updateApproval(getSql(SqlConstants.CS_SQL_APPROVE_ADD), approval)) {
                    lb_success = false;
                }
            }
        }

        return lb_success;
    }

    @Override
    public boolean revokeApprovals(Collection<ApiScope> approvals) {
        boolean success = true;

        for (ApiScope approval : approvals) {
            if (handleRevocationsAsExpiry) {
                success = updateApproval(getSql(SqlConstants.CS_SQL_APPROVE_UPDATE_EXPIRED), approval);
            } else {
                success = updateApproval(getSql(SqlConstants.CS_SQL_APPROVE_DELETE), approval);
            }
        }

        return success;
    }

    @Override
    public boolean purgeExpiredApprovals() {
        Map<String, Object> lhm_paramMap = new HashMap<>();
        lhm_paramMap.put("expiresAt", new Timestamp(System.currentTimeMillis()));

        return update(getSql(SqlConstants.CS_SQL_APPROVE_DELETE_EXPIRED), lhm_paramMap);
    }

    @Override
    public List<ApiScope> getApprovals(String userName, String clientId, ApiScope.ApprovalStatus a_status) {
        Map<String, Object> lhm_paramMap = new HashMap<>();
        lhm_paramMap.put(VS_PARAM_USER_ID, userName);
        lhm_paramMap.put(VS_PARAM_CLIENT_ID, clientId);
        lhm_paramMap.put(VS_PARAM_STATUS, a_status.toString());

        return (List<ApiScope>) queryAll(getSql(SqlConstants.CS_SQL_APPROVE_SEARCH_STATUS), lhm_paramMap, ApiScope.class);
    }

    @Override
    public List<ApiScope> getApprovals(String userName, String clientId) {
        try {
            Map<String, Object> lhm_paramMap = new HashMap<>();
            lhm_paramMap.put(VS_PARAM_USER_ID, userName);
            lhm_paramMap.put(VS_PARAM_CLIENT_ID, clientId);

            return (List<ApiScope>) queryAll(getSql(SqlConstants.CS_SQL_APPROVE_SEARCH), lhm_paramMap, ApiScope.class);
        } catch (EmptyResultDataAccessException exception) {
            // eat it
        }

        return null;
    }

    @Override
    public Map<String, Object> getApprovals(String clientId) {
        try {
            Map<String, Object> lhm_paramMap = new HashMap<>();
            lhm_paramMap.put(VS_PARAM_CLIENT_ID, clientId);

            return queryForMap(getSql(SqlConstants.CS_SQL_PERMIT_SEARCH), lhm_paramMap);
        } catch (EmptyResultDataAccessException exception) {
            // eat it
        }

        return null;
    }

    private boolean updateApproval(String sql, ApiScope approval) {
        Map<String, Object> lhm_paramMap = new HashMap<>();

        if (approval.getExpiresAt() != null) {
            lhm_paramMap.put(VS_PARAM_EXPIRES_AT, new Timestamp(approval.getExpiresAt().getTime()));
        }

        if (approval.getStatus() != null) {
            lhm_paramMap.put(VS_PARAM_STATUS, approval.getStatus().toString());
        } else {
            lhm_paramMap.put(VS_PARAM_STATUS, ApiScope.ApprovalStatus.APPROVED.toString());
        }

        if (approval.getLastUpdatedAt() != null) {
            lhm_paramMap.put(VS_PARAM_LAST_MODIFIED_AT, new Timestamp(approval.getLastUpdatedAt().getTime()));
        }

        lhm_paramMap.put(VS_PARAM_USER_ID, approval.getUserId());
        lhm_paramMap.put(VS_PARAM_CLIENT_ID, approval.getClientId());
        lhm_paramMap.put(VS_PARAM_SCOPE, approval.getScope());

        return this.update(sql, lhm_paramMap);
    }
}
