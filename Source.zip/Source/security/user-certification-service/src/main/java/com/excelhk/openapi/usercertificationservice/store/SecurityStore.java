package com.excelhk.openapi.usercertificationservice.store;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
@PropertySource(value = "classpath:config/security.properties")
@ConfigurationProperties("security.store")
public class SecurityStore extends BaseStore {

    private static final String VS_KEY_SECURITY_IGNORE = "url.ignore";
    private static final String VS_KEY_SECURITY_PERMIT = "url.permit";
    private static final String VS_KEY_SECURITY_USERNAME_PARAM = "form.username";
    private static final String VS_KEY_SECURITY_PASSWORD_PARAM = "form.password";
    private static final String VS_KEY_SECURITY_URL_LOGIN = "url.login";
    private static final String VS_KEY_SECURITY_URL_LOGOUT = "url.logout";
    private static final String VS_KEY_SECURITY_URL_CALLBACK = "url.callback";
    private static final String VS_KEY_SECURITY_URL_FAILURE = "url.failure";

    @Override
    protected void loadPropertiesData(String as_prefix) { }

    public String getUsernameParamName() {
        return getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_USERNAME_PARAM);
    }

    public String getPasswordParamName() {
        return getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_PASSWORD_PARAM);
    }

    public String[] getIgnoreUrl() {
        String ls_ignoreUrlChain = getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_IGNORE);

        return StringUtils.commaDelimitedListToStringArray(ls_ignoreUrlChain);
    }

    public String[] getPermitUrl() {
        String ls_permitUrlChain = getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_PERMIT);

        return StringUtils.commaDelimitedListToStringArray(ls_permitUrlChain);
    }

    public String getLoginUrl() {
        return getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_URL_LOGIN);
    }

    public String getLogoutUrl() {
        return getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_URL_LOGOUT);
    }

    public String getCallbackUrl() {
        return getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_URL_CALLBACK);
    }

    public String getFailureUrl() {
        return getPropertiesValue(getAlias() + "." + VS_KEY_SECURITY_URL_FAILURE);
    }
}
