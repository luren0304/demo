package com.excelhk.openapi.usercertificationservice.security;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import java.util.Date;

public class EnhancedHttpSessionEventPublisher extends HttpSessionEventPublisher {

    private static final String VS_CLASS_NAME = EnhancedHttpSessionEventPublisher.class.getName();


    public EnhancedHttpSessionEventPublisher() {
        super();
    }

    @Override
    public void sessionCreated(HttpSessionEvent a_sessionEvent) {
        AppLogger.info(VS_CLASS_NAME + " : sessionCreated...");

        printSession(a_sessionEvent);

        super.sessionCreated(a_sessionEvent);
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent a_sessionEvent) {
        AppLogger.info(VS_CLASS_NAME + " : sessionDestroyed...");

        printSession(a_sessionEvent);

        super.sessionDestroyed(a_sessionEvent);
    }

    private void printSession(HttpSessionEvent a_sessionEvent) {
        HttpSession l_session = a_sessionEvent.getSession();

        if (l_session != null) {
            if (l_session.isNew()) {
                AppLogger.info(VS_CLASS_NAME + " : printSession : session id = " + l_session.getId() + "(NEW)");
            } else {
                AppLogger.info(VS_CLASS_NAME + " : printSession : session id = " + l_session.getId());
            }

            AppLogger.info(VS_CLASS_NAME + " : printSession : session creation time = " + new Date(l_session.getCreationTime()));
            AppLogger.info(VS_CLASS_NAME + " : printSession : session accessed time = " + new Date(l_session.getLastAccessedTime()));
            AppLogger.info(VS_CLASS_NAME + " : printSession : session timeout = " + l_session.getMaxInactiveInterval() + " seconds");
        }
    }
}
