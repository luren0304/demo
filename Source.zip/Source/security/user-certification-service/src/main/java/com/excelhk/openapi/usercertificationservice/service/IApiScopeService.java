package com.excelhk.openapi.usercertificationservice.service;

import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import org.springframework.security.core.Authentication;

import java.util.Map;

public interface IApiScopeService {

    AuthorizationRequest loadPreApprovalApiScopes(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception;

    AuthorizationRequest updateApiScopesAfterApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception;

    Map<String, Object> getApiScopesForApprovalRequest(AuthorizationRequest authorizationRequest, Authentication userAuthentication);
}
