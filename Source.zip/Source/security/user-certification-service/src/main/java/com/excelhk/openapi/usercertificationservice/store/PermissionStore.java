package com.excelhk.openapi.usercertificationservice.store;

import com.excelhk.openapi.usercertificationservice.common.CommonUtil;
import com.excelhk.openapi.usercertificationservice.entity.SysPermission;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@PropertySource(value = {"classpath:config/permission.properties", "file:config/permission.properties"}, ignoreResourceNotFound = true)
@ConfigurationProperties("permission.store")
public class PermissionStore extends BaseStore {

    private static final String VS_KEY_PERMIT_CODE = "code";
    private static final String VS_KEY_PERMIT_URL = "url";
    private static final String VS_KEY_PERMIT_DESC = "desc";

    private static final Map<String, SysPermission> VM_PERMISSION = new HashMap<String, SysPermission>();

    @Override
    protected void loadPropertiesData(String as_prefix) {
        String ls_permitCode;
        String ls_permitUrl;
        String ls_permitDesc;

        SysPermission l_SysPermission;

        ls_permitCode = getPropertiesValue(as_prefix + VS_KEY_PERMIT_CODE);
        ls_permitUrl = getPropertiesValue(as_prefix + VS_KEY_PERMIT_URL);
        ls_permitDesc = getPropertiesValue(as_prefix + VS_KEY_PERMIT_DESC);

        if (!CommonUtil.isEmptyString(ls_permitCode)) {
            l_SysPermission = new SysPermission();

            l_SysPermission.setPermissionCode(ls_permitCode);
            l_SysPermission.setPermissionUrl(ls_permitUrl);
            l_SysPermission.setDescription(ls_permitDesc);

            VM_PERMISSION.put(ls_permitCode, l_SysPermission);
        }
    }

    public Map<String, SysPermission> getPermissions() {
        return VM_PERMISSION;
    }
}
