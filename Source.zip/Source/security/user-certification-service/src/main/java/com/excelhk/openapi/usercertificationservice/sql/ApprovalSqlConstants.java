package com.excelhk.openapi.usercertificationservice.sql;

import java.util.HashMap;

public class ApprovalSqlConstants {

    public static void loadSql(HashMap<String, String> ahm_sqlPool) {

        ahm_sqlPool.put(SqlConstants.CS_SQL_PERMIT_SEARCH,
            " SELECT" +
                " client.scope scope," +
                " client.additional_information info" +
            " FROM oauth_client_details client" +
            " WHERE 1=1" +
                " AND client.client_id = :clientId"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_SEARCH,
            " SELECT " +
                " approval.expiresAt expiresAt," +
                " approval.status status," +
                " approval.lastModifiedAt lastModifiedAt," +
                " approval.userId userId," +
                " approval.clientId clientId," +
                " approval.scope scope" +
            " FROM oauth_approvals approval" +
            " WHERE 1=1" +
                " AND approval.clientId = :clientId" +
                " AND approval.userId = :userId"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_SEARCH_STATUS,
            " SELECT " +
                    " approval.expiresAt expiresAt," +
                    " approval.status status," +
                    " approval.lastModifiedAt lastModifiedAt," +
                    " approval.userId userId," +
                    " approval.clientId clientId," +
                    " approval.scope scope" +
            " FROM oauth_approvals approval" +
            " WHERE 1=1" +
                    " AND approval.clientId = :clientId" +
                    " AND approval.userId = :userId" +
                    " AND approval.status = :status"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_ADD,
            " INSERT INTO oauth_approvals" +
            " (" +
                " expiresAt," +
                " status," +
                " lastModifiedAt," +
                " userId," +
                " clientId," +
                " scope" +
            " )" +
            " VALUES" +
            " (" +
                ":expiresAt, :status, :lastModifiedAt, :userId, :clientId, :scope" +
            " )"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_UPDATE,
            " UPDATE oauth_approvals approval SET" +
                " approval.expiresAt = :expiresAt," +
                " approval.status = :status," +
                " approval.lastModifiedAt = :lastModifiedAt" +
            " WHERE 1=1" +
                " AND approval.userId = :userId" +
                " AND approval.clientId = :clientId" +
                " AND approval.scope = :scope"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_UPDATE_EXPIRED,
            " UPDATE oauth_approvals approval SET" +
                " approval.expiresAt = :expiresAt" +
            " WHERE 1=1" +
                " AND approval.userId = :userId" +
                " AND approval.clientId = :clientId" +
                " AND approval.scope = :scope"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_DELETE,
            " DELETE FROM oauth_approvals" +
            " WHERE 1=1 " +
                " AND userId = :userId" +
                " AND clientId = :clientId" +
                " AND scope = :scope"
        );

        ahm_sqlPool.put(SqlConstants.CS_SQL_APPROVE_DELETE_EXPIRED,
            " DELETE FROM oauth_approvals" +
            " WHERE 1=1" +
                " AND expiresAt <= :expiresAt"
        );
    }
}
