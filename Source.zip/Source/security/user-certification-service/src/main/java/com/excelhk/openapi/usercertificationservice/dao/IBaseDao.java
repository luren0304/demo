package com.excelhk.openapi.usercertificationservice.dao;

import java.util.List;
import java.util.Map;

public interface IBaseDao {

    List<? extends Object> queryAll(String as_sql, Map<String, Object> am_params, Class<?> a_class);

    Object queryForMap(String as_sql, Map<String, Object> am_params, Class<?> a_class);

    Map<String, Object> queryForMap(String as_sql, Map<String, Object> am_params);

    boolean update(String as_sql, Map<String, Object> am_params);
}
