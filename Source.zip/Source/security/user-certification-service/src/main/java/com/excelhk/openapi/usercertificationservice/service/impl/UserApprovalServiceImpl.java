package com.excelhk.openapi.usercertificationservice.service.impl;

import com.excelhk.openapi.usercertificationservice.api.AccessApi;
import com.excelhk.openapi.usercertificationservice.api.Api;
import com.excelhk.openapi.usercertificationservice.api.ApiDefinition;
import com.excelhk.openapi.usercertificationservice.api.ApiVersion;
import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.dao.IUserApprovalDao;
import com.excelhk.openapi.usercertificationservice.entity.UserApproval;
import com.excelhk.openapi.usercertificationservice.request.AccessApiRequest;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import com.excelhk.openapi.usercertificationservice.service.IRestService;
import com.excelhk.openapi.usercertificationservice.service.IUserApprovalService;
import com.excelhk.openapi.usercertificationservice.token.TokenAccessRight;
import com.excelhk.openapi.usercertificationservice.token.TokenKeyRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserApprovalServiceImpl implements IUserApprovalService {

    @Autowired
    private IUserApprovalDao v_userApprovalDao;

    @Autowired
    IRestService restService;

    private final String VS_CLASS_NAME = UserApprovalServiceImpl.class.getName();

    @Override
    public AuthorizationRequest checkForPreUserApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception {
        AppLogger.info(VS_CLASS_NAME + " - checkForPreUserApproval...");

        UserApproval l_userApproval = v_userApprovalDao.getUserUnexpiredApproval(userAuthentication.getName(), authorizationRequest.getClientId());

        if (l_userApproval != null) {
            authorizationRequest.setTokenKeyRule(l_userApproval.getKeyRules());
            authorizationRequest.setApproved(true);

            AppLogger.info(VS_CLASS_NAME + " - checkForPreUserApproval : skipping approve page!");
        } else {
            authorizationRequest.setApproved(false);

            AppLogger.info(VS_CLASS_NAME + " - checkForPreUserApproval : goto approve page!");
        }

        return authorizationRequest;
    }

    @Override
    public AuthorizationRequest updateUserApprovalAfterApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception {
        String ls_clientId;
        Date ld_expiry;

        AccessApiRequest l_accessApiRequest;
        AccessApi l_accessApi;
        TokenKeyRule l_tokenKeyRule;
        UserApproval l_userApproval;

        List<AccessApi> ll_accessApis;
        Set<String> lss_approvedScopes;

        AppLogger.info(VS_CLASS_NAME + " - updateUserApprovalAfterApproval...");

        ls_clientId = authorizationRequest.getClientId();
        ll_accessApis = new ArrayList<>();

        if (authorizationRequest.isApproved()) {
            lss_approvedScopes = authorizationRequest.getScope();
            ld_expiry = authorizationRequest.getApprovalExpireAt();

            for (String ls_scope : lss_approvedScopes) {
                l_accessApiRequest = new AccessApiRequest(ls_scope);
                l_accessApi = restService.retrieveAccessApi(l_accessApiRequest);

                if (l_accessApi != null) {
                    ll_accessApis.add(l_accessApi);
                }

                AppLogger.info(VS_CLASS_NAME + " - updateUserApprovalAfterApproval : retrieved access api with [" + ls_scope + "]");
            }

            l_tokenKeyRule = buildTokenKeyRule(ll_accessApis, ls_clientId);
            l_userApproval = new UserApproval(userAuthentication.getName(), ls_clientId, ld_expiry);
            l_userApproval.setKeyRules(l_tokenKeyRule);

            v_userApprovalDao.addUserApprovals(l_userApproval);

            AppLogger.info(VS_CLASS_NAME + " - updateUserApprovalAfterApproval : add user approval!");

            authorizationRequest.setTokenKeyRule(l_tokenKeyRule);

            AppLogger.info(VS_CLASS_NAME + " - updateUserApprovalAfterApproval : token key rule = " + JsonUtil.toJsonStr(l_tokenKeyRule));
        }

        return authorizationRequest;
    }

    private TokenKeyRule buildTokenKeyRule(List<AccessApi> a_accessApis, String as_clientId) {
        String ls_orgid = "";

        TokenAccessRight l_accessRight;
        ApiDefinition l_apiDefinition;

        List<Api> ll_apis;
        Map<String, ApiVersion> lm_apiVersion;
        Map<String, TokenAccessRight> lm_accessRight;

        AppLogger.info(VS_CLASS_NAME + " - buildTokenKeyRule...");

        lm_accessRight = new HashMap<>();

        for (AccessApi accessApi : a_accessApis) {
            ll_apis = accessApi.getApis();

            for (Api api : ll_apis) {
                l_apiDefinition = api.getApiDefinition();
                ls_orgid = l_apiDefinition.getOrgId();
                lm_apiVersion = l_apiDefinition.getVersionData().getApiVersions();

                l_accessRight = new TokenAccessRight(l_apiDefinition.getName(), l_apiDefinition.getApiId(), new HashSet<>(lm_apiVersion.keySet()));
                lm_accessRight.put(l_apiDefinition.getApiId(), l_accessRight);
            }
        }

        return new TokenKeyRule(ls_orgid, as_clientId, "", false, lm_accessRight);
    }
}