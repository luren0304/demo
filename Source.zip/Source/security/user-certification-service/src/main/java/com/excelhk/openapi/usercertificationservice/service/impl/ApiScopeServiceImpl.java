package com.excelhk.openapi.usercertificationservice.service.impl;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.CommonUtil;
import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.dao.IApiScopeDao;
import com.excelhk.openapi.usercertificationservice.entity.ApiScope;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import com.excelhk.openapi.usercertificationservice.service.IApiScopeService;
import com.excelhk.openapi.usercertificationservice.service.IRestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

@Service
public class ApiScopeServiceImpl implements IApiScopeService {

    @Autowired
    private IApiScopeDao v_approvalDao;

    @Autowired
    IRestService restService;

    private String scopePrefix = GlobalConstant.GS_SCOPE_PREFIX;

    private int approvalExpirySeconds = -1;

    private final String VS_CLASS_NAME = ApiScopeServiceImpl.class.getName();

    @Override
    public AuthorizationRequest loadPreApprovalApiScopes(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception {
        String ls_clientId;
        String ls_clientScopes;

        Set<String> ass_approvedScopes;
        Map<String, Object> lm_clientApprovals;
        Map<String, String> lm_clientInformation = null;

        AppLogger.info(VS_CLASS_NAME + " - loadPreApprovalApiScopes...");

        ls_clientId = authorizationRequest.getClientId();

        ass_approvedScopes = new HashSet<>();

        if (!authorizationRequest.isApproved()) {
            lm_clientApprovals = v_approvalDao.getApprovals(ls_clientId);

            if (lm_clientApprovals == null) {
                throw new Exception("Invalid client id " + ls_clientId);
            } else {
                AppLogger.debug(VS_CLASS_NAME + " - loadPreApprovalApiScopes : client approvals = " + JsonUtil.toJsonStr(lm_clientApprovals));
            }

            ls_clientScopes = lm_clientApprovals.containsKey("scope") ? (String) lm_clientApprovals.get("scope") : null;

            if (lm_clientApprovals.containsKey("info")) {
                lm_clientInformation = (Map<String, String>) JsonUtil.toJavaBean(lm_clientApprovals.get("info").toString(), Map.class);

                authorizationRequest.setAppName(lm_clientInformation.get("application_name"));
            } else {
                authorizationRequest.setAppName("Open API");
            }

            if (!CommonUtil.isEmptyString(ls_clientScopes)) {
                ass_approvedScopes = StringUtils.commaDelimitedListToSet(ls_clientScopes);
            }

            authorizationRequest.setScope(ass_approvedScopes);

            AppLogger.debug(VS_CLASS_NAME + " - loadPreApprovalApiScopes : scopes = " + JsonUtil.toJsonStr(ass_approvedScopes));
        } else {
            AppLogger.info(VS_CLASS_NAME + " - loadPreApprovalApiScopes : is approved!");
        }

        return authorizationRequest;
    }

    @Override
    public AuthorizationRequest updateApiScopesAfterApproval(AuthorizationRequest authorizationRequest, Authentication userAuthentication) throws Exception {
        String ls_approvalParameter;
        String ls_approvalValue;

        boolean lb_approved;
        ApiScope l_approval;

        AppLogger.info(VS_CLASS_NAME + " - updateApiScopesAfterApproval...");

        Set<String> lss_requestedScopes = authorizationRequest.getScope();
        Set<String> lss_approvedScopes = new HashSet<>();
        Set<ApiScope> l_approvals = new HashSet<>();
        Date ld_expiry = computeExpiry();

        Map<String, String> approvalParameters = authorizationRequest.getApprovalParameters();

        AppLogger.debug(VS_CLASS_NAME + " - updateApiScopesAfterApproval : approval parameters = " + JsonUtil.toJsonStr(approvalParameters));

        for (String ls_requestedScope : lss_requestedScopes) {
            ls_approvalParameter = scopePrefix + ls_requestedScope;
            ls_approvalValue = approvalParameters.get(ls_approvalParameter);

            if (ls_approvalValue == null) {
                ls_approvalValue = "";
            } else {
                ls_approvalValue = ls_approvalValue.toLowerCase();
            }

            if ("true".equals(ls_approvalValue) || ls_approvalValue.startsWith("approve")) {
                lss_approvedScopes.add(ls_requestedScope);

                l_approval = new ApiScope(userAuthentication.getName(), authorizationRequest.getClientId(),
                        ls_requestedScope, ld_expiry, ApiScope.ApprovalStatus.APPROVED);
            } else {
                l_approval = new ApiScope(userAuthentication.getName(), authorizationRequest.getClientId(),
                        ls_requestedScope, ld_expiry, ApiScope.ApprovalStatus.DENIED);
            }

            l_approvals.add(l_approval);
            AppLogger.debug(VS_CLASS_NAME + " - updateApiScopesAfterApproval : add approval = " + JsonUtil.toJsonStr(l_approval));
        }

        v_approvalDao.addApprovals(l_approvals);

        authorizationRequest.setScope(lss_approvedScopes);
        authorizationRequest.setApprovalExpireAt(ld_expiry);

        if (lss_approvedScopes.isEmpty() && !lss_requestedScopes.isEmpty()) {
            lb_approved = false;
        } else {
            lb_approved = true;
        }

        authorizationRequest.setApproved(lb_approved);

        AppLogger.info(VS_CLASS_NAME + " - updateApiScopesAfterApproval : approve = " + lb_approved);
        return authorizationRequest;
    }

    @Override
    public Map<String, Object> getApiScopesForApprovalRequest(AuthorizationRequest authorizationRequest, Authentication userAuthentication) {
        Map<String, String> lm_scopes = new LinkedHashMap<>();
        Map<String, Object> lm_model = new HashMap<>();

        lm_model.putAll(authorizationRequest.getRequestParameters());

        for (String scope : authorizationRequest.getScope()) {
            lm_scopes.put(scopePrefix + scope, "true");
        }

        lm_model.put("scopes", lm_scopes);

        return lm_model;
    }

    private Date computeExpiry() {
        Calendar expiresAt = Calendar.getInstance();

        if (approvalExpirySeconds < 0) {
            expiresAt.add(Calendar.MONTH, 1);
        } else {
            expiresAt.add(Calendar.SECOND, approvalExpirySeconds);
        }

        return expiresAt.getTime();
    }
}
