package com.excelhk.openapi.usercertificationservice.request;

import com.excelhk.openapi.usercertificationservice.common.CommonUtil;
import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;

import java.util.Map;
import java.util.Set;

public class AuthorizationRequestFactory {

    private static AuthorizationRequestFactory v_factory;

    public static AuthorizationRequestFactory getInstance() {
        if (v_factory == null) {
            v_factory = new AuthorizationRequestFactory();
        }

        return v_factory;
    }

    public AuthorizationRequest createAuthorizationRequest(Map<String, String> am_parameters) {
        String ls_clientId = am_parameters.get(GlobalConstant.GS_CLIENT_ID);
        String ls_state = am_parameters.get(GlobalConstant.GS_STATE);
        String ls_redirectUri = am_parameters.get(GlobalConstant.GS_REDIRECT_URI);
        String ls_responseType = am_parameters.get(GlobalConstant.GS_RESPONSE_TYPE);

        Set<String> lss_scopes = extractScopes(am_parameters, ls_clientId);

        return new AuthorizationRequest(am_parameters, lss_scopes,ls_clientId, ls_state, ls_redirectUri, ls_responseType);
    }

    public AccessTokenRequest createAccessTokenRequest(AuthorizationRequest a_authRequest) {
        return new AccessTokenRequest(a_authRequest);
    }

    private Set<String> extractScopes(Map<String, String> requestParameters, String clientId) {
        return CommonUtil.parseParameterList(requestParameters.get(GlobalConstant.GS_SCOPE));
    }
}
