package com.excelhk.openapi.usercertificationservice.store;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = {"classpath:config/restful.properties", "file:config/restful.properties"}, ignoreResourceNotFound = true)
@ConfigurationProperties("restful.store")
public class RestfulStore extends BaseStore {

    private String vs_checkUserUrl;
    private String vs_verifyUserUrl;
    private String vs_accessTokenUrl;
    private String vs_accessApiUrl;
    private String vs_authorization;
    private int vi_connectionTimeout;
    private int vi_readTimeout;

    @Override
    protected void loadPropertiesData(String as_prefix) { }

    public String getCheckUserUrl() {
        return vs_checkUserUrl;
    }

    public void setCheckUserUrl(String checkUserUrl) {
        this.vs_checkUserUrl = checkUserUrl;
    }

    public String getVerifyUserUrl() {
        return vs_verifyUserUrl;
    }

    public void setVerifyUserUrl(String verifyUserUrl) {
        this.vs_verifyUserUrl = verifyUserUrl;
    }

    public String getAccessTokenUrl() {
        return vs_accessTokenUrl;
    }

    public void setAccessTokenUrl(String accessTokenUrl) {
        this.vs_accessTokenUrl = accessTokenUrl;
    }

    public String getAccessApiUrl() {
        return vs_accessApiUrl;
    }

    public void setAccessApiUrl(String accessApiUrl) {
        this.vs_accessApiUrl = accessApiUrl;
    }

    public String getAuthorization() {
        return vs_authorization;
    }

    public void setAuthorization(String authorization) {
        this.vs_authorization = authorization;
    }

    public int getConnectionTimeout() {
        return vi_connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.vi_connectionTimeout = connectionTimeout;
    }

    public int getReadTimeout() {
        return vi_readTimeout;
    }

    public void setReadTimeout(int readTimeout) {
        this.vi_readTimeout = readTimeout;
    }
}
