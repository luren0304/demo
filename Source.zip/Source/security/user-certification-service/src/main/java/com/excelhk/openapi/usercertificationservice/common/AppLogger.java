package com.excelhk.openapi.usercertificationservice.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppLogger {

    private final static Logger V_LOGGER = LoggerFactory.getLogger("APP");

    public static void info(String as_msg, Object... ao_params) {
        V_LOGGER.info(as_msg, ao_params);
    }

    public static void debug(String as_msg, Object... ao_params) {
        V_LOGGER.debug(as_msg, ao_params);
    }

    public static void warn(String as_msg, Object... ao_params) {
        V_LOGGER.warn(as_msg, ao_params);
    }

    public static void error(String as_msg, Throwable a_throw) {
        V_LOGGER.error(as_msg, a_throw);
    }
}
