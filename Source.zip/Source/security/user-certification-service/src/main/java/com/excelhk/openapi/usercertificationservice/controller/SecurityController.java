package com.excelhk.openapi.usercertificationservice.controller;

import com.excelhk.openapi.usercertificationservice.common.AppLogger;
import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

@Controller
@SessionAttributes(GlobalConstant.GS_AUTHORIZATION_REQUEST)
public class SecurityController {

    private RequestCache requestCache = new HttpSessionRequestCache();

    @RequestMapping(value = { "/", "/home"})
    public String homePage() {
        AppLogger.info("SecurityController - homePage ...");

        return "index";
    }

    @RequestMapping("/login")
    public String loginPage(HttpServletRequest request, HttpServletResponse response) {
        AppLogger.info("SecurityController - loginPage ...");

        SavedRequest l_savedRequest = requestCache.getRequest(request, response);
        String[] lss_linkedUsers = (l_savedRequest != null) ? l_savedRequest.getParameterValues("user") : null;

        if (lss_linkedUsers != null) {
            request.getSession().setAttribute("LINKED_USER", lss_linkedUsers[0]);

            AppLogger.info("SecurityController - loginPage : Linked user = " + lss_linkedUsers[0]);
        }

        return "login";
    }

    @RequestMapping("/approve")
    public String approvePage(HttpServletRequest request, HttpServletResponse response) {
        AppLogger.info("SecurityController - approvePage ...");

        return "approve";
    }

    @CrossOrigin
    @RequestMapping("/logout_callback")
    public @ResponseBody Object logoutCallback(HttpServletRequest request, HttpServletResponse response) {
        AppLogger.info("SecurityController - logoutCallback ...");

        return new ArrayList<>();
    }
}
