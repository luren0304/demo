package com.excelhk.openapi.usercertificationservice.sql;

import com.excelhk.openapi.usercertificationservice.common.CommonUtil;

import java.util.HashMap;

public class SqlConstants extends HashMap<String, String> {

    private static SqlConstants v_sqlPool = null;

    // Client Detail
    public static final String CS_SQL_PERMIT_SEARCH = "PERMIT.SEARCH";

    // User Approve
    public static final String CS_SQL_USER_APPROVE_ADD = "GS_USER-APPROVE.ADD";
    public static final String CS_SQL_USER_APPROVE_SEARCH = "GS_USER-APPROVE.SEARCH";
    public static final String CS_SQL_USER_APPROVE_UPDATE = "GS_USER-APPROVE.UPDATE";
    public static final String CS_SQL_USER_APPROVE_UPDATE_EXPIRED = "GS_USER-APPROVE.UPDATE-EXPIRED";
    public static final String CS_SQL_USER_APPROVE_DELETE = "GS_USER-APPROVE.DELETE";
    public static final String CS_SQL_USER_APPROVE_DELETE_EXPIRED = "GS_USER-APPROVE.DELETE-EXPIRED";

    // Approve
    public static final String CS_SQL_APPROVE_ADD    = "APPROVE.ADD";
    public static final String CS_SQL_APPROVE_SEARCH = "APPROVE.SEARCH";
    public static final String CS_SQL_APPROVE_SEARCH_STATUS = "APPROVE.SEARCH-STATUS";
    public static final String CS_SQL_APPROVE_UPDATE = "APPROVE.UPDATE";
    public static final String CS_SQL_APPROVE_UPDATE_EXPIRED = "APPROVE.UPDATE-EXPIRED";
    public static final String CS_SQL_APPROVE_DELETE = "APPROVE.DELETE";
    public static final String CS_SQL_APPROVE_DELETE_EXPIRED = "APPROVE.DELETE-EXPIRED";

    public SqlConstants() {
        super(100);
        loadSQL();
    }

    private void loadSQL() {
        ApprovalSqlConstants.loadSql(this);
        UserApprovalSqlConstants.loadSql(this);
    }

    public static String getSQL(String as_sqlName) {
        String ls_sql = "";

        if (v_sqlPool == null) {
            v_sqlPool = new SqlConstants();
        }

        ls_sql = v_sqlPool.get(as_sqlName);

        if (CommonUtil.isEmptyString(ls_sql)) {
            throw new RuntimeException("Required sql for : "+ as_sqlName + " not found");
        }

        return ls_sql;
    }
}
