package com.excelhk.openapi.usercertificationservice.service.impl;

import com.excelhk.openapi.usercertificationservice.api.AccessApi;
import com.excelhk.openapi.usercertificationservice.api.Api;
import com.excelhk.openapi.usercertificationservice.api.ApiDefinition;
import com.excelhk.openapi.usercertificationservice.api.ApiVersionData;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.dao.IUserApprovalDao;
import com.excelhk.openapi.usercertificationservice.entity.UserApproval;
import com.excelhk.openapi.usercertificationservice.request.AccessApiRequest;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import com.excelhk.openapi.usercertificationservice.service.IRestService;
import com.excelhk.openapi.usercertificationservice.service.IUserApprovalService;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;

import java.util.*;

public class UserApprovalServiceImplTest extends BaseServiceTest {

    private static final String VS_INVALID_CLIENT_ID = "xxxxxx";

    @Mock
    private IUserApprovalDao v_mockUserApprovalDao;

    @Mock
    private IRestService v_mockRestService;

    @InjectMocks
    @Autowired
    private IUserApprovalService v_mockService;

    private AuthorizationRequest v_authorizationRequest;
    private Authentication v_authentication;

    @Override
    public void initMocks() {
        super.initMocks();

        v_authentication = getAuthentication();
        v_authorizationRequest = getAuthorizationRequest();
    }

    @Test
    public void checkForPreUserApproval() throws Exception {
        String ls_username = v_authentication.getName();
        String ls_clientId = v_authorizationRequest.getClientId();

        P_LOGGER.info("Testing user not approval...");
        testUserApproval(ls_username, VS_INVALID_CLIENT_ID, false);
        P_LOGGER.debug("Testing user not approval, result = " + JsonUtil.toJsonStr(v_authorizationRequest));

        P_LOGGER.info("Testing user already approved...");
        testUserApproval(ls_username, ls_clientId, true);
        P_LOGGER.debug("Testing user already approved, result = " + JsonUtil.toJsonStr(v_authorizationRequest));
    }

    @Test
    public void updateUserApprovalAfterApproval() throws Exception {
        Set<String> lss_approvedScopes = v_authorizationRequest.getScope();

        for (String ls_scope : lss_approvedScopes) {
            AccessApiRequest l_accessApiRequest = new AccessApiRequest(ls_scope);
            l_accessApiRequest.build();

            Api l_api = new Api(new Date(), new ApiDefinition(UUID.randomUUID().toString(), ls_scope, "", true, new ApiVersionData()));

            List<Api> ll_apis = new ArrayList<>();
            ll_apis.add(l_api);

            AccessApi l_accessApi = new AccessApi();
            l_accessApi.setApis(ll_apis);

            P_LOGGER.debug("Retrieve access api = " + JsonUtil.toJsonStr(l_accessApi));

            Mockito.when(v_mockRestService.retrieveAccessApi(l_accessApiRequest)).thenReturn(l_accessApi);
        }

        v_authorizationRequest.setApproved(true);
        v_authorizationRequest.setApprovalExpireAt(new Date());

        v_mockService.updateUserApprovalAfterApproval(v_authorizationRequest, v_authentication);

        Mockito.verify(v_mockUserApprovalDao).addUserApprovals(Mockito.any());
        Assert.assertNotNull(v_authorizationRequest.getTokenKeyRule());

        P_LOGGER.debug("Result = " + JsonUtil.toJsonStr(v_authorizationRequest));
    }

    private void testUserApproval(String as_username, String as_clientId, boolean ab_isApproved) throws Exception {
        if (ab_isApproved) {
            Mockito.when(v_mockUserApprovalDao.getUserUnexpiredApproval(as_username, as_clientId)).thenReturn(new UserApproval());
        } else {
            Mockito.when(v_mockUserApprovalDao.getUserUnexpiredApproval(as_username, as_clientId)).thenReturn(null);
        }

        v_authorizationRequest.setClientId(as_clientId);
        v_mockService.checkForPreUserApproval(v_authorizationRequest, v_authentication);

        Mockito.verify(v_mockUserApprovalDao).getUserUnexpiredApproval(as_username, as_clientId);

        Assert.assertEquals(ab_isApproved, v_authorizationRequest.isApproved());
    }
}