package com.excelhk.openapi.usercertificationservice.controller;

import com.excelhk.openapi.usercertificationservice.BaseTest;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.nio.charset.StandardCharsets;

import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;


public abstract class BaseControllerTest extends BaseTest {

    @Autowired
    private WebApplicationContext v_webContext;

    private MockMvc mockMvc;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(v_webContext).apply(springSecurity()).build();
    }

    public ResultActions perform(RequestBuilder a_requestBuilder) throws Exception {
        return mockMvc.perform(a_requestBuilder).andDo(MockMvcResultHandlers.log());
    }

    public MockHttpServletRequestBuilder getPostRequestBuilder(String as_uri, Object... ao_uriVars) {
        return MockMvcRequestBuilders.post(as_uri, ao_uriVars).characterEncoding(StandardCharsets.UTF_8.displayName());
    }

    public MockHttpServletRequestBuilder getGetRequestBuilder(String as_uri, Object... ao_uriVars) {
        return MockMvcRequestBuilders.get(as_uri, ao_uriVars).characterEncoding(StandardCharsets.UTF_8.displayName());
    }
}
