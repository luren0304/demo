package com.excelhk.openapi.usercertificationservice.controller;

import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.store.TestStore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.util.AssertionErrors;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.ui.ModelMap;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Map;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.logout;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.unauthenticated;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class AuthorizationControllerTest extends BaseControllerTest {

    private String vs_testUsername;
    private String vs_testPassword;

    private static final String VS_CONFIRM_ACCESS_URL = "/oauth/confirm_access";
    private static final String VS_APPROVAL_URL = "/oauth/approval";
    private static final String VS_ACCESS_TOKEN = "access_token";

    private static final String VS_USER_OAUTH_APPROVAL = "user_oauth_approval";

    private static final String PS_URL_APPROVE = "/approve";
    private static final String PS_URL_AUTHORIZE = "/oauth/authorize";

    @Autowired
    private TestStore testStore;

    @PostConstruct
    public void init() {
        vs_testUsername = testStore.getUsername();
        vs_testPassword = testStore.getPassword();
    }

    @Test
    public void authorizeWithoutAuthentication() throws Exception {
        authorize().andExpect(unauthenticated()).andReturn();
    }

    @Test
    @WithMockDummy
    public void authorizeWithAuthentication() throws Exception {
        MvcResult l_mvcResult = authorize().andExpect(authenticated()).andReturn();
        MockHttpServletResponse l_response = l_mvcResult.getResponse();

        int li_responseStatus = l_response.getStatus();
        String ls_redirectedUrl = l_response.getRedirectedUrl();
        String ls_forwardedUrl = l_response.getForwardedUrl();

        ModelMap modelMap = l_mvcResult.getModelAndView().getModelMap();
        Object lo_authorizeRequest = modelMap.get(GlobalConstant.GS_AUTHORIZATION_REQUEST);
        Object lo_scopes = modelMap.get(GlobalConstant.GS_SCOPES);

        // Goto scope approval
        if (HttpStatus.OK.value() == li_responseStatus) {
            if (StringUtils.isEmpty(ls_forwardedUrl) || !ls_forwardedUrl.endsWith(VS_CONFIRM_ACCESS_URL)) {
                AssertionErrors.fail("Forward url must be ends with ", VS_CONFIRM_ACCESS_URL, ls_forwardedUrl);
            } else {
                P_LOGGER.info("Get access confirmation:");
                getAccessConfirmation(ls_forwardedUrl, lo_authorizeRequest, lo_scopes);

                P_LOGGER.info("Approve or Deny scopes :");
                approveOrDeny(lo_authorizeRequest, lo_scopes);
            }

        // Skipping the scope approval
        } else if (HttpStatus.FOUND.value() == li_responseStatus) {
            verifyAccessToken(ls_redirectedUrl);
        } else {
            AssertionErrors.fail("Request status must be in ", HttpStatus.OK.value() + "," + HttpStatus.FOUND.value(), li_responseStatus);
        }
    }

    @Test
    public void loginWithUsernameNotFound() throws Exception {
        login("anonymous", null).andExpect(unauthenticated());
    }

    @Test
    public void loginWithPasswordIncorrect() throws Exception {
        login(vs_testUsername, "password").andExpect(unauthenticated());
    }

    @Test
    public void loginAndLogout() throws Exception {
        login(vs_testUsername, vs_testPassword).andExpect(authenticated().withUsername(vs_testPassword));

        perform(logout()).andExpect(unauthenticated());
    }

    private ResultActions login(String as_username, String as_password) throws Exception {
        return perform(formLogin().user(as_username).password(as_password));
    }

    private ResultActions authorize() throws Exception {
        MultiValueMap<String, String> lmvm_params = new LinkedMultiValueMap<String, String>();

        lmvm_params.add(GlobalConstant.GS_CLIENT_ID, testStore.getClientId());
        lmvm_params.add(GlobalConstant.GS_RESPONSE_TYPE, testStore.getClientResponseType());
        lmvm_params.add(GlobalConstant.GS_REDIRECT_URI, testStore.getClientRedirectUri());
        lmvm_params.add(GlobalConstant.GS_STATE, testStore.getClientState());

        return perform(getPostRequestBuilder(PS_URL_AUTHORIZE).params(lmvm_params));
    }

    private void approveOrDeny(Object a_authorizeRequest, Object a_scopes) throws Exception {

        Map<String, String > lm_scope = (Map<String, String>) a_scopes;
        MultiValueMap<String, String> lmvm_approveAllParams = new LinkedMultiValueMap<>();

        lmvm_approveAllParams.setAll(lm_scope);
        lmvm_approveAllParams.add(VS_USER_OAUTH_APPROVAL, "true");

        MvcResult l_mvcResult = perform(getPostRequestBuilder(VS_APPROVAL_URL)
                .requestAttr(GlobalConstant.GS_AUTHORIZATION_REQUEST, a_authorizeRequest)
                .params(lmvm_approveAllParams))
                .andExpect(authenticated()).andExpect(status().isFound()).andReturn();

        verifyAccessToken(l_mvcResult.getResponse().getRedirectedUrl());
    }

    private void getAccessConfirmation(String as_forwardUrl, Object a_authorizeRequest, Object a_scopes) throws Exception {
        perform(getPostRequestBuilder(as_forwardUrl)
                .requestAttr(GlobalConstant.GS_AUTHORIZATION_REQUEST, a_authorizeRequest)
                .requestAttr(GlobalConstant.GS_SCOPES, a_scopes))
                .andExpect(authenticated())
                .andExpect(status().isOk())
                .andExpect(forwardedUrl(PS_URL_APPROVE)).andReturn();
    }

    private void verifyAccessToken(String as_redirectedUrl) {
        if (StringUtils.isEmpty(as_redirectedUrl) || !as_redirectedUrl.startsWith(testStore.getClientRedirectUri())) {
            AssertionErrors.fail("Redirected url must be starts with ", testStore.getClientRedirectUri(), as_redirectedUrl);
        }

        if (!as_redirectedUrl.contains(VS_ACCESS_TOKEN)) {
            AssertionErrors.fail("Redirected url must be contains ", VS_ACCESS_TOKEN, as_redirectedUrl);
        }
    }
}


@Retention(RetentionPolicy.RUNTIME)
@WithMockUser(username = "dummy", password = "password", authorities = {"All"})
@interface WithMockDummy { }