package com.excelhk.openapi.usercertificationservice.controller;

import org.junit.Test;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class SecurityControllerTest extends BaseControllerTest {

    @Test
    public void homePage() throws Exception {
        perform(getGetRequestBuilder("/")).andExpect(status().isOk());
        perform(getGetRequestBuilder("/home")).andExpect(status().isOk());
    }

    @Test
    public void loginPage() throws Exception {
        perform(getGetRequestBuilder("/login")).andExpect(status().isOk());
    }

    @Test
    public void approvePage() throws Exception  {
        perform(getGetRequestBuilder("/approve")).andExpect(status().isOk());
    }

    @Test
    public void logoutCallback() throws Exception {
        perform(getGetRequestBuilder("/logout_callback")).andExpect(status().isOk());
    }
}