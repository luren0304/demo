package com.excelhk.openapi.usercertificationservice;

import org.junit.AfterClass;
import org.junit.AssumptionViolatedException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.junit.runner.RunWith;
import org.junit.runners.model.Statement;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.context.web.ServletTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration
@WebAppConfiguration
@Transactional
@TestExecutionListeners(listeners = {
        ServletTestExecutionListener.class,
        DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        WithSecurityContextTestExecutionListener.class})
public abstract class BaseTest {

    protected static final Logger P_LOGGER = LoggerFactory.getLogger("TEST");

    private static long vl_classMethodExecuteTime = -1L;

    public BaseTest() {
        Thread.currentThread().setName(getClass().getSimpleName());
    }

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @AfterClass
    public static void endOfTest() {
        P_LOGGER.info(">>>>>> Total Execute Time = " + vl_classMethodExecuteTime + " <<<<<<");

        vl_classMethodExecuteTime = -1L;
    }

    @Rule
    public TestRule methodTestWatcher = new TestWatcher() {
        private long ll_executeTime = -1;

        @Override
        public Statement apply(Statement base, Description description) {
            return super.apply(base, description);
        }

        @Override
        protected void succeeded(Description description) {
            super.succeeded(description);

            calculateMethodExecuteTime();

            print(description, ": Succeeded(" + ll_executeTime + ")!");
        }

        @Override
        protected void failed(Throwable e, Description description) {
            super.failed(e, description);

            calculateMethodExecuteTime();

            print(description, ": Failed!", e);
        }

        @Override
        protected void skipped(AssumptionViolatedException e, Description description) {
            super.skipped(e, description);

            calculateMethodExecuteTime();

            print(description, ": Skipped(" + ll_executeTime + ")!");
        }

        @Override
        protected void starting(Description description) {
            print(description, "...");

            calculateMethodExecuteTime();

            super.starting(description);
        }

        @Override
        protected void finished(Description description) {
            super.finished(description);

            vl_classMethodExecuteTime += ll_executeTime;

            P_LOGGER.info("--------------------------------------------------------------------------------");
        }

        private void calculateMethodExecuteTime() {
            if (ll_executeTime < 0) {
                ll_executeTime = System.currentTimeMillis();
            } else {
                ll_executeTime = System.currentTimeMillis() - ll_executeTime;
            }
        }

        private void print(Description description, String as_message) {
            P_LOGGER.info(description.getClassName() + " - " + description.getMethodName() + as_message);
        }

        private void print(Description description, String as_message, Throwable throwable) {
            P_LOGGER.error(description.getClassName() + " - " + description.getMethodName() + as_message, throwable);
        }
    };
}
