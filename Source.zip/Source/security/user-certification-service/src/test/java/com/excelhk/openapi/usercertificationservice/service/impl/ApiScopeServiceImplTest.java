package com.excelhk.openapi.usercertificationservice.service.impl;

import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.common.JsonUtil;
import com.excelhk.openapi.usercertificationservice.dao.IApiScopeDao;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import com.excelhk.openapi.usercertificationservice.service.IApiScopeService;
import com.excelhk.openapi.usercertificationservice.store.TestStore;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ApiScopeServiceImplTest extends BaseServiceTest {

    private static final String VS_INVALID_CLIENT_ID = "xxxxxx";
    private static final String VS_CLIENT_ID_NO_SCOPES = "Unauthorized";
    private static final String VS_APPLICATION_NAME = "test";

    @Mock
    private IApiScopeDao v_mockApprovalDao;

    @InjectMocks
    @Autowired
    private IApiScopeService v_mockService;

    @Autowired
    private TestStore v_testStore;

    private AuthorizationRequest v_authorizationRequest;
    private Authentication v_authentication;

    private String vs_clientId;

    @Override
    public void initMocks() {
        super.initMocks();

        v_authentication = getAuthentication();
        v_authorizationRequest = getAuthorizationRequest();
        vs_clientId = v_testStore.getClientId();
    }

    @Test
    public void loadPreApprovalApiScopes() throws Exception {
        testInvalidClientId();

        testClientIdWithoutScopes();

        testClientIdWithScopes();
    }

    @Test
    public void updateApiScopesAfterApproval() throws Exception {
        testApiApprovalWithDeny();

        testApiApprovalWithPartDeny();

        testApiApprovalWithApproved();
    }

    private void testApiApprovalWithDeny() throws Exception {
        P_LOGGER.info("Testing api approval with deny...");

        setApiScopes(false, false);

        v_mockService.updateApiScopesAfterApproval(v_authorizationRequest, v_authentication);

        Mockito.verify(v_mockApprovalDao).addApprovals(Mockito.anyCollection());

        P_LOGGER.info("Testing api approval with deny, result = " + JsonUtil.toJsonStr(v_authorizationRequest));

        Assert.assertFalse(v_authorizationRequest.isApproved());
    }

    private void testApiApprovalWithPartDeny() throws Exception {
        P_LOGGER.info("Testing api approval with part deny...");
        setApiScopes(true, true);

        v_mockService.updateApiScopesAfterApproval(v_authorizationRequest, v_authentication);
        Mockito.verify(v_mockApprovalDao, Mockito.times(2)).addApprovals(Mockito.anyCollection());

        P_LOGGER.info("Testing api approval with part deny, result = " + JsonUtil.toJsonStr(v_authorizationRequest));

        Assert.assertTrue(v_authorizationRequest.isApproved());
    }

    private void testApiApprovalWithApproved() throws Exception {
        P_LOGGER.info("Testing api approval with part approved...");
        setApiScopes(true, false);

        v_mockService.updateApiScopesAfterApproval(v_authorizationRequest, v_authentication);
        Mockito.verify(v_mockApprovalDao, Mockito.times(3)).addApprovals(Mockito.anyCollection());

        P_LOGGER.info("Testing api approval with approved, result = " + JsonUtil.toJsonStr(v_authorizationRequest));

        Assert.assertTrue(v_authorizationRequest.isApproved());
    }

    private void setApiScopes(boolean ab_isApproved, boolean ab_isParted) {
        Map<String, String> lm_scopes = new LinkedHashMap<>();

        reset();

        for (String scope : v_authorizationRequest.getScope()) {
            if (ab_isParted) {
                if (lm_scopes.size() % 2 == 0) {
                    lm_scopes.put(GlobalConstant.GS_SCOPE_PREFIX + scope, "true");
                } else {
                    lm_scopes.put(GlobalConstant.GS_SCOPE_PREFIX + scope, "false");
                }
            } else {
                if (ab_isApproved) {
                    lm_scopes.put(GlobalConstant.GS_SCOPE_PREFIX + scope, "true");
                } else {
                    lm_scopes.put(GlobalConstant.GS_SCOPE_PREFIX + scope, "false");
                }
            }
        }

        v_authorizationRequest.setApprovalParameters(lm_scopes);
    }

    private void testInvalidClientId() {
        P_LOGGER.info("Testing invalid client id...");

        v_authorizationRequest.setClientId(VS_INVALID_CLIENT_ID);

        Mockito.when(v_mockApprovalDao.getApprovals(VS_INVALID_CLIENT_ID)).thenReturn(null);

        try {
            v_mockService.loadPreApprovalApiScopes(v_authorizationRequest, v_authentication);
        } catch (Exception a_exception) {
            P_LOGGER.info("Testing invalid client id, error = " + a_exception.getLocalizedMessage());
        }

        Mockito.verify(v_mockApprovalDao).getApprovals(VS_INVALID_CLIENT_ID);
    }

    private void testClientIdWithoutScopes() throws Exception {
        P_LOGGER.info("Testing client id without scopes...");

        v_authorizationRequest.setClientId(VS_CLIENT_ID_NO_SCOPES);

        Mockito.when(v_mockApprovalDao.getApprovals(VS_CLIENT_ID_NO_SCOPES)).thenReturn(new HashMap<>());

        v_mockService.loadPreApprovalApiScopes(v_authorizationRequest, v_authentication);

        Mockito.verify(v_mockApprovalDao).getApprovals(VS_CLIENT_ID_NO_SCOPES);

        P_LOGGER.info("Testing client id without scopes, result = " + JsonUtil.toJsonStr(v_authorizationRequest));
    }

    private void testClientIdWithScopes() throws Exception {
        P_LOGGER.info("Testing normal client id...");

        v_authorizationRequest.setClientId(vs_clientId);

        Map<String, Object> lm_info = new HashMap<>();
        lm_info.put("application_name", VS_APPLICATION_NAME);

        Map<String, Object> lm_result = new HashMap<>();
        lm_result.put("scope", v_testStore.getScopes());
        lm_result.put("info", JsonUtil.toJsonStr(lm_info));

        Mockito.when(v_mockApprovalDao.getApprovals(vs_clientId)).thenReturn(lm_result);

        v_mockService.loadPreApprovalApiScopes(v_authorizationRequest, v_authentication);

        Mockito.verify(v_mockApprovalDao).getApprovals(vs_clientId);

        P_LOGGER.info("Testing normal client id, result = " + JsonUtil.toJsonStr(v_authorizationRequest));
    }

}