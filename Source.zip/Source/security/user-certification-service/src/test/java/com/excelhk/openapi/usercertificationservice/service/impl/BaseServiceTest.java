package com.excelhk.openapi.usercertificationservice.service.impl;

import com.excelhk.openapi.usercertificationservice.BaseTest;
import com.excelhk.openapi.usercertificationservice.common.GlobalConstant;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequest;
import com.excelhk.openapi.usercertificationservice.request.AuthorizationRequestFactory;
import com.excelhk.openapi.usercertificationservice.store.TestStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

public abstract class BaseServiceTest extends BaseTest {

    private static final String VS_SCOPE_CHAIN = "scopeA,scopeB";

    private AuthorizationRequest v_authorizationRequest;
    private TestingAuthenticationToken v_authentication;

    @Autowired
    private TestStore v_testStore;

    @Override
    public void initMocks() {
        super.initMocks();

        init();
    }

    public AuthorizationRequest getAuthorizationRequest() {
        return v_authorizationRequest;
    }

    public Authentication getAuthentication() {
        return v_authentication;
    }

    protected void reset() {
        init();
    }

    private void init() {
        Map<String, String> lm_params = new HashMap<>();

        lm_params.put(GlobalConstant.GS_CLIENT_ID, v_testStore.getClientId());
        lm_params.put(GlobalConstant.GS_RESPONSE_TYPE, v_testStore.getClientResponseType());
        lm_params.put(GlobalConstant.GS_REDIRECT_URI, v_testStore.getClientRedirectUri());
        lm_params.put(GlobalConstant.GS_STATE, v_testStore.getClientState());

        v_authentication = new TestingAuthenticationToken("dummy", "password");
        v_authorizationRequest = AuthorizationRequestFactory.getInstance().createAuthorizationRequest(lm_params);
        v_authorizationRequest.setScope(StringUtils.commaDelimitedListToSet(v_testStore.getScopes()));
    }

}
