package com.excelhk.openapi.usercertificationservice;

import com.excelhk.openapi.usercertificationservice.controller.AuthorizationControllerTest;
import com.excelhk.openapi.usercertificationservice.controller.SecurityControllerTest;
import com.excelhk.openapi.usercertificationservice.service.impl.ApiScopeServiceImplTest;
import com.excelhk.openapi.usercertificationservice.service.impl.UserApprovalServiceImplTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        ApiScopeServiceImplTest.class,
        UserApprovalServiceImplTest.class,
        SecurityControllerTest.class,
        AuthorizationControllerTest.class
})
public class OpenapiPermitApplicationTests {}